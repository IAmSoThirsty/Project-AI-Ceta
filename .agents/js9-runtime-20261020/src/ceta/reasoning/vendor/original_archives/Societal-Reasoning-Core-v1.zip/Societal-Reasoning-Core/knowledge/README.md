# Complete two-volume societal inventory — Version 1

The owner-authorized target is **all 2,000 entries**, divided into two source Markdown files:

- `volume-01-full.md`: IDs `1` through `1000`, every number present once.
- `volume-02-full.md`: IDs `1001` through `2000`, every number present once.

Both files were manually transcribed from earlier assistant-authored inventories in this conversation. They are retained as **local working sources** with source-line metadata and SHA-256 hashes. Punctuation was normalized during ASCII-safe transcription; they have not been line-by-line checked against an independently exported chat transcript. These are inventory source descriptions, not independently established facts. The original research claims are **not** assigned `independently_verified`.

`python scripts/compile_inventory.py` validates that compiled JSONL records match these exact files. `python scripts/compile_inventory.py --write` deliberately regenerates the derived artifacts. The canonical runtime load is `src/societal_reasoning/resources/concepts.full.jsonl`; the two volume-specific full JSONL files are derived outputs. Historical 8-entry snippets and 134 starter summaries are retained only for lineage and are **not** loaded into the canonical graph.

Every record contains `id`, `label`, `summary`, `original_text`, `domains`, `aliases`, `source` with volume/line/source SHA-256/entry SHA-256, and `status=source_transcribed`. The source hash proves local integrity **relative to the saved file**, not authorship, external authenticity, or factual correctness.

The release fails if the local files or compiled data have missing, duplicate, renamed, mismatched, or out-of-range IDs. No blanket proof of social comprehension is claimed merely because the inventory is complete.
