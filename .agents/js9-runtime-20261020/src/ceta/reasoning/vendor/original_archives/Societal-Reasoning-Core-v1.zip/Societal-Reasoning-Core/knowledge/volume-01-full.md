# THE ANATOMY OF HUMAN SOCIETY - VOLUME I
## 1. Physical reality and natural resources
1. **Air and oxygen:** Sustains life; pollution, airborne toxins, and emissions harm populations.
2. **Water:** Drinking, sanitation, agriculture, industry, transportation, and ecosystems; scarcity, contamination, privatized exclusion, and water conflict.
3. **Food:** Nutrition, survival, culture, celebration, employment, and trade; starvation, malnutrition, waste, adulteration, and unequal access.
4. **Energy:** Electricity, heat, mobility, computation, manufacturing, medicine, and communication; energy poverty, pollution, extraction, and supply manipulation.
5. **Land:** Habitation, agriculture, identity, sovereignty, and natural habitat; dispossession, land grabs, exclusion, speculation, and territorial conflict.
6. **Soil:** Crop production, nutrient cycles, carbon storage, and ecological stability; erosion, degradation, contamination, and desertification.
7. **Forests:** Biodiversity, timber, medicines, water regulation, cultural meaning, and carbon storage; deforestation, habitat destruction, and illicit logging.
8. **Oceans:** Food, climate regulation, shipping, international commerce, and ecological diversity; overfishing, pollution, exploitation, and territorial disputes.
9. **Rivers and lakes:** Freshwater, irrigation, energy, transportation, recreation, and settlement; flooding, contamination, overuse, and dam-related displacement.
10. **Minerals and metals:** Construction, electronics, transportation, manufacturing, and advanced technology; dangerous mining, conflict minerals, and ecological damage.
11. **Fossil fuels:** Industrial development, heating, transportation, and electricity; greenhouse emissions, pollution, dependency, and geopolitical leverage.
12. **Renewable resources:** Replenishable energy and materials; land conflicts, material extraction, habitat disturbance, and waste if poorly managed.
13. **Animals:** Food, companionship, labor, ecosystems, research, and cultural meaning; cruelty, extinction, disease transmission, and exploitation.
14. **Plants:** Nutrition, medicines, construction, oxygen production, and ecological support; invasive species, crop failures, and toxic exposure.
15. **Microorganisms:** Digestion, decomposition, fermentation, soil fertility, and medicine; epidemics, infections, and biological contamination.
16. **Weather:** Agriculture, water cycles, transportation, and daily life; droughts, storms, floods, and extreme temperatures.
17. **Climate:** Long-term conditions that make settlement and production possible; climate disruption, displacement, resource insecurity, and ecosystem collapse.
18. **Geography:** Natural protection, trade routes, resource distribution, and cultural development; isolation, transport barriers, and unequal geographical opportunities.
19. **Natural disasters:** Forces that test adaptation, cooperation, and resilience; earthquakes, tsunamis, volcanic eruptions, wildfires, landslides, and mass destruction.
20. **Space and orbital systems:** Satellite communications, navigation, weather forecasting, scientific discovery, and planetary observation; orbital debris, militarization, and collision risks.
21. **Physical laws:** The predictable foundations of engineering, medicine, agriculture, and civilization; physical constraints that no political or economic institution can suspend.
22. **Finite resources:** Encourage conservation, prioritization, and innovation; create competition, scarcity, hoarding, and conflict.
## 2. Biology, survival, and the human lifecycle
23. **Birth:** Continuation of populations and families; maternal mortality, reproductive coercion, and unequal reproductive healthcare.
24. **Reproduction:** Intergenerational continuity and family formation; unwanted pregnancy, infertility-related hardship, coercion, and exploitation.
25. **Sexuality:** Intimacy, reproduction, pleasure, attachment, and personal identity; assault, coercion, objectification, stigma, and exploitation.
26. **Sleep:** Physical recovery, cognition, emotional regulation, and productivity; deprivation, exhaustion, and impaired judgment.
27. **Nutrition:** Development, health, and cognitive function; hunger, disordered eating, nutrient deficiencies, and food insecurity.
28. **Physical health:** Independence, participation, and quality of life; disease, disability-related barriers, and unequal access to treatment.
29. **Mental health:** Psychological functioning, relationships, and resilience; suffering, stigma, neglect, and inadequate treatment.
30. **Aging:** Experience, knowledge transmission, mentorship, and generational continuity; frailty, age discrimination, isolation, and dependency.
31. **Childhood:** Learning, attachment, socialization, and future development; neglect, abuse, exploitation, and interrupted development.
32. **Adolescence:** Identity formation, experimentation, social learning, and independence; bullying, manipulation, impulsive harm, and coercion.
33. **Adulthood:** Responsibility, productivity, caregiving, autonomy, and community participation; overwork, economic insecurity, and social pressure.
34. **Elderhood:** Historical memory, wisdom, traditions, and intergenerational assistance; abandonment, institutional neglect, and financial exploitation.
35. **Death:** A biological certainty that shapes inheritance, religion, medicine, law, and family organization; grief, premature death, violence, and institutional mishandling.
36. **Disease:** Drives medical research and public health organization while causing suffering, disability, economic disruption, and mortality.
37. **Genetic inheritance:** Biological continuity and variation; inherited disease and the misuse of genetics to justify discrimination.
38. **Physical differences:** Human diversity and different capabilities; exclusion, ableism, accessibility barriers, and harmful stereotypes.
39. **Neurodiversity:** Variation in cognition, perception, attention, and problem-solving; exclusion and unmet support needs.
40. **Human dependency:** Makes cooperation, caregiving, and shared responsibility indispensable; creates vulnerability to neglect and control.
## 3. Emotions, instincts, and motivations
41. **Love:** Attachment, sacrifice, protection, loyalty, and connection; possessiveness and unhealthy dependency when distorted.
42. **Compassion:** Assistance, mercy, care, and solidarity; susceptibility to manipulation or harmful overextension.
43. **Empathy:** Understanding another person's experience; selective empathy, emotional manipulation, or partiality.
44. **Kindness:** Everyday cooperation and goodwill; exploitation of generosity by opportunistic people.
45. **Happiness:** Satisfaction, celebration, social connection, and motivation; unhealthy pursuit of pleasure without regard for consequences.
46. **Joy:** Play, expression, bonding, enthusiasm, and shared experiences.
47. **Hope:** Persistence, recovery, innovation, and willingness to pursue difficult goals; misplaced hope and unrealistic expectations.
48. **Fear:** Hazard recognition, caution, and self-preservation; panic, repression, prejudice, and manipulation.
49. **Anger:** Recognition of violations, motivation for resistance, and boundary enforcement; aggression, retaliation, and violence.
50. **Sadness:** Response to loss, reflection, and opportunities for support; withdrawal, suffering, and social disconnection.
51. **Grief:** Mourning, remembrance, cultural rituals, and adaptation to loss; prolonged suffering and social isolation.
52. **Shame:** Can discourage misconduct; can also produce humiliation, secrecy, self-contempt, and social control.
53. **Guilt:** Recognition of wrongdoing and motivation to repair harm; excessive guilt or guilt deliberately imposed by manipulators.
54. **Pride:** Achievement, dignity, confidence, and belonging; arrogance, superiority, and refusal to acknowledge errors.
55. **Envy:** Awareness of unequal outcomes and motivation for improvement; resentment and destructive comparison.
56. **Jealousy:** Fear of losing valued relationships or status; possessiveness, suspicion, and controlling behavior.
57. **Greed:** Can motivate accumulation and economic activity; drives exploitation, corruption, hoarding, and destructive acquisition.
58. **Ambition:** Achievement, innovation, leadership, and advancement; ruthlessness and disregard for others.
59. **Curiosity:** Discovery, experimentation, learning, and exploration; reckless investigation and boundary violations.
60. **Courage:** Resistance to injustice, protection, and risk-taking; recklessness when detached from judgment.
61. **Cowardice:** Avoidance of danger; can enable injustice through refusal to intervene.
62. **Resentment:** Recognition of perceived mistreatment; prolonged hostility and retaliatory behavior.
63. **Revenge:** A desire for retaliation that influences social behavior, conflict, law, and moral codes; perpetuates cycles of harm.
64. **Forgiveness:** Reconciliation, personal recovery, and restoration; can be pressured or exploited when accountability is absent.
65. **Loyalty:** Trust, solidarity, commitment, and resilience; favoritism, concealment of wrongdoing, and blind allegiance.
66. **Betrayal:** Violates trust, alters alliances, and reshapes relationships and institutions.
67. **Desire:** Motivates connection, consumption, creativity, achievement, and change; fuels obsession and exploitation.
68. **Lust:** Sexual attraction and human bonding; can contribute to objectification or misconduct when boundaries are disregarded.
69. **Loneliness:** Creates demand for friendship, community, companionship, and belonging; increases vulnerability to isolation and exploitation.
70. **Boredom:** Can stimulate creativity, experimentation, and exploration; can encourage destructive entertainment and impulsivity.
71. **Disgust:** Helps people avoid biological hazards; can be weaponized to stigmatize groups.
72. **Awe:** Inspires scientific inquiry, spirituality, art, and humility; can facilitate uncritical devotion.
73. **Wonder:** Exploration, imagination, and meaning-making.
74. **Humor:** Connection, relief, social criticism, bonding, and entertainment; ridicule, bullying, dehumanization, and humiliation.
75. **Sarcasm:** Social commentary, humor, resistance, and indirect communication; contempt, hostility, and deliberate ambiguity.
76. **Irony:** Highlights contradictions and generates humor, criticism, and cultural meaning; can obscure intent.
77. **Embarrassment:** Encourages awareness of social expectations; can suppress participation and experimentation.
78. **Admiration:** Mentorship, learning, aspiration, and recognition; celebrity worship and uncritical imitation.
79. **Contempt:** Social condemnation of perceived wrongdoing; dehumanization, hostility, and exclusion.
80. **Indifference:** Can permit tolerance and coexistence; can also enable cruelty through neglect.
81. **Desperation:** Motivates survival and extraordinary action; increases vulnerability to coercion and harmful decisions.
82. **Trust:** Enables nearly every form of cooperation; creates vulnerability to fraud and betrayal.
83. **Suspicion:** Supports threat detection and scrutiny; can undermine cooperation or become paranoia.
84. **Faith:** Sustains purpose, solidarity, and endurance; can become dogmatism or facilitate exploitation.
85. **Doubt:** Encourages scrutiny, self-correction, and intellectual humility; excessive doubt can paralyze action.
86. **Optimism:** Sustains motivation and collective ambition; can create complacency toward risks.
87. **Pessimism:** Encourages caution and preparation; can undermine initiative and hope.
88. **Self-interest:** Supports self-preservation, autonomy, and initiative; can conflict with collective welfare.
89. **Altruism:** Supports charity, sacrifice, cooperation, and public service; can be exploited by those who take without reciprocating.
90. **The desire for belonging:** Creates communities, friendships, and shared identity; can produce conformity, tribalism, and exclusion.
## 4. Cognition, perception, and personal judgment
91. **Reason:** Supports coherent decisions and problem-solving; can be used to rationalize harmful objectives.
92. **Logic:** Enables consistent conclusions and disciplined analysis; can be misapplied when premises are false.
93. **Intuition:** Allows rapid judgment from experience; can perpetuate bias and error.
94. **Memory:** Preserves learning, identity, relationships, and history; can distort, deteriorate, or become unreliable.
95. **Imagination:** Enables invention, storytelling, planning, and artistic expression; can produce unfounded beliefs and fears.
96. **Attention:** Directs learning, relationships, and productivity; is vulnerable to manipulation and distraction.
97. **Perception:** Determines what people notice and how they experience events; is incomplete and susceptible to distortion.
98. **Interpretation:** Converts observations into personal meaning; can produce understanding or serious misunderstanding.
99. **Language comprehension:** Makes communication possible; semantic ambiguity creates conflict and manipulation opportunities.
100. **Beliefs:** Organize identity, decisions, and behavior; false beliefs can sustain harmful systems.
101. **Values:** Guide choices, priorities, morality, and institutions; conflicting values generate disputes.
102. **Bias:** Simplifies rapid judgment but can create prejudice, discrimination, and unjust decisions.
103. **Heuristics:** Make everyday decisions manageable; can produce predictable reasoning errors.
104. **Assumptions:** Allow action under incomplete information; unexamined assumptions produce mistakes and systemic failures.
105. **Stereotypes:** Simplify perceptions of groups; reduce individuals to inaccurate generalizations.
106. **Confirmation bias:** Reinforces existing beliefs and can obstruct corrective evidence.
107. **Cognitive dissonance:** Can motivate reassessment or rationalization when beliefs conflict with actions.
108. **Self-deception:** Protects a person's self-image at the possible expense of accuracy and accountability.
109. **Denial:** Can temporarily buffer overwhelming experiences; can obstruct recognition of urgent problems.
110. **Adaptation:** Enables survival and learning under changing conditions; can normalize harmful environments.
111. **Habits:** Create efficiency, stability, and consistency; can preserve destructive routines.
112. **Discipline:** Supports long-term goals and reliability; can become oppressive rigidity.
113. **Impulse:** Enables spontaneous action and creativity; can undermine long-term consequences.
114. **Risk tolerance:** Supports experimentation and enterprise; can expose others to unacceptable danger.
115. **Critical thinking:** Challenges misinformation, unsupported claims, and institutional failures; can be misused as reflexive contrarianism.
116. **Self-awareness:** Supports correction, personal development, and responsibility; can become excessive self-preoccupation.
117. **Personal identity:** Provides continuity, purpose, and self-definition; can become a source of rigid exclusion.
118. **Free choice and agency:** Enable autonomy and responsibility; are constrained by coercion, resources, information, and circumstances.
119. **Meaning and purpose:** Sustain motivation, resilience, and coordinated effort; destructive ideologies can also supply purpose.
120. **Mortality awareness:** Shapes long-term priorities, legacy, spirituality, ambition, and the meaning people assign to life.
## 5. Human interaction
121. **Conversation:** Shares information, develops relationships, resolves problems; can spread lies, hostility, and confusion.
122. **Listening:** Creates understanding and cooperation; selective listening distorts communication.
123. **Asking questions:** Enables clarification, discovery, and accountability; can become interrogation or harassment.
124. **Honesty:** Sustains trust and informed choice; can be expressed cruelly or without appropriate consideration.
125. **Dishonesty:** Conceals truth, manipulates decisions, and can temporarily protect a person from danger or retaliation.
126. **Promises:** Enable coordination and long-term commitments; broken promises destroy confidence.
127. **Commitment:** Supports stable relationships, projects, and institutions; can trap people in harmful arrangements.
128. **Consent:** Makes legitimate voluntary interaction possible; coercion and disregard for consent create serious harm.
129. **Respect:** Supports dignity, coexistence, and conflict resolution; demands for respect can be used to suppress dissent.
130. **Boundaries:** Protect autonomy, safety, and identity; can be misrepresented or weaponized to avoid responsibility.
131. **Cooperation:** Makes shared work, caregiving, and civilization possible; can coordinate harmful collective action.
132. **Competition:** Encourages innovation, effort, performance, and choice; can produce exclusion, sabotage, and exploitation.
133. **Compromise:** Resolves disagreements and enables pluralism; may preserve injustice when basic rights are bargained away.
134. **Negotiation:** Helps distribute resources and settle conflicts; can be distorted by unequal power.
135. **Conflict:** Can expose legitimate grievances and force change; can also destroy relationships and institutions.
136. **Apologies:** Acknowledge wrongdoing and facilitate repair; can be insincere or used to evade meaningful accountability.
137. **Accountability:** Connects decisions to consequences; can become selective punishment or scapegoating.
138. **Reciprocity:** Encourages repeated cooperation and mutual support; can create transactional obligations and coercive expectations.
139. **Generosity:** Redistributes resources and strengthens communities; can encourage dependency when poorly structured.
140. **Hospitality:** Welcomes strangers and supports cultural exchange; can expose hosts or guests to exploitation.
141. **Friendship:** Provides emotional support, companionship, assistance, and shared history; may also enable harmful group behavior.
142. **Mentorship:** Transfers expertise, experience, and opportunity; creates risks of dependency and abuse of authority.
143. **Leadership:** Coordinates people toward goals; can become manipulation or domination.
144. **Followership:** Makes collective action possible; can become unquestioning obedience.
145. **Persuasion:** Changes beliefs through argument and communication; can become coercive manipulation.
146. **Charisma:** Inspires participation and trust; can substitute personal appeal for evidence and competence.
147. **Social influence:** Spreads behavior, norms, and information; can normalize harmful practices.
148. **Peer pressure:** Encourages participation and conformity; can suppress independence.
149. **Imitation:** Enables learning and cultural transmission; spreads mistakes, prejudice, and destructive trends.
150. **Social comparison:** Supplies benchmarks and motivation; creates insecurity, status anxiety, and resentment.
## 6. Reputation, status, and social positioning
151. **Reputation:** Supports trust and accountability; can be destroyed by misinformation.
152. **Status:** Organizes recognition and informal hierarchy; creates privilege and social exclusion.
153. **Prestige:** Rewards admired achievement or service; can elevate appearances over substance.
154. **Honor:** Encourages fidelity to commitments and moral codes; can motivate vengeance and coercion.
155. **Social approval:** Reinforces prosocial behavior; can produce conformity and dishonesty.
156. **Social rejection:** Establishes group boundaries; can lead to isolation, discrimination, and humiliation.
157. **Popularity:** Connects influential people and spreads information; can distort judgments of merit.
158. **Celebrity:** Creates cultural influence, artistic opportunity, and public attention; encourages parasocial dependence and unearned authority.
159. **Personal branding:** Communicates identity, skills, and achievements; can reward exaggeration and performance over competence.
160. **Self-promotion:** Makes accomplishments visible; can become boastfulness, fraud, or attention manipulation.
161. **Modesty:** Can promote humility and openness; can also inhibit deserved recognition.
162. **Confidence:** Encourages initiative and leadership; can become overconfidence.
163. **Arrogance:** Can project certainty and authority while obstructing learning and cooperation.
164. **Humility:** Encourages correction and respect for limits; can be falsely performed for social advantage.
165. **Networking:** Creates opportunities, knowledge exchange, and cooperation; can reinforce exclusivity and favoritism.
166. **Gatekeeping:** Can maintain legitimate standards and safety; can exclude capable people to preserve privilege.
167. **Favoritism:** Benefits preferred individuals but undermines equal treatment and merit.
168. **Nepotism:** Strengthens family opportunity and loyalty while undermining fair access and institutional integrity.
169. **Gossip:** Circulates social information and informal warnings; spreads rumors and damages reputations.
170. **Rumors:** Transmit unverified information quickly; may expose genuine concerns or cause widespread misinformation.
171. **Ridicule:** Can challenge arrogance and authority; can also punish difference, vulnerability, and unconventional approaches.
172. **Public shaming:** Can expose misconduct; can create disproportionate punishment, harassment, and irreversible reputational damage.
173. **Praise:** Reinforces useful achievements and positive behavior; can become flattery or manipulation.
174. **Flattery:** Can ease interactions but can also manufacture trust or influence.
175. **Social hierarchy:** Coordinates some responsibilities and expertise; can entrench unjust power.
176. **Social mobility:** Enables changes in social and economic standing; may be blocked by inherited disadvantage.
177. **Recognition:** Gives contributors acknowledgment and social standing; selective recognition can erase others' labor.
178. **Social capital:** Converts relationships and trust into cooperation and opportunity; unequal networks can reproduce inequality.
## 7. Family, intimacy, and domestic life
179. **Family:** Provides identity, support, care, stability, and inheritance; can also perpetuate conflict, control, abuse, and inequality.
180. **Parenthood:** Raises and prepares future generations; can involve neglect, coercion, favoritism, and harmful expectations.
181. **Marriage:** Establishes recognized personal, legal, economic, and emotional commitments; can involve unequal power and coercive dependence.
182. **Partnerships:** Provide intimacy, cooperation, shared resources, and companionship; can involve manipulation and betrayal.
183. **Dating and courtship:** Facilitate romantic relationships and partner selection; can involve dishonesty, rejection, coercion, and exploitation.
184. **Divorce and separation:** Allow people to leave harmful or incompatible relationships; can produce financial hardship, conflict, and disruption.
185. **Childrearing:** Transmits practical skills, behavioral expectations, values, and traditions; can transmit prejudice and generational trauma.
186. **Adoption:** Provides family relationships and care; requires safeguards against coercion, trafficking, and institutional failures.
187. **Foster care:** Protects children when families cannot provide safe care; can suffer instability, neglect, or inadequate oversight.
188. **Extended families:** Supply childcare, caregiving, financial support, and cultural continuity; can create obligations and generational disputes.
189. **Chosen families:** Provide belonging and mutual support beyond biological kinship; can face legal or social exclusion.
190. **Household labor:** Cooking, cleaning, laundry, scheduling, and maintenance sustain daily life; unequal distribution creates invisible burdens.
191. **Unpaid caregiving:** Supports children, older adults, sick people, and disabled people; can impose economic and emotional hardship on caregivers.
192. **Emotional labor:** Maintains relationships and social functioning; can become an unrecognized or unfairly assigned obligation.
193. **Domestic authority:** Coordinates household decisions; can become domination or coercive control.
194. **Household finances:** Pool income, manage expenses, and create financial security; can generate conflict, dependency, and financial abuse.
195. **Inheritance:** Transfers wealth, property, and cultural assets between generations; can reinforce inequality and family conflict.
196. **Family traditions:** Preserve identity, memory, and belonging; may perpetuate harmful expectations.
197. **Intergenerational knowledge:** Transfers skills and wisdom; can also reproduce outdated assumptions.
198. **Domestic conflict:** Can expose important disagreements; unresolved conflict can harm household stability.
199. **Domestic violence:** Creates fear, injury, coercion, and long-term harm.
200. **Child abuse:** Damages safety, development, health, and trust.
201. **Elder abuse:** Exploits physical, social, and financial vulnerability.
202. **Family reconciliation:** Repairs relationships and restores cooperation where safe and voluntary.
203. **Family estrangement:** Can protect people from harmful relationships; can also create grief and isolation.
204. **Household routines:** Provide predictability, security, and stability; excessive rigidity can suppress autonomy.
205. **Pets and companion animals:** Provide affection, care, companionship, and social connections; neglect and irresponsible ownership create harm.
## 8. Community, neighborhood, and local networks
206. **Neighbors:** Offer mutual assistance, familiarity, local knowledge, and informal safety; can also create disputes and harassment.
207. **Neighborhood identity:** Creates belonging and solidarity; can foster territorial exclusion.
208. **Mutual aid:** Shares labor, supplies, money, and assistance during hardship.
209. **Volunteering:** Supports institutions, emergency response, and vulnerable community members.
210. **Charity:** Transfers resources toward identified needs; may be undermined by dependency, fraud, or inadequate structural reform.
211. **Community organizing:** Mobilizes residents to improve shared conditions; can also be used for exclusionary causes.
212. **Civic associations:** Coordinate local priorities and public participation.
213. **Religious congregations:** Provide support networks, worship, charity, identity, and gathering places; may also become sites of exclusion or abuse.
214. **Social clubs:** Develop friendships, hobbies, knowledge, and informal networks; may encourage exclusivity.
215. **Neighborhood businesses:** Provide employment, services, relationships, and local economic circulation.
216. **Informal commerce:** Enables small-scale earning, barter, and access; can lack worker protections and consumer safeguards.
217. **Street vendors:** Supply accessible goods and entrepreneurship; can encounter exploitation and unfair regulation.
218. **Public markets:** Facilitate trade, social contact, and local economic activity.
219. **Parks and public spaces:** Enable recreation, civic gathering, exercise, and informal interaction; can suffer neglect or exclusion.
220. **Libraries:** Provide knowledge, public resources, literacy, digital access, and community participation.
221. **Community centers:** Offer education, recreation, support services, and safe gathering places.
222. **Youth organizations:** Provide mentorship, identity, and constructive opportunities; inadequate supervision can create vulnerabilities.
223. **Sports leagues:** Encourage health, teamwork, community pride, and recreation; can foster rivalry or exclusion.
224. **Neighborhood watch programs:** Encourage cooperation and safety awareness; can produce profiling and vigilantism.
225. **Local customs:** Coordinate everyday expectations; may perpetuate prejudice or exclusion.
226. **Town meetings:** Provide public participation and accountability; can be dominated by organized interests.
227. **Local journalism:** Exposes public problems and connects residents; may suffer bias, inadequate funding, or commercial pressure.
228. **Community reputation:** Influences trust, business, relationships, and opportunity; can be damaged by gossip and prejudice.
229. **Local disputes:** Include noise, parking, property boundaries, animals, safety, and shared resources.
230. **Mediation:** Helps resolve conflict without escalation; requires legitimacy and voluntary participation.
231. **Community policing:** Can strengthen relationships and problem-solving; can also become intrusive or discriminatory.
232. **Neighborhood maintenance:** Clean streets, functional lighting, safe sidewalks, landscaping, and building upkeep preserve quality of life.
233. **Local festivals:** Reinforce culture, economic activity, and social connection.
234. **Community remembrance:** Memorials, funerals, anniversaries, and commemorations preserve shared history.
235. **Local political relationships:** Connect residents to decisions about services, land, schools, and taxation; can become patronage networks.
236. **Local solidarity:** Helps communities survive hardship; can become hostility toward outsiders.
## 9. Economic forces
237. **Scarcity:** Forces societies to prioritize needs and allocate finite resources; creates competition and deprivation.
238. **Abundance:** Improves access, security, and opportunity; can encourage waste and complacency.
239. **Supply:** Determines the availability of goods, labor, capital, and services; shortages disrupt life.
240. **Demand:** Directs production and investment; can also support harmful industries and unsustainable consumption.
241. **Prices:** Coordinate information about scarcity and purchasing decisions; may exclude those unable to pay.
242. **Money:** Facilitates exchange, accounting, saving, and coordination; creates opportunities for manipulation and fraud.
243. **Currency:** Provides a shared medium of exchange and store of value; inflation and instability can undermine confidence.
244. **Banking:** Supports deposits, payments, lending, and investment; can generate systemic financial risks.
245. **Credit:** Makes future income available for present needs and investment; can produce debt traps.
246. **Debt:** Finances homes, education, infrastructure, and enterprise; can become a tool of dependence and exploitation.
247. **Interest:** Prices lending risk and the use of capital; can become predatory.
248. **Saving:** Provides resilience and finances future investment; unequal savings capacity reinforces inequality.
249. **Investment:** Funds innovation, productive capacity, and long-term development; can support speculative bubbles or destructive ventures.
250. **Capital:** Enables production, infrastructure, and enterprise; concentrated ownership can amplify unequal influence.
251. **Assets:** Store wealth and productive value; unequal ownership can reinforce social stratification.
252. **Property:** Establishes control, stewardship, and economic security; can create exclusion and dispossession.
253. **Ownership rights:** Support investment and personal independence; can conflict with public needs or other rights.
254. **Contracts:** Enable enforceable commitments and predictable transactions; unfair terms can institutionalize exploitation.
255. **Markets:** Coordinate decentralized production and exchange; can fail through monopoly, externalities, fraud, or unequal bargaining power.
256. **Competition:** Encourages efficiency, innovation, and consumer choice; can lead to destructive cost-cutting.
257. **Monopolies:** Can achieve certain economies of scale; can suppress competition, raise prices, and entrench control.
258. **Oligopolies:** Concentrate market power among a few firms; can facilitate coordination or anticompetitive behavior.
259. **Cartels:** Coordinate suppliers, usually at the expense of competitive pricing and consumer welfare.
260. **Cooperatives:** Distribute ownership and decision-making among members; require effective shared governance.
261. **Public enterprises:** Provide services and manage strategic assets; may suffer inefficiency, political interference, or inadequate oversight.
262. **Private enterprises:** Mobilize investment, organize production, and compete; can place profit above other interests.
263. **Profit:** Rewards successful enterprise and investment; can incentivize harmful shortcuts.
264. **Loss:** Signals unsuccessful resource allocation; can destroy livelihoods and communities.
265. **Wages:** Compensate labor and support household survival; can be suppressed or withheld.
266. **Taxes:** Finance public services and shared infrastructure; can be inequitable, misused, or poorly designed.
267. **Subsidies:** Support targeted services, innovation, agriculture, and strategic industries; can encourage dependency and favoritism.
268. **Government spending:** Funds healthcare, education, defense, infrastructure, and public administration; can be wasteful or corrupt.
269. **Public debt:** Finances investment and stabilizes economies; can constrain future budgets.
270. **Inflation:** Changes purchasing power and redistributes economic burdens; severe inflation damages planning and savings.
271. **Deflation:** Changes purchasing incentives and debt burdens; prolonged deflation can suppress economic activity.
272. **Insurance:** Pools risk and supports recovery; can suffer denial practices, fraud, and unequal access.
273. **Pensions:** Provide retirement income and intergenerational security; can face underfunding and inequity.
274. **Financial markets:** Move capital and distribute investment risk; enable speculation and systemic contagion.
275. **Stock markets:** Finance corporations and permit ownership transfers; can encourage short-termism and manipulation.
276. **Bonds:** Finance government and corporate obligations; create repayment and default risks.
277. **Derivatives:** Hedge financial exposure; can increase leverage and complexity.
278. **Real estate markets:** Allocate land and buildings; can encourage speculation, displacement, and housing insecurity.
279. **Advertising:** Connects buyers with products and funds media; can manipulate demand and promote harmful consumption.
280. **Consumer spending:** Sustains businesses and employment; can generate overconsumption, debt, and waste.
281. **Entrepreneurship:** Creates businesses, employment, innovation, and services; involves uncertainty and potential exploitation.
282. **Economic development:** Expands productive capacity and living standards; can leave groups behind or damage ecosystems.
283. **Global capital flows:** Fund international investment and development; can transmit crises and facilitate capital flight.
284. **Wealth concentration:** Can accumulate large investment capacity; can magnify inequality and political influence.
285. **Economic redistribution:** Can reduce deprivation and expand opportunity; requires effective design, legitimacy, and administration.
## 10. Work, production, and employment
286. **Human labor:** Produces goods, services, knowledge, care, and infrastructure; can be exploited or undervalued.
287. **Employment:** Provides income, structure, participation, and skill development; can create dependence and insecurity.
288. **Self-employment:** Supports autonomy and enterprise; exposes individuals to unstable income and risk.
289. **Unemployment:** Reduces income and economic participation; can produce hardship and social instability.
290. **Underemployment:** Wastes productive capacity and can prevent adequate earnings.
291. **Skilled trades:** Construction, repair, electrical work, plumbing, mechanics, and specialized production maintain everyday civilization.
292. **Professional services:** Legal, accounting, engineering, consulting, design, and other expertise support institutions and commerce.
293. **Service workers:** Retail, food service, hospitality, transportation, cleaning, and personal services sustain daily social activity.
294. **Care workers:** Support children, patients, older adults, and disabled people; frequently face difficult conditions or inadequate compensation.
295. **Agricultural workers:** Sustain food production; face seasonal insecurity, physical hazards, and labor exploitation.
296. **Manufacturing workers:** Produce essential goods and industrial materials; face automation, workplace hazards, and economic displacement.
297. **Construction workers:** Build homes, hospitals, roads, utilities, and public spaces; face dangerous working conditions.
298. **Public employees:** Administer essential services and institutions; can encounter political interference and bureaucratic constraints.
299. **Military personnel:** Provide national defense and emergency capabilities; may experience injury, trauma, or involvement in unjust operations.
300. **Emergency responders:** Protect life and property under dangerous conditions; face fatigue, trauma, and institutional failures.
301. **Educators:** Transfer knowledge and support development; face resource shortages and political pressures.
302. **Scientists and researchers:** Expand knowledge and practical capabilities; can face conflicts of interest or misuse of discoveries.
303. **Artists and creators:** Produce cultural value, identity, and entertainment; often face insecure compensation.
304. **Managers:** Allocate work, coordinate resources, and establish priorities; may abuse authority.
305. **Executives:** Direct major institutions and resource allocation; can become detached from consequences.
306. **Business owners:** Organize enterprises and bear certain commercial risks; may exploit workers or consumers.
307. **Labor unions:** Coordinate collective bargaining and worker protection; can suffer corruption or rigid practices.
308. **Collective bargaining:** Balances employer and worker power; can generate costly disputes.
309. **Strikes:** Provide leverage against unfair conditions; can disrupt essential services and livelihoods.
310. **Workplace culture:** Shapes cooperation, safety, and performance; can normalize harassment, discrimination, or overwork.
311. **Productivity:** Increases output per unit of input; excessive pressure can damage safety and wellbeing.
312. **Efficiency:** Reduces waste and resource use; excessive optimization can eliminate necessary resilience.
313. **Automation:** Reduces repetitive labor and increases productive capacity; can displace jobs and concentrate ownership.
314. **Outsourcing:** Provides specialization and cost efficiencies; can weaken accountability and labor protections.
315. **Global supply chains:** Connect specialized producers across borders; create dependencies and vulnerability to disruption.
316. **Apprenticeships:** Transfer practical expertise across generations.
317. **Training:** Improves competence, safety, and adaptability.
318. **Credentials:** Signal documented education or competence; can become exclusionary barriers.
319. **Merit-based advancement:** Can reward ability and performance; depends on fair measurement and opportunity.
320. **Workplace discrimination:** Excludes individuals on irrelevant characteristics and wastes human potential.
321. **Workplace harassment:** Undermines safety, dignity, and participation.
322. **Wage theft:** Illegally deprives workers of earned compensation.
323. **Forced labor:** Extracts work through coercion and violates fundamental rights.
324. **Child labor:** Can deny education and expose children to exploitation and harm.
325. **Occupational safety:** Prevents injury and death; failures create preventable suffering.
326. **Burnout:** Results from prolonged unmanaged workplace stress and can damage performance and health.
327. **Professional ethics:** Guide responsible service and accountability; can be compromised by conflicts of interest.
328. **Institutional memory:** Preserves expertise, decisions, and lessons; its loss causes repeated mistakes.
329. **Maintenance labor:** Keeps existing systems functioning even when it creates no visible new product.
330. **Invisible labor:** Includes cleaning, sanitation, caregiving, administration, and other easily overlooked work.
## 11. Organizations and institutions
331. **Corporations:** Pool resources and coordinate economic activity; may concentrate power or externalize harm.
332. **Small businesses:** Provide local opportunity and specialized services; face financial vulnerability.
333. **Nonprofits:** Pursue social, educational, humanitarian, or other missions; require funding and accountability.
334. **Foundations:** Finance research, education, arts, and public purposes; can concentrate private influence.
335. **Cooperatives and mutual organizations:** Organize shared ownership, services, and risk.
336. **Professional associations:** Establish standards, knowledge exchange, and professional identity; can restrict entry.
337. **Trade associations:** Represent industry interests; may support standards or lobby for special privileges.
338. **Universities:** Produce research, education, and credentials; can reproduce social inequalities.
339. **Hospitals:** Coordinate medical expertise and resources; can suffer unequal access and institutional failures.
340. **Religious institutions:** Organize faith, charity, education, and community; can exert excessive social control.
341. **Political parties:** Organize electoral competition and collective political action; can encourage factional loyalty.
342. **Civil society organizations:** Mobilize public participation and advocacy; may be vulnerable to donor influence.
343. **Charitable networks:** Direct money and resources toward needs; require oversight.
344. **Bureaucracies:** Provide repeatable administration and institutional continuity; can become rigid or unresponsive.
345. **Hierarchies:** Define authority and responsibility; can enable domination.
346. **Delegation:** Distributes decisions and work; can obscure responsibility.
347. **Specialization:** Increases expertise and productivity; creates dependencies and institutional silos.
348. **Coordination:** Aligns people, resources, and timing; failures create duplication and conflict.
349. **Organizational incentives:** Shape what employees actually do, sometimes differently from stated institutional goals.
350. **Institutional legitimacy:** Sustains public cooperation and confidence; its loss can undermine social stability.
## 12. Infrastructure, settlement, and public services
351. **Housing:** Provides shelter, security, identity, and family stability; unaffordability, unsafe buildings, and displacement create harm.
352. **Renting:** Allows access to housing without ownership; creates exposure to eviction, rising costs, and unequal bargaining power.
353. **Homeownership:** Builds housing stability and potential wealth; creates debt obligations and market exposure.
354. **Homelessness services:** Provide shelter, food, outreach, and assistance; inadequate capacity leaves people exposed to danger.
355. **Urban planning:** Coordinates land use, growth, public space, and infrastructure; can create segregation or displacement.
356. **Zoning:** Separates incompatible uses and organizes development; can restrict housing supply or reinforce exclusion.
357. **Building codes:** Reduce risks from fires, structural failures, and unsafe construction; may be poorly enforced.
358. **Roads:** Connect people, goods, workplaces, and institutions; create accident risks, pollution, and maintenance demands.
359. **Bridges:** Connect communities and economic regions; deteriorating structures can create catastrophic failures.
360. **Railroads:** Move people and goods efficiently over large distances; require significant maintenance and investment.
361. **Public transit:** Expands mobility and economic participation; inadequate access isolates communities.
362. **Private vehicles:** Provide personal mobility and economic access; contribute to congestion, crashes, emissions, and spatial inequality.
363. **Bicycles and micromobility:** Offer accessible transportation; require safe infrastructure and coexistence with other road users.
364. **Sidewalks and pedestrian networks:** Make communities navigable; neglect limits mobility and accessibility.
365. **Airports:** Enable international travel, trade, and emergency transport; create environmental and security challenges.
366. **Ports:** Support maritime commerce and supply chains; can become bottlenecks and pollution centers.
367. **Warehouses:** Store goods and stabilize distribution; require land, energy, and labor.
368. **Delivery networks:** Connect businesses and households; create safety, labor, and logistical challenges.
369. **Water treatment:** Protects populations from contamination and disease; failures threaten entire communities.
370. **Sewage systems:** Prevent exposure to human waste and pathogens; failures cause disease and pollution.
371. **Waste collection:** Removes refuse and protects sanitation; poor management causes environmental and health hazards.
372. **Recycling:** Recovers useful materials; can be undermined by contamination, poor economics, and misleading claims.
373. **Electric grids:** Distribute power to nearly every modern service; outages can cascade across industries.
374. **Power generation:** Supplies electricity from diverse technologies; involves different costs, risks, and environmental impacts.
375. **Telecommunications:** Enable interpersonal communication, commerce, and emergencies; can be disrupted or surveilled.
376. **Internet infrastructure:** Supports digital communication, computing, information, and services; introduces cyber and concentration risks.
377. **Postal systems:** Move documents, packages, medicines, and official communications; support access where digital alternatives are insufficient.
378. **Public lighting:** Improves visibility and navigation; carries energy costs and environmental effects.
379. **Fire protection:** Prevents and responds to destructive fires; inadequate coverage increases loss of life and property.
380. **Emergency medical services:** Provide rapid medical response; availability and timeliness affect survival.
381. **Emergency dispatch:** Coordinates police, fire, and medical responses; communication failures can be fatal.
382. **Civil engineering:** Designs and maintains built environments; mistakes can create systemic hazards.
383. **Public procurement:** Acquires infrastructure, equipment, and services; can be compromised by corruption or waste.
384. **Maintenance budgets:** Preserve existing assets; chronic underfunding causes deterioration.
385. **Accessibility infrastructure:** Enables disabled people to participate in public life; its absence creates exclusion.
386. **Public restrooms:** Support sanitation, dignity, health, and participation in public spaces.
387. **Street cleaning:** Maintains sanitation, drainage, public appearance, and basic livability.
388. **Public records:** Preserve ownership, births, deaths, licenses, decisions, and obligations.
389. **Addressing and mapping:** Make emergency response, deliveries, navigation, and administration possible.
390. **Standards and interoperability:** Allow different technologies, services, and institutions to work together.
391. **Redundancy:** Provides backup capacity when systems fail; requires additional resources.
392. **Disaster-resistant design:** Reduces damage from predictable environmental hazards.
393. **Infrastructure cybersecurity:** Protects essential services from digital disruption and sabotage.
## 13. Agriculture, food systems, and material production
394. **Farming:** Supplies food and raw materials; can degrade land or depend on exploitative labor.
395. **Livestock production:** Provides food, materials, and income; raises animal welfare, disease, and environmental concerns.
396. **Fisheries:** Supply food and employment; face overexploitation and ecosystem damage.
397. **Aquaculture:** Expands seafood production; can produce pollution and disease risks.
398. **Food processing:** Improves preservation, safety, convenience, and distribution; can enable unhealthy products or contamination.
399. **Food preservation:** Reduces spoilage and increases security through storage, refrigeration, freezing, and fermentation.
400. **Cold chains:** Protect temperature-sensitive food and medicine; failures can destroy essential supplies.
401. **Agricultural research:** Improves crop resilience, productivity, and nutrition; requires safeguards against ecological or economic harm.
402. **Seeds and breeding:** Preserve and improve agricultural production; concentrated control can create dependency.
403. **Irrigation:** Stabilizes food production; can deplete water resources and damage soils.
404. **Fertilizers:** Improve agricultural yields; excessive use can pollute waterways and damage ecosystems.
405. **Pest control:** Protects crops and public health; improper methods can harm humans and wildlife.
406. **Food safety inspection:** Reduces contamination, fraud, and illness; failures endanger consumers.
407. **Food distribution:** Connects farms, processors, merchants, and households; disruptions cause shortages.
408. **Grocery stores:** Provide essential consumer access; location and pricing affect food security.
409. **Restaurants:** Provide meals, employment, hospitality, culture, and gathering spaces; require food safety and labor protections.
410. **Food assistance:** Reduces hunger and supports vulnerable households; depends on funding, access, and effective administration.
411. **Food waste:** Represents lost resources and unnecessary environmental costs; reduction improves efficiency.
412. **Strategic reserves:** Provide emergency supplies during shortages and disasters; can be mismanaged or hoarded.
413. **Commodity trading:** Coordinates agricultural and raw-material markets; can amplify speculation and price volatility.
414. **Resource extraction:** Supplies minerals, fuel, timber, and construction materials; may cause ecological harm and exploit communities.
415. **Manufacturing:** Converts raw materials into useful goods; can produce pollution, dangerous workplaces, and waste.
416. **Quality assurance:** Detects defects and protects consumers; failures can propagate throughout supply chains.
417. **Industrial safety:** Prevents chemical accidents, explosions, equipment failures, and occupational injury.
## 14. Healthcare, public health, and social protection
418. **Hospitals and clinics:** Diagnose and treat illness; uneven access creates preventable harm.
419. **Primary care:** Provides prevention, screening, diagnosis, and continuity of treatment.
420. **Emergency medicine:** Responds to acute illness and injury; capacity constraints affect outcomes.
421. **Surgery:** Treats injuries and disease; involves procedural risks and access inequality.
422. **Pharmaceuticals:** Prevent and treat disease; create challenges involving affordability, safety, misuse, and supply.
423. **Vaccination:** Reduces infectious disease burden; requires safe systems and public trust.
424. **Public health surveillance:** Detects disease patterns and outbreaks; must balance health protection with privacy and civil liberties.
425. **Epidemiology:** Studies disease distribution and supports public health intervention.
426. **Medical research:** Produces treatments, diagnostics, and knowledge; requires protection of research participants.
427. **Clinical trials:** Evaluate interventions; can become unethical without informed consent and oversight.
428. **Medical ethics:** Protects autonomy, dignity, safety, and fair treatment.
429. **Mental healthcare:** Supports psychological wellbeing and treatment; barriers and stigma restrict access.
430. **Addiction treatment:** Helps individuals recover from substance-use and behavioral disorders; can be undermined by insufficient access and stigma.
431. **Harm reduction:** Seeks to reduce preventable injury and death; faces political and implementation disputes.
432. **Disability services:** Support independence, accessibility, education, employment, and care.
433. **Rehabilitation:** Restores or develops physical, cognitive, and functional capabilities.
434. **Long-term care:** Supports people with continuing assistance needs; faces staffing and quality challenges.
435. **Hospice and palliative care:** Relieve suffering and preserve dignity during serious illness and end-of-life care.
436. **Maternal healthcare:** Protects health during pregnancy, childbirth, and recovery.
437. **Reproductive healthcare:** Supports fertility, contraception, pregnancy care, and reproductive health decisions.
438. **Infant healthcare:** Protects early development and survival.
439. **Preventive medicine:** Reduces future illness through screening, education, and intervention.
440. **Dental care:** Protects oral health, nutrition, communication, and general wellbeing.
441. **Vision and hearing care:** Support communication, learning, mobility, and independence.
442. **Health insurance:** Helps finance medical treatment; coverage gaps and administrative burdens can obstruct care.
443. **Public healthcare financing:** Pools resources to support access; requires sustainable funding and effective administration.
444. **Social security:** Provides income protection during retirement, disability, or qualifying hardship.
445. **Unemployment assistance:** Stabilizes households during job loss.
446. **Disability benefits:** Support individuals whose circumstances restrict earning capacity.
447. **Child welfare services:** Protect children and support families; may cause harm through inappropriate intervention or neglect.
448. **Elder services:** Assist aging populations with housing, food, healthcare, mobility, and protection.
449. **Public sanitation:** Prevents the spread of illness through clean water, hygiene, and waste management.
450. **Occupational health:** Protects workers against physical, chemical, biological, and psychological hazards.
451. **Pandemic preparedness:** Coordinates surveillance, medical supplies, emergency response, and international cooperation.
452. **Health misinformation:** Distorts risk perceptions and can undermine effective treatment and prevention.
453. **Medical discrimination:** Creates unequal treatment based on identity, income, disability, or other irrelevant characteristics.
454. **Medical negligence:** Produces preventable harm through failures of professional care.
455. **Patient advocacy:** Helps people understand choices and exercise their rights.
456. **Care coordination:** Connects specialists, caregivers, records, and services to avoid dangerous fragmentation.
457. **Healthcare supply chains:** Provide medicine, equipment, blood products, and protective materials.
458. **Biosecurity:** Reduces the risks of dangerous biological agents and misuse of biotechnology.
## 15. Knowledge, science, and discovery
459. **Observation:** Produces evidence about the world; can be incomplete or misinterpreted.
460. **Measurement:** Makes comparisons and verification possible; can create false certainty when metrics are inadequate.
461. **Evidence:** Supports warranted beliefs and accountable decisions; can be fabricated, selectively presented, or misunderstood.
462. **Scientific methods:** Enable systematic testing and correction; are limited by study design, data, and interpretation.
463. **Experiments:** Test causal claims and practical interventions; require ethical safeguards.
464. **Replication:** Tests whether findings withstand independent examination.
465. **Peer review:** Scrutinizes research before publication; can suffer bias, inconsistency, or conflicts of interest.
466. **Scientific criticism:** Identifies defects and improves understanding; can become obstruction or personal hostility.
467. **Academic freedom:** Protects inquiry and disagreement; requires responsibility and institutional safeguards.
468. **Open science:** Expands access to research and methods; must address privacy, security, and misuse risks.
469. **Intellectual property:** Rewards certain creative and technical contributions; can restrict access and follow-on innovation.
470. **Patents:** Provide time-limited legal protection for inventions; can generate monopolistic costs or strategic litigation.
471. **Copyright:** Protects original creative works; can create access and reuse restrictions.
472. **Open source:** Enables collaboration, inspection, modification, and shared development; can suffer abandonment, vulnerabilities, or exploitation of maintainers.
473. **Standards development:** Coordinates interoperability, safety, and quality; can become dominated by powerful interests.
474. **Engineering:** Applies knowledge to solve practical problems; design failures can scale harm.
475. **Innovation:** Creates new capabilities and solutions; can disrupt employment, safety, and established protections.
476. **Invention:** Produces new tools, methods, and systems; outcomes depend on use and governance.
477. **Technological diffusion:** Spreads productive innovations; also spreads harmful capabilities.
478. **Traditional knowledge:** Preserves ecological, agricultural, medicinal, and cultural practices; can be exploited or dismissed.
479. **Historical knowledge:** Provides perspective and helps identify recurring patterns; can be distorted or suppressed.
480. **Archives:** Preserve records, memory, and evidence; their destruction damages collective understanding.
481. **Libraries and repositories:** Preserve and distribute accumulated human knowledge.
482. **Translation:** Enables cooperation across languages; mistakes can transform meaning and obligations.
483. **Interdisciplinary cooperation:** Connects specialized knowledge; organizational boundaries can obstruct it.
484. **Uncertainty:** Encourages careful judgment when acknowledged; becomes dangerous when concealed.
485. **Error correction:** Allows individuals and institutions to improve; depends on openness to criticism.
## 16. Education, learning, and socialization
486. **Literacy:** Enables written communication, informed participation, and access to knowledge.
487. **Numeracy:** Supports financial decisions, measurement, reasoning, and practical independence.
488. **Early childhood education:** Builds foundational learning and social capabilities.
489. **Primary education:** Develops essential knowledge and skills.
490. **Secondary education:** Expands academic, technical, social, and civic preparation.
491. **Higher education:** Develops specialized expertise and research capabilities; can become financially exclusionary.
492. **Vocational education:** Prepares people for practical occupations and skilled trades.
493. **Adult education:** Supports career transitions, literacy, and lifelong development.
494. **Informal learning:** Transfers knowledge through observation, conversation, play, and experience.
495. **Self-education:** Enables independent learning; requires access to reliable information.
496. **Teachers:** Guide learning, assessment, and development; poor instruction or abuse of authority causes harm.
497. **Students:** Learn, challenge assumptions, create new knowledge, and become future contributors.
498. **Curricula:** Organize educational priorities; can omit perspectives or embed political bias.
499. **Examinations:** Assess certain forms of knowledge and performance; can encourage teaching to tests.
500. **Grades:** Communicate evaluations of achievement; can distort motivation or overlook capabilities.
501. **Educational credentials:** Signal preparation and achievement; can become substitutes for demonstrated competence.
502. **School discipline:** Supports safe learning environments; can become arbitrary or discriminatory.
503. **Special education:** Provides individualized support; requires inclusion and appropriate resources.
504. **Civic education:** Teaches institutions, rights, responsibilities, and public participation.
505. **Media literacy:** Develops the ability to evaluate sources, persuasion, and misinformation.
506. **Digital literacy:** Enables effective and safe participation in technological society.
507. **Financial literacy:** Improves understanding of income, debt, saving, and economic decisions.
508. **Sex education:** Provides knowledge about reproduction, health, consent, and relationships; poor instruction can leave harmful gaps.
509. **Parent education:** Supports caregiving and child development.
510. **Knowledge inequality:** Creates differences in opportunity, power, health, and participation.
511. **Indoctrination:** Promotes beliefs through methods that suppress independent examination.
512. **Censorship of education:** Restricts what people are allowed to learn or question.
## 17. Culture, religion, philosophy, and human expression
513. **Culture:** Provides shared practices, meanings, values, and identities; can preserve harmful norms.
514. **Language:** Enables thought, communication, law, trade, and identity; language barriers can exclude people.
515. **Dialect and slang:** Establish belonging and express cultural identity; can create misunderstanding across groups.
516. **Symbols:** Compress complex ideas into recognizable forms; can be used for solidarity or intimidation.
517. **Stories:** Transfer values, experience, and knowledge; can spread false narratives.
518. **Myths:** Give communities shared meaning and identity; can obscure factual history.
519. **Legends:** Preserve cultural narratives and moral examples; can distort historical understanding.
520. **Folklore:** Transmits collective memory, entertainment, and tradition.
521. **Religion:** Provides worship, ethical traditions, purpose, identity, and community; can be used to justify discrimination or coercion.
522. **Spirituality:** Provides reflection, personal meaning, connection, and practices for coping with uncertainty.
523. **Secular worldviews:** Provide ethical and philosophical approaches independent of religion; can also become dogmatic.
524. **Philosophy:** Examines knowledge, reality, morality, society, and existence.
525. **Ethics:** Guides judgments about right and wrong; competing ethical systems can produce disagreement.
526. **Morality:** Shapes behavior and social expectations; can become selective, hypocritical, or coercive.
527. **Conscience:** Encourages personal accountability and resistance to wrongdoing.
528. **Rituals:** Reinforce identity, transitions, shared values, and social cohesion; can become exclusionary or coercive.
529. **Ceremonies:** Publicly recognize commitments, achievements, relationships, and loss.
530. **Holidays:** Coordinate celebration, remembrance, rest, religion, and commercial activity.
531. **Traditions:** Preserve knowledge and continuity; can resist necessary change.
532. **Customs:** Organize social expectations; may differ profoundly across communities.
533. **Etiquette:** Reduces social friction and communicates respect; can reinforce class boundaries.
534. **Taboos:** Protect some cultural or moral boundaries; can stigmatize legitimate behavior or prevent open discussion.
535. **Fashion:** Expresses identity, creativity, status, and belonging; can fuel waste, exclusion, and insecurity.
536. **Beauty standards:** Influence aesthetics, relationships, industries, and self-perception; can reinforce discrimination.
537. **Art:** Communicates human experience, challenges authority, and creates meaning.
538. **Music:** Supports bonding, ritual, emotion, protest, entertainment, and cultural continuity.
539. **Dance:** Expresses identity, celebration, physical connection, and culture.
540. **Literature:** Preserves stories, challenges ideas, and explores human experience.
541. **Theater:** Provides storytelling, performance, criticism, and collective experience.
542. **Film and television:** Entertain, inform, and influence social narratives; can reinforce stereotypes or misinformation.
543. **Comedy:** Questions conventions, entertains, and exposes contradictions; can also normalize cruelty.
544. **Satire:** Uses humor and exaggeration to criticize institutions and behavior; can be mistaken for literal claims.
545. **Sports:** Promote skill, health, teamwork, competition, identity, and entertainment; can foster corruption, exclusion, and violence.
546. **Games:** Develop strategy, play, learning, and social bonding; may encourage compulsive behavior or exploitation.
547. **Nightlife:** Supports entertainment, relationships, employment, and cultural exchange; can involve violence, substance misuse, and exploitation.
548. **Festivals:** Generate shared experiences, community participation, and economic activity.
549. **Tourism:** Encourages cultural exchange and commerce; can produce overcrowding, displacement, and environmental damage.
550. **Museums:** Preserve and interpret cultural and scientific heritage; may face disputes involving ownership or representation.
551. **Monuments:** Preserve memory and civic identity; can also perpetuate exclusionary historical narratives.
552. **Cultural preservation:** Protects languages, artifacts, traditions, and heritage.
553. **Cultural appropriation disputes:** Concern ownership, representation, exploitation, and exchange across cultural boundaries.
554. **Counterculture:** Challenges dominant norms and creates alternatives; can produce valuable reform or destructive extremism.
555. **Subcultures:** Provide identity and belonging for communities with shared interests.
556. **Social movements:** Coordinate collective action to change society; can pursue emancipatory or oppressive goals.
557. **Public intellectual life:** Sustains debate about science, morality, philosophy, governance, and culture.
## 18. Information, media, and digital life
558. **Information:** Reduces uncertainty and supports decisions; unreliable information produces errors.
559. **Communication networks:** Connect people and organizations; can transmit abuse and misinformation.
560. **Journalism:** Investigates events, holds institutions accountable, and informs the public; can suffer bias or economic pressure.
561. **Investigative reporting:** Exposes hidden misconduct and systemic failures.
562. **Editorial judgment:** Selects which information receives attention; can create omissions and distorted priorities.
563. **Freedom of expression:** Enables criticism, creativity, and disagreement; can coexist with harmful speech and serious social conflict.
564. **Freedom of the press:** Protects independent scrutiny; may be threatened by censorship, intimidation, and economic control.
565. **Censorship:** Can restrict harmful material in certain circumstances; can also silence dissent and suppress truth.
566. **Propaganda:** Shapes beliefs and behavior through strategically selected information, often at the expense of accuracy.
567. **Disinformation:** Deliberately spreads false or misleading information.
568. **Misinformation:** Spreads false information without necessarily requiring deceptive intent.
569. **Malinformation:** Uses genuine information in contexts intended to cause harm, such as malicious disclosure of private details.
570. **Conspiracy narratives:** Can reflect genuine distrust or suspicions; unsupported claims can undermine institutions and social relations.
571. **Public relations:** Communicates organizational messages; can become reputation management that conceals misconduct.
572. **Marketing:** Connects products and services with audiences; can manipulate insecurities and attention.
573. **Mass media:** Creates large shared information environments; may concentrate narrative power.
574. **Social media:** Enables connection, organization, creativity, and information exchange; can amplify harassment and misinformation.
575. **Online communities:** Support collaboration and belonging; can foster exclusion, radicalization, or abuse.
576. **Memes:** Compress social meaning, humor, identity, and criticism into easily shared formats; can also become instruments of ridicule and dehumanization.
577. **Virality:** Rapidly spreads information and culture; can amplify falsehoods or reputational harm.
578. **Recommendation algorithms:** Help users discover information; may reinforce narrow perspectives or addictive engagement.
579. **Search engines:** Organize access to information; rankings influence visibility and understanding.
580. **Digital platforms:** Connect users, creators, customers, and service providers; may concentrate market power.
581. **Online marketplaces:** Facilitate trade across distances; enable fraud and counterfeit distribution.
582. **Digital payments:** Increase transaction convenience; introduce privacy, fraud, and access risks.
583. **Electronic identity:** Supports authentication and service delivery; requires safeguards against exclusion and misuse.
584. **Cybersecurity:** Protects systems, people, assets, and information.
585. **Cybercrime:** Uses digital systems for fraud, theft, coercion, and disruption.
586. **Phishing:** Exploits trust and deception to obtain credentials or money.
587. **Identity theft:** Misuses personal information for unauthorized gain.
588. **Data privacy:** Protects control over personal information; privacy breaches enable exploitation.
589. **Data collection:** Supports research, services, security, and personalization; can enable surveillance and manipulation.
590. **Surveillance:** Can support security and legitimate investigation; can become pervasive social control.
591. **Encryption:** Protects confidentiality and information integrity; can also conceal unlawful activity.
592. **Digital accessibility:** Enables participation by people with different physical and cognitive needs.
593. **Software:** Automates processes throughout society; defects and insecure designs can propagate harm.
594. **Open digital protocols:** Enable interoperable systems and broad participation.
595. **Cloud computing:** Provides scalable computing infrastructure; creates dependency on providers and networks.
596. **Data centers:** Support computation and digital services; consume power, water, materials, and capital.
597. **Semiconductors:** Enable nearly all modern electronics and advanced computation; create strategic supply dependencies.
598. **Artificial intelligence:** Supports research, creation, automation, analysis, and accessibility; creates risks involving misuse, bias, concentration, and reliability.
599. **AI agents:** Coordinate multi-step tasks and tools; require authorization, boundaries, monitoring, and accountability.
600. **Machine learning:** Identifies patterns and supports predictions; can reproduce errors or biases in data.
601. **Robotics:** Performs physical tasks in industry, medicine, logistics, and homes; creates safety and labor implications.
602. **Digital surveillance economies:** Monetize behavioral information and attention; can undermine privacy and autonomy.
603. **Attention economies:** Convert human attention into commercial value; can encourage sensationalism and compulsive engagement.
604. **Content moderation:** Addresses abuse and harmful material; can become inconsistent or suppress legitimate expression.
605. **Algorithmic governance:** Uses automated systems to influence decisions; can make discrimination or error difficult to challenge.
606. **Digital public infrastructure:** Supports identification, payments, records, and government services; failures can exclude large populations.
607. **Technology governance:** Sets boundaries for the design and deployment of consequential systems.
608. **Digital dependency:** Increases convenience and productivity while exposing society to outages, attacks, and concentration risks.
## 19. Government, politics, and civic coordination
609. **Government:** Coordinates public functions and collective decisions; can also concentrate power and inflict harm.
610. **Democracy:** Gives people mechanisms to influence government; can suffer manipulation, exclusion, and institutional weakness.
611. **Representative government:** Delegates political decisions to elected officials; can create distance between citizens and decision-makers.
612. **Direct democracy:** Allows citizens to vote on particular policies; can be vulnerable to misinformation and majority domination.
613. **Constitutional government:** Establishes legal authority, institutional boundaries, and fundamental protections.
614. **Authoritarian government:** Concentrates political control, often restricting dissent, accountability, and civil liberties.
615. **Monarchy:** Organizes political authority through hereditary institutions; legitimacy and accountability vary greatly across systems.
616. **Federalism:** Divides authority across levels of government; can protect regional autonomy but produce jurisdictional conflict.
617. **Local self-government:** Gives communities authority over nearby public concerns; can be limited by resources or unequal local power.
618. **Elections:** Provide mechanisms for political selection and accountability; can be manipulated or undermined.
619. **Voting:** Expresses political preferences; can be constrained by disenfranchisement or distorted by unfair systems.
620. **Political representation:** Connects populations to government decisions; unequal representation weakens legitimacy.
621. **Political parties:** Organize electoral coalitions and policy priorities; can encourage excessive partisanship.
622. **Political ideologies:** Supply coherent visions of social organization; can become intolerant or dogmatic.
623. **Conservatism:** Often emphasizes continuity, established institutions, and cautious change; can also resist necessary reform.
624. **Liberalism:** Often emphasizes liberty, rights, and individual autonomy; different forms prioritize markets, equality, and institutions differently.
625. **Socialism:** Emphasizes varying forms of collective ownership, economic equality, and social provision; implementations differ in liberty, effectiveness, and governance.
626. **Capitalism:** Organizes much production through private ownership and markets; can produce growth alongside inequality and concentrated power.
627. **Nationalism:** Can foster collective identity and self-determination; can become exclusionary or aggressive.
628. **Populism:** Mobilizes perceived conflicts between ordinary people and elites; can reveal neglected grievances or undermine institutions.
629. **Coalition building:** Connects groups with shared objectives; can require difficult compromises.
630. **Political compromise:** Enables decisions amid disagreement; can dilute important protections.
631. **Public participation:** Expands opportunities to influence institutions.
632. **Petitions:** Organize formal requests for change.
633. **Protests:** Express collective grievances and demand accountability; may generate disruption or confrontation.
634. **Civil disobedience:** Challenges perceived injustice through deliberate lawbreaking; carries legal and social consequences.
635. **Political dissent:** Questions official decisions and dominant views; can be punished by repressive authorities.
636. **Activism:** Organizes social and political change; can pursue beneficial or harmful objectives.
637. **Lobbying:** Communicates interests to government; can create disproportionate access for wealthy groups.
638. **Campaign finance:** Funds political participation; can amplify donor influence.
639. **Political patronage:** Exchanges opportunities or resources for political support; can undermine merit and fairness.
640. **Political polarization:** Sharpens ideological divisions; can reduce cooperation and increase hostility.
641. **Partisanship:** Organizes political commitments; excessive partisanship can override independent judgment.
642. **Public administration:** Implements government programs and services; can suffer inefficiency or corruption.
643. **Public budgeting:** Determines how shared resources are collected and distributed.
644. **Public consultation:** Allows communities to contribute to policy design; can become symbolic without meaningful influence.
645. **Regulation:** Establishes behavioral standards and safeguards; can become excessive, ineffective, or captured by regulated interests.
646. **Deregulation:** Removes legal restrictions; can encourage activity or eliminate necessary safeguards.
647. **Regulatory capture:** Allows regulated interests to influence institutions meant to oversee them.
648. **Transparency:** Makes actions and decisions visible; can conflict with legitimate privacy and security needs.
649. **Official secrecy:** Protects some sensitive information; can conceal misconduct.
650. **Public accountability:** Requires decision-makers to answer for the use of power.
651. **Auditing:** Examines records, performance, compliance, and resource use; can become superficial or compromised.
652. **Whistleblowing:** Exposes wrongdoing or dangerous practices; can subject individuals to retaliation.
653. **Political corruption:** Diverts authority and resources toward improper private or factional benefit.
654. **Checks and balances:** Reduce the risk of unchecked authority.
655. **Institutional independence:** Protects functions such as adjudication, oversight, and research from improper interference.
656. **Public trust:** Encourages voluntary cooperation with legitimate institutions; deteriorates when promises and performance diverge.
657. **Crisis governance:** Coordinates emergency decisions under pressure; can justify excessive concentration of authority.
658. **State capacity:** Determines whether governments can deliver services, maintain order, and carry out lawful decisions.
659. **Government failure:** Occurs when institutions cannot or do not fulfill essential responsibilities.
## 20. Law, justice, rights, and enforcement
660. **Rule of law:** Requires authority to operate under publicly applicable legal standards; unequal enforcement undermines it.
661. **Constitutions:** Establish foundational structures, rights, and limits on government.
662. **Legislation:** Creates binding public rules; can protect people or institutionalize injustice.
663. **Judicial interpretation:** Determines how laws apply to particular disputes and circumstances.
664. **Courts:** Resolve disputes and adjudicate legal claims; can suffer delay, bias, and corruption.
665. **Judges:** Apply and interpret law; require competence and independence.
666. **Juries:** Provide public participation in legal decision-making; can be affected by prejudice or incomplete evidence.
667. **Lawyers:** Represent clients and navigate legal systems; unequal access affects outcomes.
668. **Legal aid:** Provides representation to people who cannot otherwise afford it.
669. **Due process:** Protects against arbitrary deprivation of rights and liberty.
670. **Presumption of innocence:** Places the burden of proving criminal guilt on the prosecution.
671. **Evidence rules:** Guide the reliability and admissibility of information in legal proceedings.
672. **Criminal law:** Defines offenses and sanctions; can deter wrongdoing or be used abusively.
673. **Civil law:** Resolves disputes involving rights, obligations, property, and compensation.
674. **Administrative law:** Governs the exercise and review of public administrative authority.
675. **Constitutional law:** Establishes and interprets limits on state power.
676. **Family law:** Governs legally recognized family relationships, responsibilities, and disputes.
677. **Contract law:** Supports enforceable private agreements.
678. **Property law:** Establishes recognized rights concerning ownership and possession.
679. **Labor law:** Governs employment relationships, compensation, organizing, and workplace protections.
680. **Environmental law:** Restricts pollution and harmful resource practices.
681. **Consumer protection law:** Addresses fraud, unsafe products, and unfair commercial practices.
682. **Competition law:** Restricts anticompetitive conduct and abuse of market power.
683. **Privacy law:** Defines protections involving personal information and private life.
684. **Immigration law:** Governs entry, residence, and related legal status.
685. **International law:** Establishes obligations and frameworks among states and other international actors.
686. **Human rights:** Recognize fundamental protections and freedoms; violations undermine dignity and security.
687. **Civil liberties:** Protect expression, belief, association, privacy, and other freedoms.
688. **Equal protection:** Requires lawful and justifiable treatment without prohibited discrimination.
689. **Religious freedom:** Protects belief, worship, and nonbelief; can generate disputes over competing rights.
690. **Freedom of association:** Enables unions, civic organizations, political parties, and communities.
691. **Rights of children:** Protect development, safety, education, and welfare.
692. **Disability rights:** Protect equal participation, accessibility, and freedom from discrimination.
693. **Victims' rights:** Recognize the interests and protections of people harmed by offenses.
694. **Self-defense:** Allows proportionate protection against unlawful threats within applicable legal limits.
695. **Policing:** Enforces law and responds to public safety concerns; can involve misconduct, discrimination, or excessive force.
696. **Prosecution:** Brings criminal charges on behalf of the state; must guard against wrongful accusations.
697. **Criminal defense:** Protects due process and challenges the state's evidence.
698. **Sentencing:** Determines legal consequences for convictions; may be disproportionate or discriminatory.
699. **Prisons:** Confine individuals under legal authority; create substantial risks involving abuse, overcrowding, and failed rehabilitation.
700. **Probation and parole:** Supervise individuals in the community; can support reintegration or create burdensome restrictions.
701. **Rehabilitation programs:** Address behaviors and circumstances associated with repeated offending.
702. **Restorative justice:** Seeks accountability and repair through approaches involving affected parties where appropriate.
703. **Wrongful convictions:** Deprive innocent people of liberty and undermine confidence in justice.
704. **Selective enforcement:** Applies rules inconsistently based on power, identity, or favoritism.
705. **Judicial corruption:** Substitutes improper influence for impartial legal judgment.
706. **Civil remedies:** Provide compensation, injunctions, and other forms of relief.
707. **Appeals:** Permit review of legal decisions and correction of errors.
708. **Legal precedent:** Supports consistency over time; can preserve flawed interpretations.
709. **Legal reform:** Changes rules and institutions to address deficiencies.
710. **Access to justice:** Determines whether legal protections are practically available, not merely written down.
## 21. Safety, force, conflict, and organized violence
711. **Public safety:** Protects life, property, and communities from preventable harm.
712. **Crime prevention:** Reduces opportunities and incentives for harmful conduct; can become intrusive if poorly designed.
713. **Emergency response:** Mobilizes assistance during danger and disasters.
714. **Intelligence gathering:** Identifies threats and supports security decisions; risks violating privacy and civil liberties.
715. **Counterintelligence:** Detects and limits hostile espionage or infiltration.
716. **National defense:** Protects sovereignty and populations against external threats.
717. **Military preparedness:** Provides deterrence and response capability; can fuel arms races.
718. **Deterrence:** Discourages aggression through credible consequences; can fail through miscalculation.
719. **Arms control:** Seeks limits and safeguards for dangerous weapons.
720. **Disarmament:** Reduces certain categories of weapons or military capabilities.
721. **Military alliances:** Coordinate defense and security; can create obligations and geopolitical tensions.
722. **War:** Reshapes territory, institutions, populations, and economies through organized violence and destruction.
723. **Civil war:** Creates internal armed conflict, institutional collapse, and widespread civilian suffering.
724. **Insurgency:** Challenges established authority through organized resistance, sometimes involving violence against civilians.
725. **Revolution:** Can overturn oppressive systems; can also create violence, instability, and new oppression.
726. **Coups:** Replace political leadership outside ordinary constitutional processes; undermine legitimate transitions.
727. **Terrorism:** Uses violence or threats to intimidate populations or advance political objectives.
728. **War crimes:** Violate the laws governing armed conflict.
729. **Genocide:** Intentionally destroys, in whole or in part, protected national, ethnic, racial, or religious groups.
730. **Ethnic cleansing:** Forcibly removes populations from particular territories.
731. **Mass atrocities:** Cause systematic or widespread serious harm to civilians.
732. **Torture:** Inflicts severe suffering and violates fundamental protections.
733. **Political imprisonment:** Uses detention to suppress dissent or political opposition.
734. **Hostage-taking:** Coerces individuals or institutions through unlawful detention.
735. **Human shields:** Place civilians in danger to influence military operations.
736. **Cyberwarfare:** Uses digital operations to disrupt or compromise adversarial systems.
737. **Information warfare:** Manipulates information environments during political or military conflict.
738. **Economic warfare:** Uses economic pressure to weaken an adversary.
739. **Sanctions enforcement:** Restricts designated activity or actors; can impose unintended humanitarian costs.
740. **Peace negotiations:** Seek agreements to end or prevent violence.
741. **Ceasefires:** Suspend fighting under agreed conditions; can fail without credible implementation.
742. **Peacekeeping:** Attempts to stabilize conflict-affected areas and protect civilians under defined mandates.
743. **Postwar reconstruction:** Rebuilds institutions, homes, infrastructure, and livelihoods.
744. **Transitional justice:** Addresses past abuses through prosecution, truth-seeking, reparations, or reform.
745. **Veterans' services:** Support people affected by military service.
746. **Civilian protection:** Seeks to prevent harm to noncombatants during conflict.
747. **Security-sector oversight:** Holds police, military, and intelligence institutions accountable.
## 22. International relationships and global interdependence
748. **Nation-states:** Organize political communities, territorial authority, law, and international relationships.
749. **Sovereignty:** Establishes authority over territory and domestic affairs; can conflict with external obligations and human rights concerns.
750. **Diplomacy:** Manages relations through negotiation and communication.
751. **Embassies and consulates:** Represent governments and assist citizens abroad.
752. **Treaties:** Create formal international commitments.
753. **International organizations:** Coordinate countries around common interests and obligations; may suffer political deadlock.
754. **The United Nations:** Provides forums and institutions for diplomacy, development, humanitarian coordination, and international security.
755. **Regional organizations:** Coordinate neighboring states around trade, security, standards, and political concerns.
756. **International courts:** Address specified disputes and offenses under their jurisdictions.
757. **Global trade:** Exchanges goods, resources, and services across borders; creates mutual dependence and distributional conflicts.
758. **Trade agreements:** Define commercial conditions between states.
759. **Tariffs:** Influence trade, domestic production, and public revenue; can raise consumer costs or provoke retaliation.
760. **Trade restrictions:** Protect selected interests or pursue strategic objectives; can disrupt supplies.
761. **International monetary systems:** Coordinate cross-border exchange, finance, and payment.
762. **Reserve currencies:** Support international settlements and financial reserves; confer significant influence on issuing economies.
763. **Foreign exchange markets:** Determine currency conversion and transmit financial conditions.
764. **Cross-border banking:** Moves finance internationally; creates regulatory and contagion risks.
765. **Sovereign debt:** Finances governments and influences geopolitical relationships; can produce crises and dependency.
766. **International investment:** Funds businesses, infrastructure, and development; can create political or economic vulnerabilities.
767. **Multinational corporations:** Coordinate production and commerce across countries; can circumvent weaker protections.
768. **Development assistance:** Supports infrastructure, health, education, and economic development; may create dependency or reflect donor interests.
769. **Humanitarian assistance:** Supplies food, shelter, medicine, and protection during emergencies.
770. **Disaster relief cooperation:** Mobilizes resources across borders following major disasters.
771. **Migration:** Redistributes labor, knowledge, populations, and culture; creates integration and administrative challenges.
772. **Immigration:** Changes the demographic and economic composition of receiving societies.
773. **Emigration:** Moves people and skills away from their countries of origin.
774. **Refugees:** Require protection when fleeing persecution, conflict, or other qualifying threats.
775. **Asylum:** Provides legal protection under applicable standards.
776. **Diasporas:** Maintain cultural, economic, and family connections across countries.
777. **Remittances:** Transfer income from migrants to households and communities abroad.
778. **Border administration:** Regulates cross-border movement; can create humanitarian and civil-rights concerns.
779. **International tourism:** Promotes trade and cultural exchange; can strain communities and ecosystems.
780. **Cultural diplomacy:** Builds relationships through arts, education, language, and exchange.
781. **Scientific cooperation:** Shares expertise and research across national boundaries.
782. **International education:** Moves students, researchers, and knowledge between countries.
783. **Global health cooperation:** Coordinates information, medicine, preparedness, and outbreak responses.
784. **International environmental agreements:** Seek common responses to cross-border ecological problems.
785. **International cybersecurity cooperation:** Addresses cybercrime, digital threats, and security standards.
786. **Maritime law:** Governs significant rights and obligations involving the world's oceans.
787. **Freedom of navigation:** Supports commerce and mobility through lawful sea routes.
788. **Global telecommunications standards:** Enable international communication and interoperability.
789. **International aviation rules:** Coordinate safe aircraft operations across jurisdictions.
790. **Supply-chain interdependence:** Connects specialized industries and countries; creates vulnerabilities when critical suppliers fail.
791. **Strategic resource dependence:** Shapes international bargaining around energy, water, minerals, agriculture, and technology.
792. **Geopolitical competition:** Drives military, economic, scientific, and technological rivalry.
793. **Geopolitical cooperation:** Coordinates shared interests, including security, health, trade, and environmental protection.
794. **Colonialism:** Historically reorganized territory, labor, wealth, and institutions through external domination and extraction.
795. **Decolonization:** Establishes or restores political self-determination and challenges colonial arrangements.
796. **Imperialism:** Extends power or influence over other peoples or territories.
797. **Global inequality:** Produces disparities in wealth, opportunity, security, and institutional capacity across countries.
798. **International solidarity:** Supports cooperation and assistance across national boundaries.
799. **Transnational activism:** Coordinates social movements and political advocacy internationally.
800. **Cross-border corruption:** Diverts resources and influences governments through international networks.
801. **Global financial crime:** Includes illicit financial transfers, laundering, and fraud across jurisdictions.
802. **Global security threats:** Include war, weapons proliferation, pandemics, cyberattacks, and environmental crises.
## 23. Population, identity, and social stratification
803. **Population size:** Determines the scale of labor, consumption, public services, and resource demand.
804. **Population growth:** Can expand productive capacity and social diversity; can strain infrastructure and ecosystems when poorly managed.
805. **Population decline:** Can reduce some resource pressures; can shrink workforces and threaten institutional sustainability.
806. **Fertility rates:** Influence future generations, labor supply, education systems, and public spending.
807. **Life expectancy:** Reflects survival and health conditions; unequal life expectancy reveals social disparities.
808. **Urbanization:** Concentrates opportunity, infrastructure, and cultural exchange; can increase congestion, housing costs, and inequality.
809. **Rural life:** Supports agriculture, natural-resource management, and distinct communities; can face geographic isolation and service shortages.
810. **Population density:** Enables efficient service delivery and proximity; can intensify housing and infrastructure demands.
811. **Household composition:** Influences care arrangements, finances, housing, and intergenerational support.
812. **Generational differences:** Introduce new expectations, technologies, and values; can produce misunderstanding and conflict.
813. **Age hierarchies:** Recognize experience and developmental responsibility; can justify exclusion or paternalism.
814. **Race:** A socially consequential classification that has shaped identity, institutions, law, and unequal treatment.
815. **Ethnicity:** Preserves shared ancestry, culture, and identity; can become a basis for exclusion or conflict.
816. **Caste:** Organizes inherited social status in certain societies; can institutionalize severe inequality.
817. **Social class:** Influences wealth, employment, education, networks, and opportunity.
818. **Economic mobility:** Allows changes in material circumstances; may be restricted by inherited disadvantage.
819. **Gender:** Shapes identity, relationships, cultural expectations, and institutional participation.
820. **Gender roles:** Organize some social expectations and divisions of responsibility; can restrict individual freedom.
821. **Sexual orientation:** Influences intimacy, relationships, and identity; can become a basis for discrimination.
822. **Religious identity:** Provides belonging, meaning, and cultural continuity; can become a target or instrument of intolerance.
823. **National identity:** Connects people through citizenship, culture, or shared political history; can become exclusionary.
824. **Language identity:** Preserves heritage and cultural participation; language barriers can restrict access to services.
825. **Indigenous identity:** Preserves histories, communities, knowledge, and relationships with land; is affected by dispossession and discrimination.
826. **Disability status:** Shapes encounters with accessibility, healthcare, employment, and public services.
827. **Citizenship:** Establishes legal membership and associated rights and obligations; exclusion from citizenship can create vulnerability.
828. **Legal residency:** Determines access to work, services, and protections under applicable laws.
829. **Socioeconomic privilege:** Creates unequal access to resources, networks, security, and institutional influence.
830. **Inherited advantage:** Transfers assets, education, relationships, and opportunity across generations.
831. **Inherited disadvantage:** Transmits material deprivation, barriers, and exposure to harmful conditions.
832. **Segregation:** Separates populations through law, policy, economics, or social practice; can entrench inequality.
833. **Residential exclusion:** Restricts access to desirable or affordable neighborhoods.
834. **Educational inequality:** Produces unequal opportunities to develop knowledge and capabilities.
835. **Healthcare inequality:** Produces different access to treatment and health outcomes.
836. **Employment discrimination:** Restricts fair access to work and advancement.
837. **Racism:** Produces unequal treatment and hostility based on racial classifications.
838. **Sexism:** Produces unequal treatment based on sex or gender.
839. **Ableism:** Devalues or excludes people based on disability.
840. **Ageism:** Discriminates on the basis of age.
841. **Xenophobia:** Generates hostility toward foreigners or perceived outsiders.
842. **Religious intolerance:** Restricts or threatens people because of their beliefs or nonbelief.
843. **Homophobia and transphobia:** Generate stigma, exclusion, and hostility toward sexual and gender minorities.
844. **Colorism:** Creates unequal treatment based on differences in skin tone.
845. **Class prejudice:** Assigns social worth or competence based on economic position.
846. **Intersectional disadvantage:** Describes overlapping forms of exclusion or unequal treatment.
847. **Affirmative remedies:** Seek to address documented exclusion; require fair implementation and public accountability.
848. **Equal opportunity:** Seeks access to participation without unjustified barriers.
849. **Social inclusion:** Expands belonging, accessibility, and participation across differences.
850. **Social exclusion:** Denies individuals or groups meaningful participation in institutions and communities.
## 24. Environmental stewardship and long-term continuity
851. **Biodiversity:** Supports food systems, ecosystems, medicines, and resilience; biodiversity loss weakens these foundations.
852. **Ecosystem services:** Include pollination, water filtration, carbon storage, nutrient cycling, and natural hazard protection.
853. **Habitat conservation:** Protects species and ecological functions; competes with certain development and extraction demands.
854. **Wildlife protection:** Reduces preventable species loss and ecological damage.
855. **Animal welfare:** Addresses unnecessary suffering and treatment of animals.
856. **Sustainable agriculture:** Seeks food production without destroying future productive capacity.
857. **Regenerative practices:** Seek restoration of soil, ecosystems, and environmental function.
858. **Pollution prevention:** Reduces harmful releases into air, water, and soil.
859. **Environmental monitoring:** Detects ecological changes, contamination, and emerging risks.
860. **Climate mitigation:** Reduces the drivers of climate change.
861. **Climate adaptation:** Prepares communities for changes and hazards already occurring or expected.
862. **Energy transition:** Changes energy systems toward alternative technologies; creates economic, employment, and supply-chain challenges.
863. **Decarbonization:** Reduces greenhouse gas emissions from energy, industry, transport, and other activities.
864. **Carbon markets:** Create financial mechanisms involving emissions or removals; can suffer verification and integrity problems.
865. **Environmental justice:** Examines unequal exposure to pollution and environmental hazards.
866. **Resource conservation:** Preserves materials and natural assets for continued use.
867. **Circular economies:** Seek reuse, repair, recycling, and reduced material waste.
868. **Ecological restoration:** Repairs degraded landscapes and ecosystems.
869. **Reforestation:** Restores tree cover under appropriate ecological conditions.
870. **Ocean conservation:** Protects marine habitats, fisheries, and ecological processes.
871. **Plastic pollution:** Damages ecosystems and creates long-term waste-management challenges.
872. **Chemical pollution:** Can contaminate organisms and environments across generations.
873. **Freshwater security:** Determines whether communities and ecosystems have reliable access to usable water.
874. **Environmental displacement:** Forces relocation when environmental conditions become dangerous or unsustainable.
875. **Disaster resilience:** Allows communities to absorb shocks, respond, and recover.
876. **Early warning systems:** Detect threats and provide time for protective action.
877. **Critical infrastructure resilience:** Prevents individual failures from cascading across dependent services.
878. **Food-system resilience:** Maintains nutrition and supply despite disruptions.
879. **Public health resilience:** Supports continued healthcare and outbreak response under extreme conditions.
880. **Economic resilience:** Enables households, businesses, and institutions to withstand shocks.
881. **Intergenerational equity:** Considers the effects of current decisions on people not yet born.
882. **Long-term stewardship:** Maintains resources, knowledge, infrastructure, and institutions beyond current leadership.
883. **Nuclear safety:** Prevents radioactive releases, accidents, and serious technological disasters.
884. **Nuclear weapons risks:** Threaten mass destruction and long-lasting humanitarian consequences.
885. **Biological security:** Reduces risks from dangerous pathogens and biotechnology misuse.
886. **Advanced technology safety:** Addresses emerging risks from powerful and potentially difficult-to-control systems.
887. **Planetary defense:** Develops capabilities to identify and mitigate dangerous near-Earth objects.
888. **Civilizational continuity:** Concerns the survival of humanity's accumulated capabilities, relationships, institutions, and knowledge.
## 25. Exploitation, deception, coercion, and illicit power
889. **Organized crime:** Coordinates unlawful activities through structured networks and influence.
890. **Criminal gangs:** Exercise territorial, economic, or interpersonal control through intimidation and illegal activity.
891. **Black markets:** Exchange prohibited or restricted goods and services outside lawful channels.
892. **Smuggling:** Moves goods or people outside applicable legal requirements.
893. **Human trafficking:** Exploits people through force, fraud, coercion, or other legally recognized means.
894. **Sex trafficking:** Involves commercial sexual exploitation under circumstances defined by applicable law.
895. **Child sexual exploitation:** Abuses children for sexual purposes and causes serious harm.
896. **Commercial sex markets:** Include different legal and social arrangements involving consensual adult activity, alongside serious risks of exploitation, coercion, and abuse.
897. **Labor trafficking:** Extracts labor or services through prohibited forms of coercion.
898. **Debt bondage:** Uses debt obligations to impose exploitative restrictions on freedom.
899. **Modern slavery:** Encompasses severe forms of coercion, exploitation, and deprivation of liberty.
900. **Drug trafficking:** Distributes controlled substances unlawfully through networks that can involve violence and corruption.
901. **Substance misuse:** Can contribute to illness, injury, addiction, financial hardship, and social disruption.
902. **Illicit arms trading:** Supplies weapons outside lawful controls, including to violent actors.
903. **Counterfeiting:** Misrepresents goods, currency, credentials, or intellectual property.
904. **Fraud:** Obtains benefit through intentional deception.
905. **Embezzlement:** Misappropriates entrusted property or funds.
906. **Money laundering:** Conceals the unlawful origins or ownership of proceeds.
907. **Bribery:** Exchanges improper benefits for the misuse of authority.
908. **Extortion:** Obtains compliance or property through wrongful threats.
909. **Blackmail:** Uses threatened disclosure or other pressure to coerce behavior.
910. **Racketeering:** Organizes unlawful schemes for economic or other gain.
911. **Protection rackets:** Extract payments through threats or manufactured insecurity.
912. **Tax evasion:** Illegally avoids tax obligations and undermines public finance.
913. **Insider trading:** Misuses protected market information in violation of applicable law.
914. **Market manipulation:** Distorts prices or market activity through improper conduct.
915. **Corporate fraud:** Misrepresents financial or operational information for improper advantage.
916. **Corporate cover-ups:** Conceal wrongdoing, failures, or dangerous practices.
917. **Institutional retaliation:** Punishes people who report concerns, refuse misconduct, or challenge authority.
918. **Abuse of authority:** Uses entrusted power for improper purposes.
919. **Police corruption:** Undermines lawful enforcement through bribery, protection of wrongdoing, or other abuses.
920. **Political bribery:** Purchases improper government influence.
921. **Kleptocracy:** Diverts public power and resources toward ruling elites.
922. **Election fraud:** Corrupts electoral processes and results.
923. **Voter intimidation:** Uses fear or threats to interfere with political participation.
924. **Coercive control:** Restricts personal autonomy through intimidation, isolation, surveillance, or manipulation.
925. **Psychological manipulation:** Influences people through deception, exploitation of vulnerabilities, or distorted information.
926. **Gaslighting:** Manipulates another person's understanding of events or reality.
927. **Love bombing:** Uses excessive affection or attention as a potential instrument of manipulation.
928. **Cultic coercion:** Uses social, psychological, or organizational pressure to suppress individual autonomy.
929. **Grooming:** Develops trust or dependency as preparation for exploitation or abuse.
930. **Harassment:** Repeatedly or seriously targets individuals with unwanted harmful conduct.
931. **Stalking:** Involves repeated unwanted pursuit or monitoring that can create fear or danger.
932. **Doxxing:** Maliciously exposes identifying or private information.
933. **Cyberbullying:** Uses digital communication to threaten, humiliate, or harass.
934. **Hate campaigns:** Coordinate hostility toward targeted people or groups.
935. **Scapegoating:** Assigns blame to individuals or groups to divert responsibility from actual causes.
936. **Moral panic:** Amplifies public fear about perceived threats, sometimes far beyond the supporting evidence.
937. **Institutional hypocrisy:** Creates contradictions between professed principles and actual conduct.
938. **Performative morality:** Displays ethical commitments without corresponding action.
939. **Virtue signaling:** Publicly communicates moral or social commitments; can express sincere affiliation or substitute performance for substance.
940. **Reputation laundering:** Uses selected associations or messages to obscure harmful conduct.
941. **Greenwashing:** Misrepresents products or institutions as environmentally responsible.
942. **Dark patterns:** Manipulate users through deceptive or coercive interface design.
943. **Predatory lending:** Exploits borrowers through abusive terms or practices.
944. **Predatory pricing:** May use strategically unsustainable prices to exclude competitors.
945. **Collusion:** Coordinates improper conduct among actors who should remain independent.
946. **Institutional neglect:** Allows preventable harms to continue through failure to act.
947. **Willful blindness:** Avoids acknowledging evidence of wrongdoing or risk.
948. **Social abandonment:** Leaves vulnerable people without necessary protection or support.
## 26. The mechanisms underneath social life
949. **Survival:** Individuals and groups organize around continued existence.
950. **Security:** People seek protection from physical, financial, social, and psychological threats.
951. **Freedom:** People seek meaningful autonomy over their lives.
952. **Dignity:** People seek recognition of their inherent worth.
953. **Belonging:** People seek acceptance into relationships and communities.
954. **Recognition:** People seek acknowledgment of their existence, contributions, and achievements.
955. **Purpose:** Individuals and institutions pursue objectives that give direction to action.
956. **Power:** Determines who can influence people, resources, choices, and outcomes.
957. **Authority:** Establishes recognized rights or capacities to make decisions.
958. **Legitimacy:** Determines whether authority is regarded as justified.
959. **Responsibility:** Connects roles and choices to obligations.
960. **Consequences:** Make decisions matter beyond immediate intentions.
961. **Accountability:** Creates the expectation that decisions can be examined and answered for.
962. **Incentives:** Influence behavior through anticipated rewards and penalties.
963. **Disincentives:** Discourage behavior through anticipated costs.
964. **Trade-offs:** Force choices between competing benefits, costs, and constraints.
965. **Opportunity costs:** Represent the value of alternatives forgone.
966. **Externalities:** Transfer benefits or costs to people not directly involved in a decision.
967. **Public goods:** Provide benefits that ordinary markets may not adequately supply.
968. **Shared resources:** Require rules or cooperation to avoid depletion and conflict.
969. **Collective action:** Coordinates people toward shared objectives.
970. **Free-riding:** Allows individuals to benefit from cooperation without bearing proportional costs.
971. **Coordination failures:** Occur when groups cannot align behavior despite potential mutual benefits.
972. **Information asymmetry:** Gives one party an informational advantage over another.
973. **Principal-agent problems:** Arise when decision-makers act on behalf of others but have different incentives or information.
974. **Conflicts of interest:** Create incentives that may compromise entrusted responsibilities.
975. **Moral hazard:** Encourages greater risk-taking when others bear some consequences.
976. **Adverse selection:** Occurs when hidden information affects who participates in an exchange or arrangement.
977. **Network effects:** Make services or relationships more valuable as participation increases.
978. **Economies of scale:** Reduce average costs as activity expands under suitable conditions.
979. **Diseconomies of scale:** Increase complexity or costs when systems grow beyond efficient coordination.
980. **Path dependence:** Causes past decisions to constrain present alternatives.
981. **Institutional inertia:** Makes established systems resist change even when improvement is possible.
982. **Feedback loops:** Reinforce or counteract changes in behavior and system performance.
983. **Tipping points:** Mark thresholds beyond which relatively small changes can produce major effects.
984. **Cascading failures:** Spread disruptions through interconnected systems.
985. **Resilience:** Allows systems to preserve essential functions under stress.
986. **Adaptability:** Allows systems to change when conditions demand it.
987. **Redundancy:** Preserves alternatives when primary mechanisms fail.
988. **Maintenance:** Prevents cumulative deterioration.
989. **Repair:** Restores damaged relationships, infrastructure, and institutions.
990. **Learning:** Converts experience and evidence into improved capabilities.
991. **Forgetting:** Removes or weakens retained knowledge, sometimes requiring rediscovery of past lessons.
992. **Chance:** Introduces events that are neither intended nor fully controllable.
993. **Luck:** Creates unequal outcomes beyond individual merit or effort.
994. **Timing:** Determines whether actions succeed, fail, or produce unintended consequences.
995. **Historical circumstances:** Shape present opportunities, institutions, and conflicts.
996. **Unintended consequences:** Arise when interventions produce effects beyond their intended objectives.
997. **Emergence:** Occurs when interactions among components produce collective patterns not reducible to any one participant.
998. **Interdependence:** Makes one person's or institution's outcomes dependent on others.
999. **Power asymmetry:** Allows some actors to impose costs or demands that others cannot reciprocate.
1000. **Social continuity:** Maintains shared knowledge, expectations, relationships, institutions, and essential services across time.
