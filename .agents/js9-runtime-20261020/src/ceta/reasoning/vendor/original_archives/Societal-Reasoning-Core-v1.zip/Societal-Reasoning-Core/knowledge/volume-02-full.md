# THE ANATOMY OF HUMAN SOCIETY - VOLUME II
## 1. Time, synchronization, and the organization of daily existence
1001. **Civil timekeeping:** Shared clock conventions allow strangers and institutions to coordinate; inaccurate clocks can disrupt transportation, transactions, and emergency operations.
1002. **Clock synchronization:** Distributed networks, financial markets, scientific equipment, and communication systems depend on consistent timestamps; synchronization failures can corrupt records or sequencing.
1003. **Time zones:** Make local civil schedules manageable across the planet; complicate international business, remote employment, communication, and emergency coordination.
1004. **Daylight-saving transitions:** Alter official schedules and seasonal daylight distribution; can disrupt sleep, transportation, software systems, and human routines.
1005. **Calendar systems:** Organize dates, records, history, agriculture, and administration; differences between systems can create misunderstandings and scheduling errors.
1006. **Fiscal years:** Establish accounting and reporting cycles; can encourage organizations to prioritize short-term targets over long-term performance.
1007. **School-year schedules:** Coordinate education, family routines, childcare, and employment; can create unequal burdens on working households.
1008. **Deadlines:** Establish predictable completion expectations; can motivate performance or encourage shortcuts, concealment, and exhaustion.
1009. **Queue management:** Determines access to limited services and resources; unfair queuing can favor wealth, influence, aggression, or technical advantage.
1010. **Appointment systems:** Coordinate scarce professional time; inaccessible scheduling can exclude people with unstable work, housing, or transportation.
1011. **Reservation systems:** Allocate future access to facilities and services; can enable speculative booking, artificial scarcity, and privileged access.
1012. **Time budgets:** Allocate finite waking hours among work, relationships, rest, and obligations; unequal control over time affects autonomy.
1013. **Time poverty:** Occurs when unavoidable obligations leave insufficient discretionary time, restricting education, participation, health, and advancement.
1014. **Time-use inequality:** Different populations experience unequal demands for commuting, domestic duties, caregiving, and administrative responsibilities.
1015. **Waiting burdens:** Delays impose costs even when no money changes hands, especially on people paid hourly or managing dependents.
1016. **Manufactured urgency:** Artificial deadlines pressure people into purchases, concessions, or decisions before adequate consideration.
1017. **Service windows:** Limit when people can obtain assistance; narrow availability can exclude night workers and people with complex schedules.
1018. **Lead times:** Determine how far in advance manufacturing, medicine, construction, and services must be arranged.
1019. **Response latency:** Measures delay between requests and responses; excessive delay undermines coordination, confidence, and emergency effectiveness.
1020. **Turnaround time:** Determines how quickly organizations complete transactions, reviews, repairs, and requests; compression can improve access or sacrifice quality.
1021. **Administrative backlogs:** Accumulate when incoming obligations exceed processing capacity; may produce severe consequences for people awaiting decisions.
1022. **Priority allocation:** Establishes which requests receive attention first; can protect urgent cases or institutionalize favoritism.
1023. **Scheduled maintenance windows:** Allow systems to be repaired with controlled disruption; poorly coordinated shutdowns can interrupt essential services.
1024. **Operating hours:** Determine when institutions are accessible; convenience for providers can conflict with public needs.
1025. **After-hours coverage:** Keeps emergency and essential functions available outside ordinary schedules; increases staffing and operational demands.
1026. **Night-shift dependence:** Hospitals, utilities, transportation, manufacturing, and security rely on work performed while much of society sleeps.
1027. **Punctuality expectations:** Influence assessments of responsibility and professionalism; different cultural conventions can create unfair judgments.
1028. **Delay tolerance:** Determines which scheduling deviations are socially acceptable; unequal tolerance often reflects differences in authority or status.
1029. **Late fees:** Encourage timely payment and protect operational schedules; can compound hardship among people with limited resources.
1030. **Early-completion incentives:** Reward accelerated performance; can encourage innovation or premature delivery.
1031. **No-show penalties:** Reduce wasted service capacity; can punish circumstances outside an individual's control.
1032. **Advance-notice requirements:** Give organizations and people preparation time; can disadvantage those experiencing emergencies.
1033. **Cooling-off periods:** Allow reconsideration before commitments become final; protect against impulsive or pressured decisions.
1034. **Statutes of limitations:** Establish deadlines for legal claims; support finality while potentially preventing legitimate claims.
1035. **Record-retention schedules:** Define how long institutions preserve information; premature destruction undermines accountability, while excessive retention threatens privacy.
1036. **Expiration dates:** Signal when products, permissions, credentials, or obligations need reconsideration; misunderstandings can cause waste or safety risks.
1037. **Renewal cycles:** Require periodic confirmation of licenses, benefits, contracts, and qualifications; create recurring administrative burdens.
1038. **Succession intervals:** Determine how organizations transition between generations of leadership; poor planning can produce instability.
1039. **Delayed consequences:** Separate actions from their eventual effects, making responsibility difficult to recognize or assign.
1040. **Competing planning horizons:** Individuals and institutions optimize over different periods, producing conflicts between immediate rewards and long-term outcomes.
## 2. Nonverbal communication and unwritten interaction rules
1041. **Greetings:** Establish acknowledgment, peaceful intentions, familiarity, or social hierarchy; their absence may be interpreted as disrespect.
1042. **Introductions:** Establish identities and connections between people; the person making an introduction can transfer perceived credibility.
1043. **Forms of address:** Communicate familiarity, professionalism, rank, and cultural expectations; inappropriate forms can signal contempt or exclusion.
1044. **Name pronunciation:** Recognizes personal identity and attentiveness; repeated disregard can communicate indifference or discrimination.
1045. **Eye contact:** Conveys attention, confidence, or challenge depending on context; cultural differences make universal interpretation unreliable.
1046. **Facial expressions:** Provide rapid social information; expressions can be misread, concealed, exaggerated, or deliberately performed.
1047. **Posture:** Communicates engagement, comfort, confidence, or defensiveness; physical limitations and cultural habits complicate interpretation.
1048. **Physical distance:** Regulates comfort, privacy, intimacy, and perceived threat; expectations vary across relationships and cultures.
1049. **Gestures:** Supplement or replace words; identical movements can carry different meanings across communities.
1050. **Tone of voice:** Changes the social meaning of identical sentences; sarcasm, tenderness, hostility, and uncertainty may be communicated through delivery.
1051. **Speech tempo:** Influences perceived urgency, competence, confidence, and emotional intensity; people sometimes manipulate pace to dominate exchanges.
1052. **Conversational turn-taking:** Determines when people speak and listen; unequal control over turns can silence participants.
1053. **Interruptions:** May demonstrate enthusiasm, urgency, dominance, or disrespect depending on relationship and circumstance.
1054. **Silence:** Can communicate agreement, rejection, reflection, discomfort, or strategic refusal; it does not have one universal meaning.
1055. **Pauses:** Create opportunities for thought and response; can also be used to increase pressure during negotiations.
1056. **Small talk:** Establishes familiarity and tests social comfort before more consequential conversation.
1057. **Active acknowledgment:** Short verbal and nonverbal signals show that a message is being received without necessarily expressing agreement.
1058. **Clarification requests:** Prevent errors by establishing what another person actually meant; excessive or performative clarification can obstruct communication.
1059. **Conversational repair:** Corrects misunderstandings after they occur and restores a shared understanding of the exchange.
1060. **Face-saving:** Allows people to retreat from mistakes or disagreements without unnecessary public humiliation; may also conceal wrongdoing.
1061. **Diplomatic ambiguity:** Preserves negotiating flexibility and relationships; can disguise commitments or prevent genuine understanding.
1062. **Indirect requests:** Communicate needs without explicit demands; can preserve politeness or create confusion about expectations.
1063. **Social scripts:** Provide familiar patterns for interviews, meetings, ceremonies, and introductions; deviations can confuse participants.
1064. **Code-switching:** Adjusts language or expression between social environments; supports communication while sometimes reflecting pressure to conform.
1065. **Audience adaptation:** Changes presentation according to listeners' knowledge, status, and expectations; can improve understanding or manipulate perceptions.
1066. **Public versus private personas:** People reveal different aspects of themselves depending on setting; discrepancies can be ordinary or deliberately deceptive.
1067. **Social masking:** Conceals personal characteristics or reactions to satisfy expectations; can enable participation at significant personal cost.
1068. **Emotional contagion:** Feelings and expressions spread between people, strengthening collective experiences or amplifying panic.
1069. **Conversation framing:** Establishes whether an exchange is understood as joking, debating, negotiating, teaching, or confronting someone.
1070. **Shared references:** Give groups efficient ways to communicate experiences and meanings that outsiders may not immediately understand.
1071. **Inside jokes:** Reinforce familiarity and belonging; may inadvertently or intentionally exclude outsiders.
1072. **Teasing conventions:** Permit playful challenges between willing participants; can become bullying when consent or relationship context is ignored.
1073. **Playful insults:** May express familiarity in established relationships; identical language can communicate hostility in another setting.
1074. **Compliment reception:** Shapes whether praise is experienced as recognition, obligation, embarrassment, or attempted influence.
1075. **Thank-you conventions:** Publicly acknowledge assistance and reinforce socially valued conduct.
1076. **Invitation etiquette:** Communicates desired participation and relationship expectations; exclusion or ambiguous invitations can create conflict.
1077. **Gift presentation:** Communicates affection, obligation, respect, or status; can create pressure for repayment.
1078. **Ceremonial handshakes:** Signal agreement, recognition, peaceful contact, or closure; cultural and personal preferences vary.
1079. **Communication breakdowns:** Occur when participants use incompatible assumptions, contexts, meanings, or channels.
1080. **Context collapse in conversation:** Occurs when statements intended for one audience reach another with different expectations and background knowledge.
## 3. How groups actually form, govern themselves, and fracture
1081. **Group formation thresholds:** Small differences in participation costs can determine whether informal gatherings become durable communities.
1082. **Membership criteria:** Establish who can join a group; may protect shared purposes or create arbitrary exclusion.
1083. **Initiation requirements:** Test commitment and transmit expectations; can become humiliating, dangerous, or coercive.
1084. **Informal leadership selection:** Groups often follow individuals before assigning official titles, creating authority without documented responsibility.
1085. **Unofficial power brokers:** Influence decisions through relationships and access rather than formal organizational positions.
1086. **Clique formation:** Creates tightly connected networks of familiarity; can marginalize people outside favored circles.
1087. **In-group terminology:** Uses specialized words or expressions to identify insiders and communicate efficiently.
1088. **Shibboleths:** Distinguishing phrases, behaviors, or references identify group affiliation and can function as informal membership tests.
1089. **Boundary policing:** Members enforce expectations about who belongs and which behavior is acceptable; may become oppressive.
1090. **Loyalty tests:** Demand demonstrations of allegiance; can expose genuine commitment or enforce obedience through fear.
1091. **Informal sanctions:** Groups punish conduct through reduced invitations, withdrawal of cooperation, or loss of standing without official proceedings.
1092. **Status contests:** Participants compete for recognition, attention, or influence, sometimes independently of actual contribution.
1093. **Internal factions:** Subgroups develop competing priorities; can enable debate or destabilize collective objectives.
1094. **Factional bargaining:** Groups exchange support across issues to influence decisions and preserve alliances.
1095. **Coalition switching:** Individuals or factions change affiliations when incentives, beliefs, or circumstances evolve.
1096. **Network brokers:** Connect otherwise separated communities, facilitating opportunity while gaining informational influence.
1097. **Weak social ties:** Acquaintances connect people to opportunities and information unavailable within close relationships.
1098. **Strong social ties:** Close relationships support dependable assistance but can concentrate expectations and obligations.
1099. **Social network density:** Influences how rapidly information travels and how strongly collective expectations are enforced.
1100. **Structural holes:** Gaps between social networks create opportunities for intermediaries to connect people or control information.
1101. **Friendship maintenance costs:** Relationships require time, contact, mutual consideration, and follow-through to remain active.
1102. **Social drift:** Relationships weaken through distance, changing routines, or reduced interaction without an explicit conflict.
1103. **Group size limits:** Increasing membership can make familiarity, consensus, and coordination progressively more difficult.
1104. **Unwritten constitutions:** Groups develop implicit rules that may carry more practical force than their official procedures.
1105. **Informal succession:** Influence transfers when respected members withdraw, sometimes without transparent agreement.
1106. **Leadership vacuums:** The absence of accepted authority can create opportunities for innovation, competition, or disorder.
1107. **Internal dispute arbitration:** Trusted group members settle disagreements without invoking formal legal systems.
1108. **Collective memory disputes:** Members disagree about prior commitments or events, reshaping legitimacy and relationships.
1109. **Organizational mythology:** Stories about a group's origins or achievements create identity and may conceal inconvenient history.
1110. **Founder's influence:** Initial decisions and personalities can shape organizational behavior long after founders leave.
1111. **Membership churn:** Departures and arrivals change knowledge, culture, cohesion, and organizational capacity.
1112. **Exit barriers:** Financial, emotional, reputational, or practical costs make leaving certain groups difficult.
1113. **Voice versus exit:** Dissatisfied members choose between attempting internal reform and abandoning participation.
1114. **Dissent tolerance:** Groups differ in whether criticism improves decision-making or threatens a member's position.
1115. **Minority influence:** Consistent dissenting members can gradually alter majority perceptions and group behavior.
1116. **Majority illusions:** People may overestimate support for an opinion because its advocates are unusually visible within their networks.
1117. **Leadership legitimacy contests:** Competing figures dispute who has the right to direct group decisions.
1118. **Reintegration procedures:** Groups determine whether excluded or departed members can return and under what conditions.
1119. **Group dissolution:** Communities can disappear through conflict, inactivity, resource shortages, or loss of shared purpose.
1120. **Institutional inheritance:** A group's practices, relationships, assets, and unresolved disputes can survive its original membership.
## 4. Specific cognitive mechanisms behind human decisions
1121. **Anchoring effects:** Initial numbers or impressions influence later judgments, even when the starting point is arbitrary.
1122. **Availability heuristics:** Easily recalled examples influence perceived frequency or danger, sometimes distorting decisions.
1123. **Loss aversion:** Potential losses often carry greater psychological weight than comparable gains, affecting negotiation and economic behavior.
1124. **Framing effects:** Identical outcomes appear different depending on how alternatives are described.
1125. **Sunk-cost effects:** Past investments can encourage continued commitment despite evidence that stopping would be wiser.
1126. **Present bias:** Immediate rewards receive disproportionate attention compared with future consequences.
1127. **Delay discounting:** People assign differing values to benefits or costs occurring later rather than sooner.
1128. **Halo effects:** A favorable impression in one area spills into judgments about unrelated capabilities or qualities.
1129. **Horn effects:** One unfavorable characteristic disproportionately influences broader evaluations of a person or institution.
1130. **Fundamental attribution error:** Observers may overemphasize personal character while underestimating situational influences on behavior.
1131. **Self-serving attribution:** People may credit personal ability for success while attributing failure to circumstances.
1132. **Hindsight bias:** Past events appear more predictable after their outcomes become known.
1133. **Outcome bias:** Decisions are judged by eventual results rather than the quality of reasoning available at the time.
1134. **Survivorship bias:** Visible successes receive attention while unseen failures are excluded from comparisons.
1135. **Selection bias:** Evidence becomes misleading when the observed sample does not adequately represent the relevant population.
1136. **Base-rate neglect:** People may ignore general probabilities when vivid case-specific information is presented.
1137. **Overconfidence effects:** Individuals overestimate their knowledge, skill, or predictive accuracy.
1138. **Dunning–Kruger effects:** Limited competence can impair accurate self-evaluation in some circumstances; the phenomenon does not justify blanket judgments about individuals.
1139. **Illusory correlation:** People perceive relationships between events or groups when evidence does not support them.
1140. **False consensus effects:** Individuals overestimate how widely their own opinions or behaviors are shared.
1141. **Pluralistic ignorance:** Members privately reject a norm while incorrectly believing most others accept it.
1142. **Motivated reasoning:** Desired conclusions influence how evidence is selected and evaluated.
1143. **Belief perseverance:** Established conclusions remain influential after their original supporting evidence is discredited.
1144. **Moral licensing:** Prior good behavior may be used to excuse or rationalize later questionable conduct.
1145. **Moral disengagement:** People justify harmful actions by minimizing consequences, shifting responsibility, or dehumanizing those affected.
1146. **Authority effects:** People may comply with perceived experts or officials beyond what independent evidence justifies.
1147. **Social-proof effects:** The behavior of others serves as evidence about what is appropriate, popular, or safe.
1148. **Scarcity effects in decision-making:** Perceived limited availability increases attention and urgency, even when scarcity is artificial.
1149. **Choice overload:** Too many alternatives can increase decision effort and sometimes reduce satisfaction or participation.
1150. **Default effects:** Preselected options strongly influence decisions because changing them requires attention or effort.
1151. **Mental accounting:** People treat economically equivalent money differently depending on its perceived source or purpose.
1152. **Endowment effects:** Ownership can increase how highly someone values an item relative to an otherwise identical alternative.
1153. **Cognitive load:** Mental demands consume limited processing capacity and can impair memory, reasoning, and decision quality.
1154. **Decision fatigue:** Prolonged decision-making may reduce attention and consistency, especially alongside stress or exhaustion.
1155. **Attentional tunneling:** Focus on an urgent concern can cause other important information to be overlooked.
1156. **Learned helplessness:** Repeated experiences of uncontrollable outcomes can suppress attempts to change circumstances.
1157. **Self-efficacy:** Belief in one's capacity to perform a task influences effort, perseverance, and willingness to attempt challenges.
1158. **Metacognition:** The ability to assess one's own thinking improves learning and correction, but self-assessment can itself be mistaken.
1159. **Theory of mind:** Understanding that others have distinct beliefs, intentions, and knowledge supports cooperation and can enable manipulation.
1160. **Counterfactual reasoning:** Imagining alternative outcomes helps people learn from decisions but can fuel regret or distorted blame.
## 5. The hidden economy of households and intimate relationships
1161. **Household task allocation:** Determines who performs specific domestic functions; unequal assignments can consume one person's opportunities.
1162. **Mental load:** Remembering appointments, supplies, obligations, and future needs creates continuing cognitive work beyond visible chores.
1163. **Meal planning:** Connects nutrition, schedules, income, preferences, and available supplies; poor planning can increase expense and waste.
1164. **Childcare scheduling:** Coordinates supervision across working hours and school breaks; failures can threaten employment stability.
1165. **Backup caregiving arrangements:** Provide alternatives when primary caregivers become unavailable; their absence magnifies emergencies.
1166. **Household inventory management:** Tracks essential food, medicine, hygiene supplies, and equipment; shortages disproportionately affect resource-constrained homes.
1167. **Utility bill allocation:** Determines who pays for shared services; ambiguous responsibility can create arrears and conflict.
1168. **Shared-account arrangements:** Simplify household spending but can create disputes over access, privacy, and ownership.
1169. **Financial transparency between partners:** Allows informed shared planning; deliberate concealment can undermine consent and security.
1170. **Financial dependency within relationships:** Can enable specialization and shared care while reducing an individual's ability to leave harmful circumstances.
1171. **Emergency household reserves:** Protect against immediate disruptions such as illness, job loss, or equipment failure.
1172. **Informal family loans:** Provide flexible assistance outside traditional finance; unclear terms can damage relationships.
1173. **Intergenerational transfers during life:** Parents or relatives provide housing, money, childcare, or business support that changes later opportunities.
1174. **Kinship obligations:** Cultural and family expectations determine when relatives must provide help; obligations can become coercive.
1175. **Caregiver substitution:** Family members assume responsibilities when another person becomes ill, absent, or incapable.
1176. **Sibling roles:** Birth order, expectations, and household circumstances shape caregiving, rivalry, and perceived responsibility.
1177. **Parental favoritism mechanisms:** Unequal attention, resources, and expectations can create lasting differences among children.
1178. **Blended-family coordination:** Integrates different parental relationships, schedules, traditions, and legal responsibilities.
1179. **Co-parenting agreements:** Organize childcare across separated households; poorly defined responsibilities create recurring conflict.
1180. **Custody exchanges:** Require reliable logistics and communication; unresolved hostility can place children between conflicting adults.
1181. **Family emergency contacts:** Connect institutions with responsible people during illness, danger, or urgent decisions.
1182. **Medical decision proxies:** Establish who may speak for someone unable to make particular medical decisions.
1183. **Advance directives:** Preserve healthcare preferences when future communication or decision-making becomes impossible.
1184. **Power-of-attorney arrangements:** Delegate defined legal or financial authority; require safeguards against misuse.
1185. **Guardianship procedures:** Provide decision-making structures for qualifying individuals; can improperly restrict autonomy if oversight fails.
1186. **Estate administration:** Settles obligations and distributes assets following death; procedural mistakes can prolong disputes.
1187. **Funeral expenses:** Create immediate material obligations during bereavement and can impose severe financial pressure.
1188. **Family caregiving negotiations:** Determine how costs, time, and responsibilities are shared when a relative requires support.
1189. **Household conflict de-escalation:** Uses timing, space, communication, and agreed procedures to prevent disagreements from escalating.
1190. **Relationship repair attempts:** Small acknowledgments, changed behavior, and renewed commitments can restore cooperation after minor breaches.
1191. **Attachment styles:** Learned patterns of closeness and response to separation influence later relationships, without determining them completely.
1192. **Compatibility negotiation:** Partners reconcile differences in priorities, routines, intimacy, finances, and future objectives.
1193. **Relationship exclusivity agreements:** Establish what participants understand to be permitted or prohibited within a relationship.
1194. **Privacy between partners:** Protects individuality and confidence; secrecy can also be used to conceal material violations of agreed commitments.
1195. **Intimacy maintenance:** Requires continuing attention to mutual needs, communication, and changing circumstances.
1196. **Reproductive planning:** Coordinates desired timing, resources, health needs, and family decisions.
1197. **Fertility treatment decisions:** Involve medical uncertainty, emotional strain, significant costs, and questions of access.
1198. **Surrogacy arrangements:** Create family-building possibilities while raising questions of informed agreement, compensation, and exploitation.
1199. **Family geographic separation:** Employment, migration, imprisonment, military service, or disaster can divide households and redistribute care obligations.
1200. **Household crisis recovery:** Rebuilds routine, safety, and economic stability after events such as eviction, illness, separation, or death.
## 6. Retail, transactions, and the psychology of buying and selling
1201. **Stock-keeping units:** Give businesses a standardized way to distinguish products and track inventory; inaccurate identifiers cause ordering and accounting failures.
1202. **Barcodes:** Connect physical products to digital records, enabling rapid identification, sales, and inventory movement.
1203. **Shelf labeling:** Communicates product identity and price; misleading or outdated labels create disputes and consumer confusion.
1204. **Loss-leader pricing:** Sells selected goods cheaply to attract customers; can disadvantage competitors or encourage unnecessary purchases.
1205. **Retail markups:** Cover operating expenses and create business margins; excessive or opaque markups can exploit limited alternatives.
1206. **Markdown strategies:** Reduce prices to clear stock; can improve affordability or manipulate perceptions of value.
1207. **Dynamic pricing:** Adjusts prices according to demand and market conditions; can improve allocation or exploit urgent needs.
1208. **Bait-and-switch practices:** Attract customers using offers that are unavailable or misrepresented, then pressure them toward different purchases.
1209. **Inventory shrinkage:** Measures stock lost through theft, damage, administrative errors, or other causes; losses affect workers, prices, and profitability.
1210. **Inventory reconciliation:** Compares recorded stock against physical quantities to detect discrepancies and protect operational accuracy.
1211. **Cash drawer balancing:** Verifies money received and returned during transactions; errors can trigger disputes or unfair accusations.
1212. **End-of-day reconciliation:** Compares sales, payments, refunds, and cash movement to identify operational inconsistencies.
1213. **Change availability:** Determines whether cash transactions can be completed smoothly; shortages create friction and may disproportionately affect cash-dependent customers.
1214. **Point-of-sale tax calculation:** Applies transaction-specific tax rules; configuration errors can create legal obligations and incorrect charges.
1215. **Tipping conventions:** Redistribute customer payments to workers under varying cultural and legal expectations; can make income unpredictable.
1216. **Service charges:** Add stated fees to transactions; unclear presentation can mislead customers about total costs or worker compensation.
1217. **Customer loyalty programs:** Reward repeat purchasing and create business intelligence; can collect extensive behavioral data.
1218. **Reward-point valuation:** Converts purchases into redeemable benefits; expiration rules and changing values can undermine expected rewards.
1219. **Coupons:** Reduce selected purchase prices and influence customer behavior; complicated restrictions can obscure genuine savings.
1220. **Manufacturer rebates:** Return part of a purchase price after qualifying procedures; administrative friction reduces redemption.
1221. **Return policies:** Define conditions for reversing purchases; can protect consumers or impose unreasonable barriers.
1222. **Restocking fees:** Recover some return-processing costs; may discourage legitimate returns.
1223. **Product warranties:** Promise specified remedies for defects or failures; unclear exclusions can create disputes.
1224. **Product recalls:** Remove or repair goods posing recognized problems; delayed or incomplete recalls endanger consumers.
1225. **Customer complaint systems:** Collect reports of defects, dissatisfaction, and misconduct; ignored complaints allow recurring problems.
1226. **Dispute escalation procedures:** Provide a route beyond frontline employees when ordinary resolution fails; can be inaccessible or excessively bureaucratic.
1227. **Price matching:** Allows customers to challenge higher prices using competing offers; exclusions and verification requirements affect its usefulness.
1228. **Product placement:** Changes purchasing behavior by altering what shoppers encounter first or most prominently.
1229. **Seasonal promotions:** Coordinate supply and consumer demand around particular periods; can generate artificial urgency and unsustainable purchasing.
1230. **Shopping-cart abandonment:** Reflects consumer reconsideration, price surprises, inconvenience, or friction within digital purchasing.
1231. **Comparison shopping:** Improves buyer information; complicated pricing structures can make meaningful comparison difficult.
1232. **Unit pricing:** Expresses costs per comparable measure, helping buyers distinguish genuine value from misleading package sizes.
1233. **Package-size manipulation:** Changes quantity or weight while preserving familiar visual presentation, potentially obscuring effective price increases.
1234. **Product packaging design:** Protects goods and communicates information; can generate excessive waste or misleading impressions.
1235. **Planned obsolescence:** Designs limited useful life or replacement pressures into products, potentially increasing waste and dependency.
1236. **Repairability:** Determines whether owners can economically restore products rather than replace them; restrictions affect cost and resource consumption.
1237. **Authenticity verification:** Helps distinguish genuine products from misrepresented ones; failures threaten safety and confidence.
1238. **Seller-rating systems:** Communicate buyer experiences; manipulation and selective feedback can distort trust.
1239. **Marketplace seller accountability:** Determines responsibility when independent merchants use a larger platform to reach customers.
1240. **Cashless exclusion:** Occurs when payment systems reject physical currency, disadvantaging people without reliable digital banking access.
## 7. The financial plumbing underneath money and credit
1241. **Payment authorization:** Checks whether a proposed payment may proceed; failures interrupt commerce and can produce false declines.
1242. **Clearing:** Exchanges transaction information between financial institutions before funds are finally settled.
1243. **Settlement:** Completes financial obligations between parties; settlement failures can spread through dependent institutions.
1244. **Correspondent banking:** Allows banks to conduct transactions through other banks, supporting cross-border payments while introducing intermediary risks.
1245. **Interbank payment rails:** Move obligations between financial institutions; outages can disrupt entire markets.
1246. **Card networks:** Coordinate card-based transactions among merchants, processors, issuers, and financial institutions.
1247. **Merchant acquiring:** Provides businesses access to electronic payment acceptance; fees affect commercial viability.
1248. **Payment processing fees:** Compensate intermediaries for transaction handling; opaque pricing can burden smaller merchants.
1249. **Chargeback procedures:** Reverse disputed card transactions under specified conditions; protect buyers while exposing merchants to abuse.
1250. **Payment fraud screening:** Detects suspicious transactions; excessive sensitivity can deny legitimate customers access.
1251. **Escrow arrangements:** Hold assets with a third party until contractual conditions are satisfied, reducing certain forms of transaction risk.
1252. **Collateral:** Provides lenders with assets that may be claimed after qualifying defaults; collateral requirements restrict some borrowers' access.
1253. **Loan underwriting:** Evaluates the likelihood that borrowers can satisfy obligations; discriminatory or inaccurate methods create exclusion.
1254. **Credit scoring:** Summarizes selected indicators of repayment risk; errors and incomplete histories can create persistent disadvantage.
1255. **Credit reporting agencies:** Collect information affecting access to loans and other services; inaccurate records can harm individuals for years.
1256. **Debt servicing:** Handles payments, account records, notices, and borrower communication after loans are issued.
1257. **Loan refinancing:** Replaces an existing obligation with another arrangement; may reduce payments or extend costly indebtedness.
1258. **Debt restructuring:** Changes repayment terms when existing obligations become unsustainable; can preserve solvency or redistribute losses unfairly.
1259. **Default triggers:** Define circumstances under which a borrower or counterparty breaches financial obligations.
1260. **Collections procedures:** Seek repayment of overdue obligations; can become abusive when legal safeguards are ignored.
1261. **Bank capital requirements:** Require financial institutions to maintain financial buffers against losses; affect lending capacity and stability.
1262. **Liquidity management:** Ensures institutions can meet near-term obligations without selling assets under destructive conditions.
1263. **Deposit guarantees:** Protect qualifying depositors against certain bank failures; must be structured to limit excessive risk-taking.
1264. **Bank runs:** Occur when widespread withdrawal demands overwhelm an institution's available liquidity, potentially threatening otherwise viable operations.
1265. **Interbank contagion:** Transmits financial distress through linked obligations, investments, and shared exposures.
1266. **Margin requirements:** Require collateral against leveraged positions; sudden increases can force asset sales.
1267. **Margin calls:** Demand additional collateral after changes in exposure; can accelerate financial crises.
1268. **Mark-to-market accounting:** Updates asset values using current market conditions; improves visibility but can amplify reported volatility.
1269. **Depreciation accounting:** Allocates the cost of certain assets across their useful lives, influencing financial statements and investment decisions.
1270. **Accounts receivable:** Records money owed to a business; delayed collection can create liquidity problems despite profitable sales.
1271. **Accounts payable:** Tracks financial obligations to suppliers and other parties; poor administration damages credit and relationships.
1272. **Factoring:** Converts qualifying unpaid invoices into immediate funding at a cost, helping businesses manage cash flow.
1273. **Trade credit:** Allows businesses to receive goods before paying; strengthens commercial relationships but creates default exposure.
1274. **Letters of credit:** Use financial institutions to support payment obligations in specified commercial transactions.
1275. **Surety bonds:** Provide a financial assurance that defined obligations will be performed or compensated if breached.
1276. **Beneficial ownership disclosure:** Identifies people who ultimately control certain assets or entities, helping expose hidden financial influence.
1277. **Customer identification procedures:** Help financial institutions establish who they are serving; poorly designed requirements can exclude legitimate users.
1278. **Suspicious-transaction reporting:** Provides authorities with information about qualifying potentially unlawful financial activity; requires appropriate protections against misuse.
1279. **Currency convertibility restrictions:** Limit exchange or transfer of currency, affecting capital movement, foreign trade, and individual savings.
1280. **Financial reconciliation across institutions:** Detects differences between independently maintained transaction records before discrepancies cause larger failures.
## 8. The overlooked mechanisms of workplaces
1281. **Job descriptions:** Establish expected duties and qualifications; vague descriptions permit shifting obligations without clear accountability.
1282. **Staffing ratios:** Determine how many workers are available for a particular workload; unsafe ratios can compromise services.
1283. **Duty rosters:** Allocate people to operational responsibilities; poor allocation produces gaps and inequitable burdens.
1284. **Shift handoffs:** Transfer information and responsibility between workers; omitted details can create dangerous errors.
1285. **Scheduling predictability:** Allows employees to organize childcare, transportation, education, and personal obligations.
1286. **Overtime allocation:** Determines who works beyond normal hours and receives associated compensation; uneven allocation creates financial and safety problems.
1287. **On-call obligations:** Require employees to remain available for uncertain demands, restricting discretionary time.
1288. **Paid sick leave:** Supports recovery and reduces pressure to work while ill; inadequate coverage can increase disease transmission.
1289. **Parental leave policies:** Shape the ability of working parents to care for infants and maintain employment.
1290. **Bereavement leave:** Gives workers time to address death-related family and practical obligations.
1291. **Reasonable workplace accommodations:** Adjust tasks or conditions to permit qualified people with disabilities to participate.
1292. **Ergonomic design:** Reduces physical strain and injury from repeated movements, awkward positions, or unsuitable equipment.
1293. **Fatigue management:** Adjusts work patterns and rest requirements to reduce errors and injury associated with exhaustion.
1294. **Task rotation:** Distributes repetitive or demanding duties; may improve versatility but can reduce specialization.
1295. **Cross-training:** Prepares workers to perform multiple functions, preserving service when specialized personnel are unavailable.
1296. **Shadow training:** Teaches practical work by having learners observe experienced employees; can transmit both effective practices and bad habits.
1297. **Competency assessments:** Verify the ability to perform specified tasks rather than relying exclusively on claimed experience.
1298. **Performance appraisals:** Evaluate employee contributions and development; poorly designed metrics encourage gaming and favoritism.
1299. **Performance improvement plans:** Establish targets for correcting deficiencies; can provide useful guidance or serve as a pretext for termination.
1300. **Probationary employment periods:** Allow employers to assess new workers; can increase insecurity when protections are weak.
1301. **Exit interviews:** Collect information from departing employees; honest feedback depends on safety and confidence.
1302. **Severance arrangements:** Provide specified compensation or conditions at employment separation; unequal negotiating power affects terms.
1303. **Internal grievance processes:** Give workers channels to contest mistreatment or disputes without immediately seeking external intervention.
1304. **Disciplinary documentation:** Records alleged violations and responses; inaccurate or selective documentation can destroy careers.
1305. **Progressive discipline:** Uses escalating consequences for specified repeated misconduct; requires consistency and proportionality.
1306. **Workplace incident reports:** Preserve accounts of injuries, threats, mistakes, and unusual events; inaccurate reports obstruct investigation.
1307. **Near-miss reporting:** Identifies circumstances that could have caused harm before an actual injury or failure occurs.
1308. **Root-cause investigations:** Examine the conditions producing failures rather than assigning blame solely to the most visible participant.
1309. **Safety briefings:** Communicate immediate hazards and operational changes; habitual or superficial delivery reduces their value.
1310. **Standard operating procedures:** Translate organizational requirements into repeatable steps; outdated procedures can institutionalize errors.
1311. **Exception handling:** Defines how employees respond when ordinary procedures cannot accommodate actual circumstances.
1312. **Escalation authority:** Determines who can approve unusual decisions or respond to incidents beyond an employee's assigned role.
1313. **Segregation of duties:** Divides sensitive functions among multiple people to reduce opportunities for concealed misuse.
1314. **Access provisioning:** Grants workers the systems and resources necessary for their assigned duties; excessive permissions increase risk.
1315. **Access removal after departure:** Prevents former personnel from retaining unauthorized capabilities and sensitive information.
1316. **Knowledge-transfer sessions:** Preserve specialized operational understanding before personnel change roles or leave.
1317. **Succession planning for critical roles:** Identifies replacements for personnel whose absence could halt essential operations.
1318. **Internal mobility:** Allows workers to change functions without leaving an organization, improving retention and skill deployment.
1319. **Workforce contingency planning:** Prepares organizations for sudden staff shortages, strikes, illness, or unexpected demand.
1320. **Informal workplace rulemaking:** Employees develop practical methods beyond written procedures; these may improve operations or bypass necessary safeguards.
## 9. Supply chains, logistics, and the movement of physical civilization
1321. **Bills of lading:** Document cargo receipt, transport arrangements, and specified rights concerning shipments.
1322. **Freight forwarding:** Coordinates shipments across carriers, modes, and jurisdictions; complex arrangements introduce accountability gaps.
1323. **Customs brokerage:** Helps shipments comply with customs procedures; errors can trigger delays, penalties, or seizure.
1324. **Cargo manifests:** Record goods being transported, supporting accounting, safety, and regulatory inspections.
1325. **Containerization:** Standardizes cargo handling across ships, trains, and trucks; increases efficiency while concentrating dependence on port infrastructure.
1326. **Palletization:** Combines goods into standardized handling units, reducing labor and damage during transportation.
1327. **Freight consolidation:** Combines smaller shipments to reduce transport costs; can introduce additional handling and delays.
1328. **Cross-docking:** Transfers incoming goods directly toward outbound transport with limited storage, reducing inventory time.
1329. **Last-mile fulfillment:** Delivers products from distribution facilities to final recipients; often carries disproportionate labor and transport costs.
1330. **Reverse logistics:** Moves returned, damaged, reusable, or recyclable products back through distribution systems.
1331. **Return merchandise authorization:** Creates a traceable procedure for accepting and processing returned commercial goods.
1332. **Warehouse slotting:** Determines storage locations based on product characteristics and demand; poor design increases errors and handling time.
1333. **Order picking:** Collects selected goods from warehouse inventory; mistakes propagate directly into customer orders.
1334. **Packing verification:** Checks that shipments contain correct goods and protection before dispatch.
1335. **Load balancing in transport:** Distributes cargo to preserve vehicle stability, capacity, and operating efficiency.
1336. **Route optimization:** Selects delivery paths to reduce time, cost, fuel use, or other constraints; optimization can produce unrealistic labor expectations.
1337. **Fleet utilization:** Measures how effectively vehicles and equipment are deployed; overuse accelerates wear and reduces backup capacity.
1338. **Vehicle maintenance schedules:** Prevent equipment breakdown and improve transport safety through planned inspections and repairs.
1339. **Driver rest compliance:** Limits fatigue-related hazards in transportation systems.
1340. **Shipment tracking:** Provides location and status information; gaps or false updates can obscure losses and delays.
1341. **Proof of delivery:** Records whether goods reached the intended recipient; forged or inadequate evidence creates disputes.
1342. **Cargo insurance:** Allocates financial losses associated with specified transport hazards.
1343. **Demurrage charges:** Penalize excessive use of port or terminal capacity, influencing cargo movement and storage decisions.
1344. **Customs valuation:** Determines the declared value of imports for applicable duties and compliance obligations.
1345. **Rules of origin:** Establish where products legally originate for trade treatment; complex manufacturing chains make classification difficult.
1346. **Export documentation:** Records goods, destinations, and permissions for cross-border movement; inaccuracies may violate trade controls.
1347. **Supplier qualification:** Evaluates prospective vendors for reliability, capacity, quality, and compliance.
1348. **Single-source dependence:** Reduces complexity when one supplier is used but creates concentrated failure risk.
1349. **Dual sourcing:** Maintains alternative suppliers for essential inputs, improving resilience at additional cost.
1350. **Just-in-time inventory:** Minimizes stored goods and holding expenses; increases vulnerability to disruption.
1351. **Just-in-case inventory:** Maintains extra supplies for uncertainty; consumes capital and storage capacity.
1352. **Safety stock:** Provides inventory beyond expected immediate demand to absorb variability.
1353. **Reorder points:** Trigger replenishment when stock reaches defined thresholds; inaccurate thresholds cause shortages or excess supply.
1354. **Demand forecasting:** Estimates future purchasing or consumption; errors propagate into procurement, production, and transport.
1355. **Bullwhip effects:** Small consumer-demand changes produce increasingly large ordering fluctuations farther upstream.
1356. **Capacity reservations:** Secure future manufacturing or transport availability; can create waste if projected demand fails to materialize.
1357. **Production bottlenecks:** Limit system throughput at constrained stages, regardless of spare capacity elsewhere.
1358. **Lot traceability:** Connects finished products to specific production batches and materials, supporting targeted recalls and investigations.
1359. **Chain-of-custody tracking:** Documents possession and transfer of goods or samples to preserve authenticity and accountability.
1360. **Supply-chain visibility gaps:** Prevent organizations from recognizing dependencies beyond immediate vendors, allowing distant failures to arrive unexpectedly.
## 10. Food production, water systems, and ecosystem dynamics
1361. **Crop rotation:** Changes planting sequences to manage soil nutrients, disease, and pests; poor rotation can reduce long-term yields.
1362. **Intercropping:** Grows complementary crops together to improve resource use and sometimes reduce pest vulnerability.
1363. **Monoculture dependence:** Simplifies production and mechanization but increases exposure to particular diseases and environmental changes.
1364. **Seed banks:** Preserve genetic diversity and potential future crop varieties against disasters or agricultural losses.
1365. **Seed germination testing:** Evaluates whether stored or commercial seeds remain viable before planting.
1366. **Plant breeding selection:** Combines or selects traits for yield, resilience, and quality; narrow selection can reduce genetic diversity.
1367. **Soil microbial communities:** Support decomposition, nutrient availability, and plant growth; disturbance can degrade fertility.
1368. **Mycorrhizal relationships:** Connect fungi and plants through exchanges of nutrients and other resources, influencing ecosystem productivity.
1369. **Composting:** Converts suitable organic waste into useful soil amendments; poor management can introduce pathogens or contaminants.
1370. **Integrated pest management:** Combines monitoring and targeted interventions to reduce crop losses while limiting unnecessary pesticide use.
1371. **Biological pest control:** Uses natural enemies or ecological relationships to manage pests; introduced control species can create unintended consequences.
1372. **Pollination networks:** Link flowering plants and pollinating organisms; disruption can affect food production and biodiversity.
1373. **Agricultural runoff:** Carries nutrients, sediment, or chemicals from farmland into waterways, creating downstream environmental costs.
1374. **Nutrient loading:** Excess nitrogen or phosphorus stimulates ecological imbalances in receiving waters.
1375. **Eutrophication:** Nutrient enrichment can produce excessive biological growth, oxygen depletion, and damage to aquatic life.
1376. **Harmful algal blooms:** Certain algal or cyanobacterial populations produce toxins or ecological disruption threatening water supplies and fisheries.
1377. **Groundwater recharge:** Restores water to underground aquifers; paved surfaces and extraction can reduce sustainable replenishment.
1378. **Aquifer depletion:** Occurs when withdrawals exceed sustainable replenishment, threatening agriculture, settlements, and future access.
1379. **Land subsidence:** Ground surfaces sink through processes including excessive groundwater extraction, damaging buildings and infrastructure.
1380. **Water rights allocation:** Establishes who may withdraw or use water and under what conditions; competing claims can create serious conflict.
1381. **Watershed management:** Coordinates land use, water quality, flood risks, and ecological needs across drainage regions.
1382. **Reservoir operation:** Balances water storage, supply, electricity, environmental flows, and flood-control demands.
1383. **Environmental flow requirements:** Preserve sufficient river movement to support ecological functions and downstream needs.
1384. **Desalination:** Produces usable freshwater from saline sources; demands energy and responsible management of concentrated waste.
1385. **Rainwater harvesting:** Captures precipitation for later use; local rules and health safeguards influence applications.
1386. **Graywater reuse:** Redirects appropriate wastewater toward selected nonpotable purposes, reducing demand for treated freshwater.
1387. **Leak detection in water networks:** Identifies hidden losses before they cause structural damage or unnecessary extraction.
1388. **Cross-connection control:** Prevents contaminated water from entering safe supply systems through improperly connected plumbing.
1389. **Wetland hydrology:** Sustains environments that filter water, store carbon, support wildlife, and moderate flooding.
1390. **Riparian vegetation:** Stabilizes stream banks, shades waterways, and supports wildlife along rivers and streams.
1391. **Trophic cascades:** Changes in one species' abundance propagate through multiple levels of an ecosystem.
1392. **Keystone species:** Have ecological effects disproportionately large relative to their abundance; removal can destabilize entire communities.
1393. **Invasive species management:** Attempts to limit ecological damage from organisms spreading outside their established ranges.
1394. **Habitat connectivity:** Enables organisms to move among suitable areas; fragmentation increases isolation and ecological vulnerability.
1395. **Genetic bottlenecks:** Reduce genetic variation after sharp population reductions, potentially weakening future adaptability.
1396. **Ecological carrying capacity:** Describes population limits under particular resource and environmental conditions, rather than a fixed universal number.
1397. **Predator-prey cycles:** Shape changing population sizes and ecological relationships over time.
1398. **Disease reservoirs in wildlife:** Maintain pathogens that may affect other animals or humans under certain transmission conditions.
1399. **Ecological baseline selection:** Determines which historical or current conditions are used to judge environmental change.
1400. **Cumulative environmental impacts:** Result when numerous individually limited activities collectively produce substantial ecological harm.
## 11. The internal mechanics of medical care and public health
1401. **Medical triage:** Prioritizes patients according to urgency and available resources; incorrect classification can delay lifesaving treatment.
1402. **Acuity scoring:** Uses clinical observations to estimate severity and identify deteriorating patients.
1403. **Differential diagnosis:** Considers multiple possible explanations for symptoms before selecting treatment; premature conclusions can conceal serious disease.
1404. **Specimen handling:** Preserves the integrity of blood, tissue, and other samples; contamination or mislabeling can produce incorrect medical decisions.
1405. **Laboratory accreditation:** Evaluates whether laboratories satisfy established operational and quality requirements.
1406. **Diagnostic sensitivity:** Measures a test's ability to identify people who actually have a specified condition.
1407. **Diagnostic specificity:** Measures a test's ability to correctly identify people who do not have a specified condition.
1408. **Predictive value of medical tests:** Depends on test performance and disease prevalence; misunderstood probabilities can create unnecessary fear or reassurance.
1409. **False-negative results:** Fail to identify an existing condition and can delay necessary treatment or precautions.
1410. **Overdiagnosis:** Identifies conditions that would not have caused meaningful harm, potentially exposing patients to unnecessary intervention.
1411. **Underdiagnosis:** Fails to recognize treatable conditions, contributing to preventable illness and inequitable outcomes.
1412. **Medical second opinions:** Provide an additional professional evaluation when diagnosis or treatment choices are consequential or uncertain.
1413. **Specialist referral pathways:** Determine how patients move between general and specialized care; delays can worsen outcomes.
1414. **Prior authorization:** Requires advance payer approval for certain services; may control spending but can create harmful treatment delays.
1415. **Drug formularies:** Establish which medications are covered or preferred within a health system; restrictions affect treatment access.
1416. **Medication reconciliation:** Compares prescribed and actually used medications across care transitions to detect omissions and dangerous inconsistencies.
1417. **Drug-interaction screening:** Identifies combinations that may reduce effectiveness or cause harmful reactions.
1418. **Treatment adherence support:** Helps patients follow appropriate regimens while addressing affordability, complexity, side effects, and practical barriers.
1419. **Antimicrobial stewardship:** Promotes appropriate antimicrobial use to preserve effectiveness and reduce resistance.
1420. **Vaccine temperature monitoring:** Protects temperature-sensitive biological products from losses of effectiveness caused by unsuitable storage or transport.
1421. **Healthcare-associated infection prevention:** Reduces the spread of pathogens within medical facilities.
1422. **Hand-hygiene compliance:** Prevents transmission between patients, workers, equipment, and surrounding environments.
1423. **Instrument sterilization:** Removes viable microorganisms from equipment requiring sterile conditions; failures can spread serious infections.
1424. **Patient isolation procedures:** Separate individuals when necessary to reduce specific infection-transmission risks.
1425. **Contact tracing:** Identifies potentially exposed individuals so appropriate information and interventions can reach them.
1426. **Wastewater disease monitoring:** Uses population-level sewage measurements to identify certain health trends without testing every individual.
1427. **Clinical handovers:** Transfer responsibility and essential information between medical professionals; communication omissions can cause injury.
1428. **Electronic health record integrity:** Preserves accurate patient histories, orders, results, and treatment documentation.
1429. **Medical data exchange standards:** Allow appropriate health information to move between different systems while protecting confidentiality.
1430. **Clinical decision-support systems:** Provide relevant alerts or guidance; poorly designed systems can create overreliance or alert fatigue.
1431. **Medical malpractice review:** Examines whether treatment fell below applicable professional standards and caused legally cognizable harm.
1432. **Professional medical credential verification:** Confirms qualifications and authorization before healthcare workers undertake regulated duties.
1433. **Morbidity and mortality conferences:** Review difficult clinical outcomes to identify learning opportunities and preventable failures.
1434. **Organ donation coordination:** Connects consent, clinical eligibility, preservation, transport, and recipient needs.
1435. **Transplant allocation systems:** Apply defined medical and ethical criteria when scarce donor organs must be assigned.
1436. **Blood bank compatibility testing:** Reduces dangerous transfusion reactions by checking blood-group and other relevant characteristics.
1437. **Regional trauma networks:** Direct severely injured patients toward facilities with appropriate capabilities and staffing.
1438. **Medical interpretation services:** Enable patients and professionals who use different languages to communicate accurately about consequential treatment decisions.
1439. **Medical billing codes:** Standardize descriptions of services for reimbursement and administration; incorrect coding can create denials or improper charges.
1440. **Uncompensated medical care:** Occurs when healthcare providers deliver services without receiving full payment, shifting financial burdens within health systems.
## 12. The mechanisms inside teaching and scientific knowledge production
1441. **Learning prerequisites:** Establish knowledge and skills required before more advanced concepts can be understood.
1442. **Instructional scaffolding:** Provides temporary support while learners develop independent competence; excessive support can inhibit autonomy.
1443. **Spaced repetition:** Revisits information across intervals to improve long-term retention.
1444. **Retrieval practice:** Strengthens memory by requiring learners to recall information rather than merely reread it.
1445. **Elaborative learning:** Connects new knowledge with explanations and existing concepts to support deeper understanding.
1446. **Feedback timing:** Influences whether corrections arrive soon enough to help learning without undermining independent problem-solving.
1447. **Formative assessment:** Measures progress during instruction so teaching can be adjusted before final evaluation.
1448. **Summative assessment:** Evaluates achievement after a defined learning period; can encourage excessive focus on tested material.
1449. **Mastery-based progression:** Advances learners after demonstrating competence instead of relying exclusively on elapsed classroom time.
1450. **Differentiated instruction:** Adjusts teaching methods or support according to learners' needs and preparation.
1451. **Classroom grouping:** Organizes students for activities and instruction; grouping choices can affect social relationships and opportunities.
1452. **Instructional pacing:** Determines how quickly concepts are introduced; inappropriate pacing can leave some learners behind or disengaged.
1453. **Attendance monitoring:** Identifies missed instruction and potential welfare concerns; punitive responses may worsen underlying barriers.
1454. **Chronic absenteeism intervention:** Addresses recurring absence caused by illness, transportation, instability, safety concerns, or other obstacles.
1455. **School transportation routes:** Determine practical access to education and can significantly affect family schedules.
1456. **School nutrition programs:** Provide meals that support learning and reduce household food insecurity.
1457. **Educational material procurement:** Determines whether students receive suitable books, equipment, and learning supplies.
1458. **Student device access:** Affects participation in digital assignments and instruction; unequal access reinforces educational disparities.
1459. **Teacher preparation time:** Supports lesson development, evaluation, and individualized assistance; inadequate time reduces instructional quality.
1460. **Lesson sequencing:** Organizes concepts so later instruction builds on earlier knowledge.
1461. **Class-size effects:** Influence individual attention, classroom management, and the distribution of teaching resources.
1462. **Individual tutoring:** Provides focused instruction that can close particular learning gaps, subject to access and quality.
1463. **Peer instruction:** Uses student explanations and discussion to reinforce understanding; can spread errors without appropriate guidance.
1464. **Learning-difficulty identification:** Detects students who need particular educational supports, while guarding against misclassification.
1465. **Grading rubrics:** Make evaluation criteria more explicit; poorly constructed rubrics can reward superficial compliance.
1466. **Grade inflation:** Reduces the informational value of grades when increasingly high marks do not reflect corresponding achievement.
1467. **Scholarship allocation:** Distributes limited educational funding according to specified criteria; design determines who can realistically qualify.
1468. **Educational tracking:** Places learners into different pathways; may offer specialization while reinforcing unequal expectations.
1469. **Hidden curricula:** Transmit unwritten institutional expectations about authority, behavior, class, and professional culture.
1470. **School-to-work transitions:** Connect education with employment through placements, guidance, credentials, and practical experience.
1471. **Academic misconduct investigations:** Examine alleged violations while balancing institutional integrity with procedural fairness.
1472. **Plagiarism detection:** Identifies potentially unattributed work; automated similarity measures require contextual interpretation.
1473. **Research preregistration:** Records intended hypotheses and methods before results are examined, reducing some forms of selective reporting.
1474. **Random assignment:** Allocates participants to conditions by chance to reduce certain confounding influences in experiments.
1475. **Blinding in research:** Limits knowledge of assignments or conditions to reduce expectancy-related bias.
1476. **P-hacking:** Manipulates analytical choices or reporting to obtain apparently favorable statistical results.
1477. **Publication bias:** Makes positive or statistically notable findings more visible than unsuccessful or inconclusive studies.
1478. **Null-result reporting:** Preserves evidence that tested claims did not receive expected support, reducing repeated waste.
1479. **Research retractions:** Correct the formal scholarly record when publications contain sufficiently serious problems.
1480. **Reproducibility packages:** Supply code, data descriptions, methods, or other materials allowing independent examination of research findings.
## 13. Local government's daily machinery
1481. **Construction permits:** Establish authorization for specified building work; delayed processing can obstruct housing and economic activity.
1482. **Business registration procedures:** Create recognized operating records and legal responsibilities for enterprises.
1483. **Occupancy certificates:** Establish whether buildings satisfy requirements for intended use.
1484. **Property tax assessments:** Assign taxable property values under applicable rules; errors create unfair financial burdens.
1485. **Cadastral mapping:** Records legally relevant land parcels, boundaries, and identifiers used in ownership and administration.
1486. **Property title searches:** Examine recorded ownership interests and claims before important transactions.
1487. **Lien recording:** Makes specified legal claims against property visible to relevant parties.
1488. **Easements:** Permit defined uses of another person's land, such as access or utility passage; ambiguous terms create disputes.
1489. **Eminent domain procedures:** Permit qualifying public acquisition of property under legal constraints; misuse can cause severe injustice.
1490. **Zoning variances:** Allow specified exceptions from ordinary land-use rules after applicable review.
1491. **Planning notices:** Inform affected residents about proposed developments or policy changes before decisions occur.
1492. **Public land-use hearings:** Allow evidence and concerns about proposed uses to enter administrative decision-making.
1493. **Written public comments:** Preserve community objections, support, and technical information for institutional consideration.
1494. **Official meeting minutes:** Document decisions, attendance, and proceedings so institutional actions can be reconstructed.
1495. **Government transparency portals:** Publish public expenditures, contracts, decisions, and other records in accessible formats.
1496. **Public-records request processing:** Determines how members of the public obtain government documents subject to applicable disclosure laws.
1497. **Sanitation complaint investigation:** Identifies unsafe waste conditions and directs appropriate corrective responses.
1498. **Municipal service-request systems:** Route reports about local problems to relevant departments and track responses.
1499. **Graffiti remediation:** Restores damaged property or public surfaces; enforcement choices can raise disputes about expression and public priorities.
1500. **Pothole repair scheduling:** Allocates maintenance crews and materials according to road condition, traffic, and risk.
1501. **Sidewalk accessibility repairs:** Restore usable pedestrian routes when surfaces, obstructions, or designs restrict safe movement.
1502. **Snow and ice removal:** Maintains access during winter conditions; unequal service can isolate vulnerable neighborhoods.
1503. **Storm-drain maintenance:** Removes sediment and obstructions that otherwise increase localized flooding.
1504. **Traffic signal coordination:** Adjusts intersection timing to manage movement, delay, safety, and emergency access.
1505. **School crossing protection:** Coordinates infrastructure and personnel to reduce risks where children cross roads.
1506. **Parking permit systems:** Allocate scarce curb or facility space among residents, visitors, workers, and businesses.
1507. **Curb-space allocation:** Determines whether street edges serve deliveries, transit, parking, accessibility, or pedestrian activity.
1508. **Traffic citation administration:** Processes alleged roadway violations and provides mechanisms for payment or contest.
1509. **Vehicle impoundment procedures:** Remove or hold vehicles under defined authority; improper towing can cause substantial hardship.
1510. **Animal control operations:** Address stray animals, bites, cruelty reports, and public safety concerns.
1511. **Mosquito abatement:** Reduces disease-vector populations through surveillance and targeted interventions; measures carry ecological trade-offs.
1512. **Nuisance abatement hearings:** Determine whether certain property conditions violate local requirements and what remedies are permitted.
1513. **Code-inspection scheduling:** Coordinates inspections needed to verify buildings, businesses, and facilities comply with applicable standards.
1514. **Lead-hazard remediation:** Reduces exposure from contaminated paint, pipes, soil, or other sources, especially for children.
1515. **Brownfield redevelopment:** Attempts to restore previously contaminated or potentially contaminated land to productive use.
1516. **Utility shutoff protections:** Restrict termination of essential services under qualifying circumstances, balancing collection obligations against human needs.
1517. **Municipal bond issuance:** Raises money for qualifying public purposes while establishing future repayment obligations.
1518. **Special assessments:** Charge selected property owners for specified local improvements, potentially creating unequal burdens.
1519. **Local emergency mutual-aid agreements:** Allow nearby jurisdictions to share personnel and resources when one locality cannot meet an emergency alone.
1520. **Municipal annexation:** Changes local boundaries and responsibility for services, taxation, and representation.
## 14. National administration, macroeconomic policy, and institutional continuity
1521. **Population censuses:** Count and characterize populations for planning and representation; omissions can distort public resource allocation.
1522. **Official statistical sampling:** Estimates population characteristics without examining every individual; methodology affects reliability.
1523. **Population registries:** Maintain records of qualifying residents and demographic events, supporting services while requiring strong privacy safeguards.
1524. **Legislative apportionment:** Distributes representative seats among political subdivisions according to applicable rules.
1525. **Partisan redistricting:** Draws electoral boundaries to advantage particular political interests, potentially distorting representation.
1526. **Ballot-access requirements:** Determine which candidates or measures appear before voters; excessive barriers can reduce meaningful competition.
1527. **Campaign expenditure reporting:** Discloses selected political spending, allowing scrutiny of funding and influence.
1528. **Vote tabulation procedures:** Convert individual ballots into official totals; accuracy and verifiability are essential to legitimacy.
1529. **Election recounts:** Reexamine ballots or tallies under defined conditions to resolve sufficiently close or disputed outcomes.
1530. **Administrative transitions:** Transfer personnel, records, authorities, and responsibilities when political leadership changes.
1531. **Merit-based civil-service hiring:** Seeks to select public employees by demonstrated qualifications rather than personal political allegiance.
1532. **Political appointment processes:** Fill offices through specified selection and confirmation mechanisms, influencing institutional direction.
1533. **Executive orders:** Direct actions within executive authority; cannot legitimately supersede superior legal requirements.
1534. **Delegated rulemaking:** Allows authorized agencies to establish detailed operational regulations under legislative authority.
1535. **Regulatory impact assessments:** Estimate the likely consequences, costs, and benefits of proposed rules.
1536. **Agency responses to public comments:** Explain how submitted concerns or evidence affected regulatory decisions.
1537. **Sunset provisions:** Cause specified laws or authorities to expire unless renewed, creating opportunities for review.
1538. **Grandfather clauses:** Preserve selected existing arrangements when new requirements take effect; can create unequal regulatory treatment.
1539. **Ministerial responsibility:** Connects officials to the conduct of institutions they oversee under particular constitutional traditions.
1540. **Legislative oversight committees:** Examine executive implementation, spending, and institutional performance.
1541. **Legislative subpoena authority:** Compels qualifying testimony or records under applicable law, creating powerful investigative capabilities.
1542. **Inspectors general:** Independently examine certain public programs for waste, misconduct, and operational weaknesses.
1543. **Judicial review of administrative action:** Tests whether decisions or rules comply with governing legal standards.
1544. **Administrative guidance:** Communicates how agencies interpret or implement existing requirements; may influence behavior even when not independently binding.
1545. **Enforcement discretion:** Determines how limited regulatory resources are allocated among potential violations.
1546. **Revolving-door employment:** Moves personnel between regulators and regulated organizations, potentially transferring expertise or creating conflicts of interest.
1547. **Policy implementation gaps:** Separate officially adopted decisions from the actions and results that institutions actually deliver.
1548. **Unfunded mandates:** Assign duties to lower-level institutions without supplying sufficient resources.
1549. **Intergovernmental transfers:** Move public funds between levels of government, shaping local autonomy and service capacity.
1550. **Central-bank interest-rate decisions:** Influence credit conditions, spending, savings, employment, and inflation pressures.
1551. **Reserve requirements:** Establish specified holdings for qualifying financial institutions, affecting liquidity and the operation of monetary systems.
1552. **Central-bank asset purchases:** Alter financial conditions through purchases of selected securities; effects depend on economic circumstances.
1553. **Automatic fiscal stabilizers:** Change public revenue or benefit payments as economic conditions change without requiring a new legislative decision.
1554. **Fiscal multipliers:** Describe how changes in public spending or taxation influence wider economic activity.
1555. **Budget forecasting:** Estimates future government revenue, expenditures, and obligations; errors affect priorities and fiscal planning.
1556. **Statutory debt limits:** Constrain specified public borrowing authority and may generate financial disruption when unresolved.
1557. **National risk registers:** Organize recognized hazards and preparedness priorities; overlooked risks remain dangerous even when absent from official documents.
1558. **Information classification procedures:** Restrict specified sensitive government information; excessive classification obstructs accountability.
1559. **Declassification review:** Determines when previously restricted records may become accessible.
1560. **Continuity-of-government planning:** Establishes how lawful public authority and essential functions continue during extraordinary disruption.
## 15. Security, preparedness, and operational survivability
1561. **Threat modeling:** Identifies assets, potential attackers, vulnerable pathways, and plausible consequences before designing defenses.
1562. **Attack-surface analysis:** Identifies exposed components that could permit unauthorized access or harmful interference.
1563. **Adversarial risk assessment:** Examines how an intentional opponent might exploit a system's weaknesses rather than merely how accidents occur.
1564. **Role-based access control:** Assigns capabilities according to defined responsibilities, reducing unnecessary access.
1565. **Least-privilege enforcement:** Limits permissions to those required for a specific task, constraining damage from errors or compromise.
1566. **Multifactor authentication:** Combines distinct forms of verification to reduce dependence on a single compromised credential.
1567. **Secret management:** Protects passwords, signing keys, and tokens throughout their storage and use.
1568. **Credential rotation:** Replaces authentication material periodically or after suspected compromise.
1569. **Security patch management:** Identifies, tests, and deploys corrections to known vulnerabilities.
1570. **Coordinated vulnerability disclosure:** Gives researchers and maintainers a structured process for reporting and correcting security weaknesses.
1571. **Bug bounty programs:** Reward qualifying vulnerability reports; poorly structured incentives can create disputes or unnecessary disclosure risks.
1572. **Malware signature detection:** Compares suspicious material with known malicious patterns; novel or modified threats may evade it.
1573. **Behavioral intrusion detection:** Recognizes unusual activity that may indicate compromise even without a known malicious signature.
1574. **Tamper-resistant logging:** Makes alteration or removal of relevant records detectable, supporting investigations and accountability.
1575. **Security anomaly investigation:** Examines suspicious deviations to distinguish actual incidents from harmless variation.
1576. **Insider-threat assessment:** Evaluates risks arising from people with legitimate access, including malicious conduct and accidental harm.
1577. **Social-engineering resistance:** Recognizes attempts to obtain cooperation through impersonation, pressure, or manipulation of human expectations.
1578. **Security-awareness simulations:** Test whether workers recognize common deception methods; careless exercises can damage organizational trust.
1579. **Physical access badges:** Restrict movement through selected facilities; stolen credentials or inappropriate permissions create vulnerabilities.
1580. **Visitor access records:** Document temporary entry into controlled spaces, helping reconstruct incidents and manage physical security.
1581. **Tamper-evident seals:** Reveal certain attempts to open or alter protected goods, containers, or equipment.
1582. **Incident-command structures:** Establish responsibilities and communication pathways during complex emergencies.
1583. **Emergency operations centers:** Coordinate information, personnel, resources, and decisions during major incidents.
1584. **Emergency radio interoperability:** Enables different responders and agencies to communicate when ordinary networks are inadequate.
1585. **Dispatch-system redundancy:** Preserves emergency communications when primary equipment or facilities fail.
1586. **Backup power systems:** Keep essential services operating during electricity interruptions; insufficient testing can create false confidence.
1587. **Automatic failover:** Transfers functions to alternative equipment or services after certain failures.
1588. **Data backup policies:** Preserve recoverable copies of important information against deletion, corruption, or disasters.
1589. **Restore testing:** Verifies that backed-up information can actually be recovered when needed.
1590. **Business-continuity plans:** Establish essential functions and temporary arrangements for operating through disruptions.
1591. **Disaster-recovery procedures:** Rebuild affected technological or physical systems after major failures.
1592. **Tabletop exercises:** Test emergency decisions through structured scenarios before actual incidents occur.
1593. **Operational stress drills:** Examine whether people, equipment, and procedures function under demanding conditions.
1594. **Controlled load shedding:** Temporarily reduces selected demand to protect critical infrastructure from wider failure.
1595. **Single-point-of-failure analysis:** Finds components whose loss could disable an otherwise complex system.
1596. **Evacuation-route planning:** Identifies safe movement pathways, capacities, and procedures for leaving dangerous areas.
1597. **Shelter-in-place procedures:** Protect people when remaining inside a suitable location is safer than evacuation.
1598. **Hazard communication signage:** Warns of physical, chemical, biological, or operational dangers; unclear symbols can cause mistakes.
1599. **Mutual-assistance compacts:** Define reciprocal emergency obligations between organizations or jurisdictions.
1600. **Post-incident corrective-action tracking:** Converts lessons from failures into assigned, verifiable improvements rather than leaving them as reports.
## 16. The engineering systems underneath digital civilization
1601. **Domain Name System resolution:** Converts human-readable internet names into technical destinations; failures can make otherwise functioning services inaccessible.
1602. **Domain registration governance:** Determines who controls internet names and how disputes or transfers are handled.
1603. **Internet routing protocols:** Coordinate how traffic travels between networks; incorrect routing information can redirect or interrupt communications.
1604. **Network peering:** Establishes direct exchanges of traffic between networks, influencing performance, costs, and internet connectivity.
1605. **Packet switching:** Divides digital communication into manageable units that travel through networks and are reassembled at their destination.
1606. **Submarine communication cables:** Carry substantial international data traffic; cable damage and geographic chokepoints create strategic vulnerabilities.
1607. **Fiber-optic backhaul:** Connects local networks to high-capacity communication infrastructure; insufficient capacity restricts access and performance.
1608. **Cellular base-station coordination:** Manages mobile-device connections across coverage areas; failures affect communications, navigation, and emergency contact.
1609. **Radio-frequency spectrum allocation:** Assigns or coordinates access to finite electromagnetic bands, balancing commercial, civilian, scientific, and security needs.
1610. **Network congestion control:** Adjusts traffic behavior when available communication capacity becomes constrained.
1611. **Latency budgets:** Define acceptable delays for technical operations; exceeding them can disrupt real-time services and coordinated systems.
1612. **Content delivery networks:** Replicate commonly requested material closer to users, improving speed while creating infrastructure dependencies.
1613. **Local data caching:** Temporarily stores information to reduce repeated computation or retrieval; stale data can cause inconsistent behavior.
1614. **Load balancers:** Distribute requests across multiple computing resources, improving capacity and availability.
1615. **Distributed denial-of-service mitigation:** Limits malicious traffic intended to overwhelm services without unnecessarily blocking legitimate users.
1616. **Transport encryption certificates:** Establish verifiable cryptographic identities for secure network connections; expiration or compromise can interrupt trust.
1617. **Certificate authorities:** Issue and validate digital certificates; compromised authorities can undermine security across many systems.
1618. **Operating-system scheduling:** Allocates processor time and computing resources among competing applications.
1619. **Device firmware:** Controls hardware-level functions; defects or malicious modifications can persist beneath ordinary software protections.
1620. **Hardware drivers:** Translate operating-system commands into device-specific operations; incompatible drivers can cause widespread instability.
1621. **Application programming interfaces:** Define how independent software components communicate; unstable interfaces propagate integration failures.
1622. **API rate limiting:** Restricts request frequency to manage resources and abuse; poorly designed limits may obstruct legitimate activity.
1623. **Distributed consensus protocols:** Coordinate agreement among separate computing nodes despite delays or certain failures.
1624. **Database transaction isolation:** Prevents concurrent operations from interfering in unacceptable ways; weaker guarantees may create inconsistent records.
1625. **Database schema design:** Defines data structure, relationships, and constraints; poor design undermines integrity and future expansion.
1626. **Schema migrations:** Change persistent data structures while attempting to preserve existing information and operational continuity.
1627. **Data replication:** Maintains multiple copies of information for performance or recovery; synchronization errors can produce conflicting states.
1628. **Version-control histories:** Preserve changes and authorship information, allowing developers to inspect or reverse modifications.
1629. **Source-code review:** Examines proposed changes before integration; superficial review creates an appearance of scrutiny without meaningful protection.
1630. **Build systems:** Convert source material into executable or deployable artifacts through defined processes.
1631. **Software package registries:** Distribute reusable components; compromised packages can propagate malicious behavior through dependent projects.
1632. **Dependency pinning:** Restricts external component versions to improve reproducibility; excessive rigidity can delay security updates.
1633. **Semantic versioning:** Communicates expected compatibility changes through release identifiers, supporting coordination among dependent systems.
1634. **Continuous integration:** Repeatedly builds and checks proposed changes; inadequate tests allow defects to survive automated gates.
1635. **Continuous deployment:** Releases verified changes through automated processes; weak controls increase the speed at which mistakes spread.
1636. **Feature flags:** Enable selected functionality without rebuilding whole systems; abandoned flags increase complexity and configuration risk.
1637. **Deployment rollback:** Restores earlier functioning versions after harmful changes, provided data and infrastructure remain compatible.
1638. **Distributed tracing:** Follows operations across services to reveal delays, failures, and dependencies otherwise difficult to observe.
1639. **Service-level objectives:** Define measurable expectations for availability or performance, helping organizations balance reliability against development speed.
1640. **Alert routing:** Determines which operational warnings reach responsible people; inaccurate routing can overwhelm workers or leave critical failures unnoticed.
## 17. Artificial intelligence, inference systems, and agent behavior
1641. **Tokenization:** Converts text or other information into units processed by language models; token counts do not directly measure understanding.
1642. **Context-window allocation:** Determines how much information a model can attend to in a particular request; exceeding capacity requires alternative handling.
1643. **Context compaction:** Condenses prior information to preserve relevant continuity within limited processing capacity; compression can discard crucial distinctions.
1644. **Prompt construction:** Selects instructions and context intended to guide model behavior; ambiguous or conflicting prompts reduce reliability.
1645. **Instruction precedence:** Establishes how competing directions are prioritized, affecting whether user requests or untrusted material can redirect execution.
1646. **Retrieval-augmented generation:** Supplies externally retrieved information to a model; unreliable retrieval can introduce inaccurate or adversarial material.
1647. **Vector embeddings:** Represent information numerically to support similarity search and other computational tasks; proximity does not guarantee factual equivalence.
1648. **Vector-index maintenance:** Organizes and updates searchable representations; stale indexes can conceal newer or contradictory information.
1649. **Model parameter storage:** Preserves numerical values learned through training; storage integrity affects reproducibility and behavior.
1650. **Training-data curation:** Selects and filters learning material; omissions, duplication, contamination, or poor quality affect resulting capabilities.
1651. **Data annotation:** Attaches labels or judgments to examples; inconsistent annotation can encode human error into automated systems.
1652. **Synthetic training examples:** Generate artificial learning material; can improve coverage or amplify defects when poorly evaluated.
1653. **Pretraining objectives:** Establish what statistical patterns a model learns before specialized adaptation.
1654. **Task-specific fine-tuning:** Adjusts model behavior toward selected capabilities; can improve specialization while weakening other behavior.
1655. **Preference optimization:** Uses comparison or reward signals to favor selected responses; flawed preferences can encourage superficial compliance.
1656. **Model distillation:** Trains smaller models to reproduce aspects of larger systems; efficiency improvements may come with capability losses.
1657. **Model quantization:** Represents parameters at reduced numerical precision, lowering memory requirements while potentially changing outputs.
1658. **Inference batching:** Processes multiple requests together to improve hardware utilization; may increase waiting time for individual requests.
1659. **GPU scheduling:** Allocates accelerator resources among workloads; contention affects throughput, cost, and responsiveness.
1660. **Memory-bandwidth constraints:** Limit how quickly models can access required data, independently of raw computational capacity.
1661. **Model routing:** Directs tasks toward different models based on requirements, costs, or capabilities; poor routing can degrade outcomes.
1662. **Multi-agent orchestration:** Coordinates specialized model processes, their dependencies, and their outputs; introduces communication and accountability problems.
1663. **Tool invocation protocols:** Allow models to request operations from external systems; incorrect argument construction can create unintended effects.
1664. **Action authorization gates:** Determine whether an AI-requested operation is permitted before external consequences occur.
1665. **Prompt-injection attacks:** Attempt to convert untrusted content into instructions that override authorized objectives.
1666. **AI-mediated data exfiltration:** Occurs when a compromised workflow reveals protected information through outputs or unauthorized tool actions.
1667. **Model hallucination:** Produces unsupported or incorrect assertions that may appear fluent and confident.
1668. **Evidence grounding:** Connects generated conclusions to relevant information that can be examined independently.
1669. **Structured output constraints:** Require model responses to follow predefined formats; valid formatting does not guarantee valid reasoning.
1670. **Tool-result validation:** Examines external outputs before they influence decisions or execution, reducing reliance on malformed or manipulated data.
1671. **AI evaluation suites:** Test performance across specified tasks; incomplete evaluations can conceal serious weaknesses.
1672. **Benchmark contamination:** Occurs when evaluation examples appear in training material, making performance measurements misleading.
1673. **Evaluation-data leakage:** Allows information intended to remain hidden during testing to influence a system's answers.
1674. **Adversarial AI testing:** Deliberately probes systems with difficult, misleading, or hostile inputs to discover failure modes.
1675. **Capability generalization failures:** Occur when performance on familiar tasks does not transfer reliably to different circumstances.
1676. **Overrefusal and underrefusal:** Represent opposite errors in how AI systems distinguish legitimate requests from requests requiring restriction.
1677. **AI uncertainty calibration:** Evaluates whether expressed confidence corresponds appropriately to actual reliability.
1678. **Agent-memory poisoning:** Introduces malicious or misleading information into material an agent may later trust.
1679. **Autonomous action provenance:** Preserves which instructions, tools, evidence, and authorizations produced consequential system actions.
1680. **Cryptographically signed execution receipts:** Make specified actions or decisions independently verifiable against recorded evidence and authorized identities.
## 18. The machinery of publicity, persuasion, and mass perception
1681. **Media agenda-setting:** Determines which issues receive attention and therefore become salient in public discussion.
1682. **Editorial framing:** Selects which aspects of events are emphasized, influencing how audiences understand causation and responsibility.
1683. **Priming through repeated coverage:** Makes particular criteria more prominent when audiences judge people or institutions.
1684. **Headline optimization:** Uses wording and presentation to attract attention; excessive optimization can sacrifice accuracy and context.
1685. **News-cycle compression:** Reduces the time available to investigate and interpret events before public narratives form.
1686. **Breaking-news alerts:** Distribute urgent information rapidly; premature reporting can spread significant inaccuracies.
1687. **Published corrections:** Amend identifiable reporting errors; low-visibility corrections may not reach original audiences.
1688. **Article withdrawal procedures:** Remove or revise fundamentally defective reporting; transparency affects public confidence.
1689. **Independent fact-checking:** Evaluates particular factual claims against available evidence, subject to the quality and scope of the investigation.
1690. **Confidential source protection:** Encourages disclosure of information from vulnerable sources; anonymity also complicates verification.
1691. **Unauthorized disclosures:** Reveal restricted information, sometimes exposing misconduct and sometimes threatening legitimate privacy or security.
1692. **Editorial conflicts of interest:** Arise when financial, political, or personal relationships could influence coverage.
1693. **Newswire distribution:** Supplies reporting to multiple publishers, allowing information and mistakes alike to spread rapidly.
1694. **Newsroom revenue models:** Determine whether journalism depends on subscriptions, advertisements, philanthropy, public support, or other sources.
1695. **Information paywalls:** Finance some reporting while restricting access for audiences unable or unwilling to pay.
1696. **Media ownership concentration:** Places multiple information outlets under common control, affecting competition and editorial independence.
1697. **Sponsored editorial material:** Blends advertising and informational presentation, requiring clear disclosure to prevent deception.
1698. **Native advertising:** Presents paid messages in formats resembling surrounding content, potentially obscuring commercial intent.
1699. **Influencer sponsorships:** Convert personal audience relationships into marketing influence; undisclosed compensation distorts perceived independence.
1700. **Behavioral advertising:** Selects advertisements using observed or inferred characteristics, creating both commercial relevance and privacy concerns.
1701. **Political microtargeting:** Tailors persuasive messages to specific groups, potentially reducing public visibility into competing campaign claims.
1702. **Recommendation feedback amplification:** Repeatedly promotes material receiving strong engagement, reinforcing particular patterns of public attention.
1703. **Filter bubbles:** Personalized information environments may reduce exposure to unfamiliar perspectives, though their extent varies across users and platforms.
1704. **Echo chambers:** Social environments reinforce shared beliefs while discounting outsiders' information and credibility.
1705. **Engagement bait:** Encourages interactions primarily to satisfy platform-ranking incentives rather than contribute meaningful information.
1706. **Outrage monetization:** Converts anger and controversy into attention, traffic, influence, or revenue.
1707. **Astroturfing:** Manufactures the appearance of spontaneous public support through coordinated or deceptive activity.
1708. **Automated amplification networks:** Use software accounts to magnify selected messages or create misleading perceptions of popularity.
1709. **Coordinated inauthentic behavior:** Organizes deceptive participation across multiple accounts or identities to manipulate perception.
1710. **Synthetic audiovisual impersonation:** Produces convincing artificial recordings of people, creating fraud and evidentiary authenticity risks.
1711. **Media provenance verification:** Examines where recordings or documents originated and whether they have been altered.
1712. **Information laundering:** Moves unsupported claims through intermediaries until repetition makes them appear independently corroborated.
1713. **Selective video clipping:** Removes surrounding events or dialogue, potentially changing how an incident is understood.
1714. **Quotation without context:** Preserves someone's words while omitting circumstances essential to interpreting their meaning.
1715. **Plausible deniability through humor:** Allows speakers to advance controversial messages while claiming they were merely joking.
1716. **Platform enforcement transparency:** Determines whether users can understand content restrictions, account penalties, and appeal mechanisms.
1717. **Deplatforming decisions:** Remove access to particular distribution services; may limit abuse while concentrating private power over public visibility.
1718. **Visibility throttling:** Reduces the distribution of selected content without necessarily removing it; opaque application complicates accountability.
1719. **Right-of-reply procedures:** Provide affected individuals opportunities to respond to published claims under applicable rules or editorial standards.
1720. **Ephemeral content:** Makes communication disappear after a defined period, changing social expectations and the preservation of evidence.
## 19. Specific methods of fraud, coercion, and institutional abuse
1721. **Account takeover:** Uses unauthorized access to control another person's digital services, assets, or identity.
1722. **SIM-swap fraud:** Illicitly transfers control of a telephone number to defeat account protections or intercept communications.
1723. **Synthetic identity fraud:** Combines real and fabricated personal information to create deceptive financial or administrative identities.
1724. **Romance fraud:** Exploits manufactured intimacy to obtain money, information, or other benefits from targeted individuals.
1725. **Advance-fee fraud:** Demands upfront payment for promised benefits that are not delivered.
1726. **Fraudulent employment offers:** Misrepresent jobs to extract money, personal information, labor, or access to equipment.
1727. **False-invoice schemes:** Submit fabricated or altered payment requests to organizations that may process them without adequate verification.
1728. **Business-email compromise:** Uses impersonated or compromised business communication to redirect payments or sensitive information.
1729. **Technical-support impersonation:** Falsely claims to provide assistance in order to obtain payment, access, or credentials.
1730. **Recovery scams:** Target people already harmed by fraud with false promises to retrieve lost money or assets.
1731. **Money-mule accounts:** Move funds on behalf of illicit actors, sometimes using recruited individuals who misunderstand the activity.
1732. **Mule recruitment networks:** Obtain access to accounts or intermediaries through deception, compensation, pressure, or coercion.
1733. **Abusive shell-company structures:** Conceal responsibility or ownership through entities that obscure the people directing transactions.
1734. **Trade-based financial concealment:** Manipulates trade records or transactions to disguise the movement or origins of value.
1735. **Commercial invoice manipulation:** Misstates quantities, descriptions, or values to misdirect money or avoid obligations.
1736. **Cash-business concealment:** Misrepresents legitimate business receipts to disguise unrelated funds or distort financial records.
1737. **Nominee ownership arrangements:** Place assets or entities in another person's name, sometimes for legitimate purposes and sometimes to conceal actual control.
1738. **Bid rigging:** Manipulates supposedly competitive procurement through coordinated conduct among participants.
1739. **Kickback arrangements:** Return part of an improper payment or contract benefit to someone who facilitated the transaction.
1740. **Ghost-employee payroll fraud:** Creates or retains fictitious or unauthorized employee records to divert compensation.
1741. **Fraudulent charitable organizations:** Misrepresent humanitarian or social missions to solicit and misuse contributions.
1742. **Donor impersonation:** Misuses the identity of legitimate supporters or organizations to influence contributions or obtain information.
1743. **Document forgery:** Falsifies or alters records intended to establish identity, authorization, qualifications, or rights.
1744. **Deceptive labor recruitment:** Misrepresents employment conditions, migration opportunities, or fees to exploit prospective workers.
1745. **Passport confiscation:** Restricts mobility and autonomy by improperly withholding another person's travel documents.
1746. **Coercive wage withholding:** Uses unpaid compensation as leverage to prevent workers from leaving or challenging abusive conditions.
1747. **Housing-linked labor coercion:** Makes shelter contingent on continued work under unfair or threatening circumstances.
1748. **Coordinated retail theft:** Organizes repeated theft of merchandise for illicit redistribution or resale.
1749. **Cargo theft networks:** Target goods during storage or transportation, disrupting supply chains and creating financial losses.
1750. **Fuel diversion:** Illegally redirects fuel from authorized recipients or systems, sometimes compromising essential services.
1751. **Illegal waste dumping:** Avoids lawful disposal costs while shifting contamination, cleanup, and health risks onto communities.
1752. **Wildlife trafficking networks:** Illegally move protected organisms or wildlife products, threatening biodiversity and public health.
1753. **Unreported and unregulated fishing operations:** Remove marine resources outside applicable management systems, undermining conservation and lawful livelihoods.
1754. **Subcontractor exploitation chains:** Distribute labor through intermediaries in ways that can obscure responsibility for abuse.
1755. **Witness intimidation:** Uses threats or pressure to prevent testimony, reporting, or cooperation with investigations.
1756. **Jury tampering:** Improperly influences jurors or jury proceedings to distort adjudication.
1757. **Evidence destruction:** Removes or damages material relevant to investigations, preventing accurate reconstruction of events.
1758. **Strategic lawsuits against public participation:** Use burdensome litigation to deter criticism, reporting, or civic involvement.
1759. **Coercive informal prison economies:** Develop around scarce goods, favors, threats, and unequal access within confinement.
1760. **Post-incarceration access barriers:** Restrict employment, housing, licensing, and services after release, potentially reinforcing repeated instability.
## 20. How international power actually operates
1761. **The security dilemma:** One country's defensive preparations can appear threatening to others, producing mutually reinforcing military escalation.
1762. **Balance-of-power behavior:** States organize capabilities and relationships to prevent another actor from achieving overwhelming influence.
1763. **Alliance credibility:** Depends on whether partners believe promised assistance will be delivered under difficult circumstances.
1764. **Alliance entrapment:** Occurs when a state's commitments draw it into conflicts it might otherwise avoid.
1765. **Defense burden sharing:** Allocates military and financial responsibilities among partners, often generating disputes about fairness.
1766. **Extended deterrence:** Attempts to discourage threats against allies by offering protective commitments backed by national capabilities.
1767. **Strategic ambiguity:** Deliberately avoids specifying some intended responses, preserving flexibility while introducing uncertainty.
1768. **Escalation management:** Attempts to prevent limited confrontations from expanding into wider or more destructive conflicts.
1769. **Crisis communication hotlines:** Provide direct contact between governments during high-risk incidents, reducing misunderstanding.
1770. **Backchannel negotiations:** Allow sensitive communication outside normal public diplomatic procedures.
1771. **Diplomatic immunity:** Protects qualifying officials from certain host-country legal processes, supporting diplomacy while creating potential accountability disputes.
1772. **Persona non grata declarations:** Require specified foreign diplomatic personnel to leave under recognized international procedures.
1773. **Diplomatic protocol:** Establishes formal expectations regarding representation, precedence, communication, and ceremonial treatment.
1774. **Recognition of governments and states:** Influences whether political authorities are treated as legitimate participants in international relations.
1775. **Border demarcation disputes:** Concern where legally or politically accepted territorial boundaries actually lie.
1776. **Buffer territories:** Separate competing powers geographically, sometimes reducing direct confrontation and sometimes compromising local autonomy.
1777. **Demilitarized zones:** Restrict military activity within designated areas under particular agreements.
1778. **Military confidence-building measures:** Exchange information or establish procedures to reduce accidental escalation.
1779. **Arms-control verification inspections:** Examine whether parties comply with specified military restrictions or reporting obligations.
1780. **Dual-use export controls:** Regulate technologies useful for both civilian and military purposes, creating trade and research tensions.
1781. **End-use certifications:** Record intended recipients and uses of controlled exports; false declarations can undermine restrictions.
1782. **Technology-transfer restrictions:** Limit the sharing of selected capabilities with foreign actors for strategic or security reasons.
1783. **Sanctions-evasion networks:** Attempt to circumvent international economic restrictions through intermediaries, deceptive records, or alternative routes.
1784. **Secondary sanctions:** Threaten consequences for certain third parties dealing with sanctioned actors, extending economic influence beyond direct jurisdiction.
1785. **Maritime chokepoints:** Concentrate global shipping through narrow passages where interruption can affect distant economies.
1786. **Flags of convenience:** Register vessels under jurisdictions offering particular commercial or regulatory conditions, sometimes complicating oversight.
1787. **Exclusive economic zones:** Allocate significant coastal resource rights under international maritime frameworks.
1788. **Transboundary water negotiations:** Coordinate use of rivers, aquifers, and other water systems shared across political borders.
1789. **International arbitration compliance:** Determines whether parties honor decisions rendered through agreed dispute-resolution procedures.
1790. **Sovereign credit ratings:** Communicate assessments of government creditworthiness; influence borrowing conditions and investor perceptions.
1791. **Sovereign debt workouts:** Renegotiate unsustainable government obligations among debtors and creditors with competing priorities.
1792. **Sovereign wealth fund allocation:** Invests state-owned financial assets, potentially supporting future public needs and strategic influence.
1793. **Resource-curse dynamics:** Describe how substantial extractive wealth can coincide with weak institutions, concentrated power, or economic instability.
1794. **Dutch disease:** Occurs when a booming export sector contributes to conditions that weaken other tradable industries.
1795. **Foreign-exchange reserve management:** Determines how monetary authorities maintain liquid international assets for financial and policy purposes.
1796. **Humanitarian exemptions to economic restrictions:** Seek to preserve access to essential goods and services despite wider sanctions.
1797. **Statelessness:** Leaves individuals without nationality under the laws of any state, often severely restricting rights and practical participation.
1798. **Refugee resettlement allocation:** Determines how qualifying displaced people are admitted and supported across participating countries.
1799. **Remittance transfer infrastructure:** Moves earnings across borders to recipient households; fees and access restrictions reduce usable support.
1800. **International standards diplomacy:** Uses technical committees, negotiations, and institutional participation to influence the rules governing globally shared systems.
## 21. The protective procedures society depends on during its worst moments
1801. **Poll-worker certification:** Prepares election personnel to handle ballots, equipment, records, and voter questions under applicable procedures.
1802. **Independent election observation:** Provides additional scrutiny of electoral activity without transferring lawful responsibility from authorized officials.
1803. **Accessible polling arrangements:** Make voting practical for eligible people facing physical, sensory, cognitive, or communication barriers.
1804. **Ballot-curing procedures:** Allow eligible voters to correct specified ballot deficiencies before final rejection.
1805. **Emergency protective orders:** Provide rapid legal restrictions intended to prevent qualifying threats or abuse, subject to applicable legal safeguards.
1806. **Emergency shelter intake:** Identifies immediate safety, accessibility, medical, and accommodation needs when people seek temporary protection.
1807. **Shelter diversion assistance:** Attempts to identify safe alternatives to emergency shelter when appropriate and genuinely available.
1808. **Street-outreach engagement:** Builds contact with people experiencing homelessness or other severe vulnerability, often without requiring immediate participation in formal programs.
1809. **Coordinated housing entry systems:** Organize assessment and referrals across homelessness-response providers; flawed prioritization can leave high-need people unserved.
1810. **Supportive-housing case coordination:** Connects stable housing with appropriate services for people facing complex barriers.
1811. **Eviction-prevention intervention:** Uses financial assistance, negotiation, or other lawful measures to prevent avoidable housing displacement.
1812. **Tenant-defense assistance:** Helps renters understand and exercise available protections during disputes and eviction proceedings.
1813. **Pro bono legal representation:** Supplies professional services without ordinary fees to qualifying people or causes.
1814. **Community bail assistance:** Helps qualifying defendants secure pretrial release while navigating concerns about fairness and risk.
1815. **Witness-protection arrangements:** Reduce exposure to retaliation when people cooperate with consequential investigations.
1816. **Forensic interviewing of children:** Uses developmentally appropriate methods to investigate alleged harm while minimizing suggestion and additional distress.
1817. **Mandatory-reporting procedures:** Establish when specified professionals must report suspected abuse or neglect, requiring careful standards and safeguards.
1818. **Survivor-centered response protocols:** Prioritize safety, informed choice, privacy, and dignity when assisting people affected by serious abuse.
1819. **Sexual-assault forensic examinations:** Collect and preserve potential medical and evidentiary information while respecting the patient's applicable choices and rights.
1820. **Anonymous reporting mechanisms:** Allow certain concerns to be disclosed without immediate public identification, although anonymity may complicate investigation.
1821. **Witness accommodations:** Adjust legal proceedings to support people who face particular safety, disability, or communication barriers.
1822. **Independent complaint investigators:** Examine alleged institutional misconduct outside the ordinary authority of the accused organization.
1823. **Civilian oversight panels:** Provide public participation in reviewing selected public-safety policies, incidents, or patterns.
1824. **Use-of-force documentation:** Records the circumstances, justification, and consequences of force applied by officials.
1825. **Body-worn recording systems:** Preserve selected encounters for review; recording gaps, access rules, and privacy safeguards remain consequential.
1826. **Evidence-preservation holds:** Suspend routine destruction of records when material may be relevant to an investigation or legal proceeding.
1827. **Detention medical oversight:** Examines whether confined individuals receive necessary healthcare and protection from preventable harm.
1828. **Independent detention inspections:** Evaluate confinement conditions, safeguards, and institutional conduct beyond internal self-reporting.
1829. **Reentry service coordination:** Connects people leaving confinement with identification, housing, healthcare, and employment resources.
1830. **Disaster survivor registration:** Records individuals requesting assistance so needs, locations, and service delivery can be coordinated.
1831. **Family reunification operations:** Help locate and reconnect relatives separated by emergencies, evacuation, or institutional failures.
1832. **Accessible emergency alerts:** Communicate danger through multiple suitable formats so warnings reach people with different needs.
1833. **Disaster-assistance eligibility assessment:** Determines access to relief resources; complex criteria can exclude people facing urgent hardship.
1834. **Disaster debris management:** Removes dangerous wreckage while addressing hazardous materials, property rights, and environmental contamination.
1835. **Post-disaster damage assessment:** Establishes the extent of physical losses to guide repairs, assistance, and insurance decisions.
1836. **Temporary displacement housing:** Provides short-term accommodation while permanent living arrangements are unavailable.
1837. **Quarantine support services:** Help affected people obtain food, medication, income assistance, and other necessities during required movement restrictions.
1838. **Disaster victim identification:** Uses medical, scientific, documentary, and investigative methods to identify people who have died.
1839. **Unidentified-person case coordination:** Connects forensic records, missing-person reports, and investigative agencies to resolve uncertain identities.
1840. **Community recovery after mass trauma:** Addresses disrupted relationships, public spaces, livelihoods, remembrance, and long-term needs following collective catastrophe.
## 22. The physical feedback mechanisms governing planetary stability
1841. **Planetary albedo:** Determines how much incoming sunlight is reflected rather than absorbed; changes influence Earth's energy balance.
1842. **Urban heat islands:** Make developed areas warmer than their surroundings through building materials, reduced vegetation, and concentrated heat.
1843. **Tree-canopy cooling:** Provides shade and influences local temperature through evapotranspiration; unequal canopy coverage creates unequal heat exposure.
1844. **Atmospheric rivers:** Transport large quantities of water vapor and can contribute to essential precipitation or destructive flooding.
1845. **Mountain snowpack storage:** Delays seasonal water release, sustaining downstream ecosystems, agriculture, and communities.
1846. **Glacier retreat:** Changes freshwater availability, landscapes, hazards, and sea level over varying time horizons.
1847. **Ocean acidification:** Alters seawater chemistry as carbon dioxide is absorbed, affecting some marine organisms and ecosystems.
1848. **Sea-level rise:** Changes coastal flood risks, infrastructure requirements, ecosystems, and the long-term viability of settlements.
1849. **Saltwater intrusion:** Introduces saline water into freshwater systems, threatening drinking supplies and agricultural land.
1850. **Storm-surge amplification:** Raises coastal water levels during severe weather, potentially overwhelming flood defenses.
1851. **Managed coastal retreat:** Relocates people or infrastructure away from increasing hazards; creates major social, financial, and cultural consequences.
1852. **Coastal marsh buffering:** Reduces some wave energy and supports habitats; degradation weakens protective ecological functions.
1853. **Coral bleaching:** Occurs when stressed corals lose or expel symbiotic organisms, potentially threatening reef survival.
1854. **Marine heatwaves:** Create unusually warm ocean conditions that can damage fisheries, habitats, and coastal economies.
1855. **Ocean deoxygenation:** Reduces dissolved oxygen available to marine life, changing habitats and species distributions.
1856. **Large-scale ocean circulation:** Redistributes heat, nutrients, and water properties across the planet; changes can affect regional climates.
1857. **Microplastic accumulation:** Disperses small plastic particles through ecosystems and food webs, creating difficult monitoring and remediation problems.
1858. **Persistent chemical contamination:** Allows some industrial compounds to remain in water, soil, organisms, or human environments for extended periods.
1859. **Particulate air pollution:** Exposes populations to fine airborne matter associated with respiratory and cardiovascular harm.
1860. **Environmental noise exposure:** Affects sleep, concentration, communication, and health, especially near transportation and industrial activity.
1861. **Artificial light pollution:** Alters nighttime environments and can affect wildlife, human sleep, and astronomical observation.
1862. **Occupational heat exposure:** Increases risks for workers in hot conditions, requiring protective scheduling, hydration, rest, and environmental controls.
1863. **Extreme-heat vulnerability:** Depends on temperature, health, housing, cooling access, and social isolation; consequences vary across populations.
1864. **Permafrost thaw:** Changes ground stability, ecosystems, infrastructure conditions, and the release of stored carbon.
1865. **Peatland combustion:** Can release substantial stored carbon and create persistent fires difficult to detect or extinguish.
1866. **Methane leakage:** Releases a potent greenhouse gas from relevant infrastructure and natural or industrial activities.
1867. **Vegetated roofing:** Uses plant-covered roof systems to influence temperature, runoff, and building performance.
1868. **Permeable pavement:** Allows some rainfall to infiltrate rather than immediately enter conventional drainage systems.
1869. **Rain gardens:** Use designed vegetation and soils to temporarily capture and filter stormwater.
1870. **Distributed stormwater infrastructure:** Manages runoff across numerous smaller installations rather than relying exclusively on centralized structures.
1871. **Environmental impact statements:** Examine specified potential consequences of proposed activities before relevant decisions are made.
1872. **Strategic environmental assessment:** Evaluates environmental considerations at the level of policies, plans, or programs.
1873. **Hazardous-waste manifests:** Track regulated materials during transfer, transportation, and disposal.
1874. **Electronic waste recovery:** Reclaims useful materials from discarded equipment while requiring protection against toxic exposures.
1875. **Critical-mineral refining:** Converts extracted materials into forms suitable for advanced manufacturing, creating industrial dependencies and environmental burdens.
1876. **Mine-tailings containment:** Manages waste from mineral processing; failures can cause catastrophic contamination.
1877. **Environmental financial assurance:** Requires designated operators to provide funds or guarantees for future remediation obligations.
1878. **Environmental sensor networks:** Collect repeated measurements of air, water, climate, or ecosystems; poor calibration can distort findings.
1879. **Community environmental observations:** Allow residents to report local conditions and contribute evidence to scientific or regulatory processes.
1880. **Climate-related relocation planning:** Coordinates housing, rights, livelihoods, and infrastructure when communities face worsening environmental conditions.
## 23. Engineering assurance and the distinction between activity and correctness
1881. **Requirements elicitation:** Establishes what stakeholders and affected parties actually need before a system is designed.
1882. **Requirements traceability:** Connects obligations to design elements, implementations, and evidence demonstrating whether they are satisfied.
1883. **Testable acceptance criteria:** Define observable conditions for recognizing satisfactory performance.
1884. **Interface contracts:** Specify what interacting components may assume, provide, reject, or require.
1885. **System invariants:** Establish properties that must remain true across permitted operations and state transitions.
1886. **Type systems:** Constrain how program values may be represented and combined, preventing certain categories of mistakes.
1887. **Formal specifications:** Express system behavior and constraints in precise models suitable for rigorous examination.
1888. **Model checking:** Systematically examines modeled states and transitions for violations of specified properties.
1889. **Static code analysis:** Evaluates software without executing it to detect selected defects, vulnerabilities, or inconsistencies.
1890. **Dynamic program analysis:** Examines executing software to identify behavior, faults, and runtime vulnerabilities.
1891. **Unit tests:** Examine individual components under controlled conditions; successful unit tests do not establish whole-system correctness.
1892. **Integration tests:** Verify interactions among connected components, exposing failures absent from isolated component tests.
1893. **System-level tests:** Evaluate assembled systems against defined requirements and operating expectations.
1894. **End-to-end tests:** Exercise complete operational workflows across participating components.
1895. **Performance benchmarking:** Measures resource use and execution behavior under defined conditions; unsuitable benchmarks can create misleading confidence.
1896. **Software load testing:** Examines behavior under anticipated or extreme demand, identifying bottlenecks and failure thresholds.
1897. **Chaos engineering:** Introduces controlled disruptions to investigate resilience and recovery capabilities.
1898. **Fuzz testing:** Supplies varied or malformed inputs to identify unexpected failures or unsafe behavior.
1899. **Property-based testing:** Checks whether general conditions remain satisfied across many generated inputs.
1900. **Mutation testing:** Introduces controlled code changes to determine whether existing tests detect altered behavior.
1901. **Regression suites:** Recheck established behavior after modifications to identify unintended changes.
1902. **Test-coverage interpretation:** Examines what testing measures actually demonstrate; high coverage does not guarantee meaningful verification.
1903. **Acceptance gates:** Require specified evidence or approvals before changes may advance to consequential stages.
1904. **Fault-tree analysis:** Works backward from undesirable outcomes to identify combinations of failures capable of producing them.
1905. **Failure mode and effects analysis:** Examines how components might fail, what consequences could follow, and which controls are appropriate.
1906. **Hazard analysis:** Identifies dangerous conditions and evaluates the pathways through which harm may arise.
1907. **Safety cases:** Organize claims, arguments, and evidence supporting confidence in a system's safety for a defined use.
1908. **Change-control procedures:** Establish how proposed modifications are assessed, authorized, implemented, and documented.
1909. **Release authorization:** Determines who can approve deployment and which preconditions must be satisfied.
1910. **Configuration drift:** Occurs when operating systems gradually diverge from approved configurations.
1911. **Configuration reconciliation:** Restores intended settings or records authorized changes, reducing hidden divergence.
1912. **Reproducible software builds:** Produce equivalent artifacts from equivalent inputs under specified conditions, improving verifiability.
1913. **Software bills of materials:** Record included components and dependencies, supporting vulnerability and licensing analysis.
1914. **Build provenance attestations:** Preserve evidence concerning the origins and construction of software artifacts.
1915. **Technical debt accounting:** Makes the future maintenance cost of expedient design decisions visible rather than treating short-term delivery as free.
1916. **Architectural erosion:** Occurs when accumulated changes undermine originally intended system boundaries and relationships.
1917. **Reliability error budgets:** Define how much measured service unreliability is tolerable before priorities must change.
1918. **Operational runbooks:** Provide tested procedures for responding to known incidents, failures, and maintenance tasks.
1919. **Blameless engineering postmortems:** Examine contributing technical and organizational conditions without substituting personal blame for causal analysis.
1920. **Maintenance backlog prioritization:** Determines which accumulated defects, upgrades, and risks receive limited engineering capacity first.
## 24. Emergent behavior, perverse incentives, and systemic paradoxes
1921. **Schelling points:** People coordinate around recognizable choices even without direct communication, allowing order to emerge without formal leadership.
1922. **Preference falsification:** Individuals publicly express views that differ from their private beliefs to avoid social or institutional consequences.
1923. **Spirals of silence:** Perceived minority status discourages people from expressing opinions, potentially making dominant views appear more universal than they are.
1924. **Participation thresholds:** Collective movements grow when enough individuals see that others have already joined or accepted the risks.
1925. **Bandwagon effects:** Increasing popularity attracts additional support independently of the underlying merits.
1926. **Informational cascades:** People imitate earlier choices rather than relying on their own evidence, potentially spreading mistaken judgments.
1927. **Self-fulfilling expectations:** Beliefs influence behavior in ways that cause anticipated outcomes to occur.
1928. **Coordination games:** Illustrate how individuals may achieve different collective outcomes depending on whether they successfully align their decisions.
1929. **Prisoner's-dilemma dynamics:** Show how individually advantageous choices can produce collectively worse outcomes when credible cooperation is unavailable.
1930. **Stag-hunt dynamics:** Demonstrate how valuable cooperative outcomes may be abandoned because participants doubt that others will cooperate.
1931. **Common-resource depletion dilemmas:** Arise when individually beneficial extraction imposes cumulative costs on a shared resource.
1932. **Anticommons problems:** Occur when too many independent permission holders prevent productive use of otherwise available resources.
1933. **Assurance failures:** Prevent people from contributing to a beneficial undertaking because they cannot establish that enough others will participate.
1934. **Goodhart's law:** When a measurement becomes a target, behavior may change until the measurement no longer represents the intended objective.
1935. **Campbell's law:** Heavy reliance on quantitative performance indicators can encourage corruption or distortion of the processes they measure.
1936. **Proxy optimization:** Improves a measurable substitute while allowing the actual desired outcome to stagnate or deteriorate.
1937. **Positional competition:** People pursue advantages whose value depends on outperforming others, potentially creating costly collective arms races.
1938. **Winner-take-most markets:** Allocate disproportionately large rewards to leading participants, sometimes reducing opportunities for nearly comparable competitors.
1939. **Cumulative advantage:** Small initial benefits compound through additional resources, recognition, access, and opportunity.
1940. **Rent-seeking behavior:** Attempts to obtain economic benefits through control of rules or privileges rather than corresponding productive contribution.
1941. **Regulatory arbitrage:** Exploits differences between applicable rule systems to obtain more favorable treatment.
1942. **Jurisdiction shopping:** Selects legal or administrative forums perceived to offer advantageous procedures or outcomes.
1943. **Policy diffusion:** Governments and institutions adopt approaches observed elsewhere, sometimes without accounting for different local conditions.
1944. **Hysteresis:** A system's present condition depends partly on its history, so reversing an intervention may not restore the original state.
1945. **Sensitivity to initial conditions:** Small starting differences can produce substantially different trajectories in some complex systems.
1946. **Model misspecification:** Analytical methods omit or incorrectly represent important relationships, producing misleading predictions.
1947. **Hidden feedback delays:** Prevent decision-makers from recognizing consequences until additional harmful actions have accumulated.
1948. **Second-order intervention costs:** Appear when solving one problem changes incentives, resources, or relationships elsewhere.
1949. **Correlated risks:** Multiple seemingly separate failures arise together because they share underlying exposures.
1950. **Common-mode failure:** A single weakness disables several supposedly independent protective systems.
1951. **Graceful degradation:** Allows a system to preserve limited useful functionality rather than failing completely under adverse conditions.
1952. **Latent errors:** Remain concealed inside processes until particular circumstances activate their consequences.
1953. **Normalization of deviance:** Repeated violations become accepted because previous violations did not produce immediate visible harm.
1954. **Risk compensation:** People sometimes adjust behavior after safety improvements, reducing part of the expected benefit.
1955. **Rebound effects:** Efficiency improvements lower the cost of an activity, encouraging additional consumption that offsets some savings.
1956. **Tightly coupled operations:** Leave little time or flexibility to contain disturbances before they reach dependent components.
1957. **Heavy-tailed outcome distributions:** Produce extreme results more frequently than simple normal-distribution assumptions would suggest.
1958. **Tail dependence:** Causes rare, severe losses in different systems to become especially connected during extreme conditions.
1959. **Rare-event blindness:** Leads organizations to underestimate hazards because limited historical observations contain few relevant examples.
1960. **Scale mismatch:** Occurs when the authority, funding, information, or boundaries of a decision-making institution do not match the problem being addressed.
## 25. Administrative existence, practical access, and the last mile of civilization
1961. **Birth-certificate issuance:** Creates documentary evidence of a person's birth and legally relevant details; missing records can obstruct participation throughout life.
1962. **Death registration:** Establishes authoritative records of death for legal, statistical, financial, and family purposes.
1963. **Legal name-change administration:** Connects an individual's recognized name with existing records, credentials, obligations, and legal identity.
1964. **Identity-marker correction:** Allows qualifying personal records to be updated under applicable procedures; inconsistencies can create exclusion and disclosure risks.
1965. **Government identification issuance:** Provides recognized identity credentials needed for many transactions and services; access barriers disproportionately affect vulnerable people.
1966. **Notarial authentication:** Provides defined verification of signatures, acknowledgments, or other formal acts; improper verification enables fraud.
1967. **International document authentication:** Establishes whether certain official documents may be recognized across jurisdictions.
1968. **Witness attestations:** Provide formal confirmation of specified acts or events when documentation requires independent observation.
1969. **Identity-proofing failures:** Mistakenly associate people with incorrect records or fail to recognize legitimate identities, potentially blocking essential services.
1970. **Replacement-document procedures:** Restore access when credentials are lost, stolen, damaged, or destroyed; fees and administrative requirements can prolong exclusion.
1971. **Eligibility verification:** Determines whether applicants satisfy defined requirements; inaccurate verification can deny legitimate benefits or authorizations.
1972. **Periodic benefit recertification:** Requires continued proof of qualifying circumstances; administrative complexity can interrupt essential assistance.
1973. **Benefit cliffs:** Occur when small increases in earnings cause disproportionately large losses of assistance, sometimes discouraging economic advancement.
1974. **Proof-of-address requirements:** Help verify residency while disadvantaging people without stable housing or conventional documentation.
1975. **Unbanked exclusion:** Arises when institutions require bank accounts for participation, restricting access for people unable to obtain or maintain them.
1976. **Administrative literacy:** Determines whether individuals understand forms, deadlines, evidentiary requirements, and available remedies.
1977. **Service navigation assistance:** Helps people move among institutions whose requirements, terminology, or eligibility rules are difficult to understand.
1978. **Multilingual intake procedures:** Allow services to receive accurate information from people who do not use an institution's dominant language.
1979. **Interagency case transfer:** Moves responsibility and records between institutions; failed transfers can interrupt care, assistance, or legal processing.
1980. **Waiting-list transparency:** Allows applicants to understand their status and relevant allocation procedures, reducing uncertainty and opportunities for favoritism.
1981. **Street-level bureaucratic discretion:** Gives frontline workers practical influence over how broad institutional rules affect individual people.
1982. **Documentation burdens:** Require applicants to collect, reproduce, and submit evidence, often imposing hidden costs in time, travel, and money.
1983. **Record-access fees:** Charge individuals for documents needed to establish their own identity, rights, or history; high costs can obstruct participation.
1984. **Automatic disqualification rules:** Reject applications based on predefined criteria, potentially ignoring relevant circumstances that require individual evaluation.
1985. **Wrongful benefit termination:** Removes support from eligible people because of mistakes, faulty procedures, or inaccurate information.
1986. **Automated administrative decision errors:** Scale mistaken classifications or calculations across large populations when systems lack effective safeguards.
1987. **Human reconsideration mechanisms:** Allow consequential automated or administrative decisions to receive meaningful individual examination.
1988. **Adverse-action notices:** Inform people that a benefit, service, permission, or legal position has been denied or changed and explain applicable grounds.
1989. **Administrative appeal deadlines:** Determine when decisions may be contested; missed deadlines can turn correctable errors into lasting consequences.
1990. **Administrative grace periods:** Provide additional time to satisfy requirements before specified penalties or losses take effect.
1991. **Temporary presumptive eligibility:** Allows certain services to begin before full verification when delay would create serious hardship.
1992. **Public ombuds services:** Provide an independent or specially designated channel for examining administrative complaints and institutional unfairness.
1993. **Official record correction:** Allows documented mistakes to be amended, preventing inaccurate information from repeatedly influencing future decisions.
1994. **Unclaimed-property custody:** Preserves certain financial assets when owners cannot be located, requiring procedures for eventual rightful recovery.
1995. **Continuity of guardianship records:** Preserves legally relevant authority and responsibilities when dependent individuals move between institutions or jurisdictions.
1996. **Emergency identity restoration:** Helps people recover critical documents and access after displacement, disaster, theft, or institutional disruption.
1997. **Cross-jurisdiction missing-person coordination:** Connects separate reporting and investigative systems when a person's location or identity cannot be established locally.
1998. **Public compensation claims:** Provide procedures through which people seek payment for qualifying injury, loss, or improper institutional conduct.
1999. **Last-mile service failure:** Occurs when a functioning system cannot deliver its intended benefit to the particular individual who needs it.
2000. **The implementation–experience gap:** Describes the difference between what an institution officially promises, what its procedures actually produce, and what the affected human being ultimately experiences.
