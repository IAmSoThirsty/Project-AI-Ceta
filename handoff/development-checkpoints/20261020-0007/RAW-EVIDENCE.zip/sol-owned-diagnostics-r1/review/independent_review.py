from pathlib import Path
import ast, ctypes, difflib, hashlib, json, os, subprocess, sys, threading, unittest
from unittest.mock import patch
from dataclasses import replace
R=Path(__file__).resolve().parent; W=R.parent/'work'; C=W/'candidate'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(W/'MANIFEST.json')=='637cc58a8972a3570e7acf962df8f8fd822208886b2d5271a9145c23fa09dd20'
BEFORE={p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file()}
base=json.loads((W/'BASELINE.json').read_bytes())['baseline']
old=Path(base['baseline_candidate'])/'src/ceta/composition/owned_service.py'; new=C/'src/ceta/composition/owned_service.py'
def methods(p):
 t=ast.parse(p.read_bytes()); cls=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='OwnedService')
 return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=methods(old),methods(new)
assert all(b[k]==v for k,v in a.items()),'existing method changed'
assert set(b)-set(a)=={'_diagnostics_binding_available','_diagnostics_owner_snapshot','_diagnostics_owner_current','resource_diagnostics'}
(R/'source.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new))),encoding='utf8')
sys.path[:0]=[str(C/'src'),str(C/'tests/contract')]
from test_owned_diagnostics_binding import OwnedDiagnosticsBindingTests, GENERATION, RetainedProcess
from ceta.contracts.wire import ContractError
from ceta.composition.owned_service import OwnedDiagnosticsSnapshot
class Independent(unittest.TestCase):
 def owner(self): return OwnedDiagnosticsBindingTests().service()
 def test_real_stop_path_marks_invalid_before_termination_outside_lock(self):
  s=self.owner(); snap=s._diagnostics_owner_snapshot(GENERATION)
  s._last=None; s._detail=''; entered=threading.Event(); release=threading.Event(); errors=[]; observed=[]
  def termination(owner,kind):
   observed.append((s._state,s._diagnostics_owner_current(snap))); entered.set()
   if not release.wait(3): raise AssertionError('barrier timeout')
  def stop():
   try:s.request_stop()
   except BaseException as e:errors.append(repr(e))
  with patch.object(s,'_request_termination',side_effect=termination):
   t=threading.Thread(target=stop); t.start()
   try:
    self.assertTrue(entered.wait(3)); self.assertFalse(s._diagnostics_owner_current(snap))
    with self.assertRaises(ContractError):s._diagnostics_owner_snapshot(GENERATION)
   finally:release.set(); t.join(3)
  self.assertFalse(t.is_alive()); self.assertEqual(errors,[]); self.assertEqual(observed,[('STOPPING',False)]*2)
 def test_uncertainty_clear_alone_cannot_restore_old_generation(self):
  s=self.owner(); snap=s._diagnostics_owner_snapshot(GENERATION)
  s._state='RECOVERING'; s._uncertain_task_request=object(); self.assertFalse(s._diagnostics_owner_current(snap))
  s._state='READY'; self.assertFalse(s._diagnostics_owner_current(snap))
  s._uncertain_task_request=None; s._generation='b'*64; self.assertFalse(s._diagnostics_owner_current(snap))
  with self.assertRaises(ContractError):s._diagnostics_owner_snapshot(GENERATION)
  self.assertTrue(s._diagnostics_owner_current(s._diagnostics_owner_snapshot('b'*64)))
 def test_exact_type_and_role_scope_boundaries(self):
  s=self.owner(); snap=s._diagnostics_owner_snapshot(GENERATION)
  class Derived(OwnedDiagnosticsSnapshot):pass
  self.assertFalse(s._diagnostics_owner_current(Derived(**vars(snap))))
  self.assertFalse(s._diagnostics_owner_current(replace(snap,service_process=snap.client_process,client_process=snap.service_process)))
  for scopes in ((), ('installation:controlled',)*9,('installation:controlled','bad scope'),['installation:controlled']):
   s._scopes=scopes
   self.assertFalse(s._diagnostics_owner_current(snap))
   with self.assertRaises(ContractError):s._diagnostics_owner_snapshot(GENERATION)
 def test_atomic_stop_metadata_read(self):
  s=self.owner(); snap=s._diagnostics_owner_snapshot(GENERATION); entered=threading.Event(); done=threading.Event(); values=[]
  def reader():entered.set(); values.append(s._diagnostics_owner_current(snap)); done.set()
  with s._lock:
   t=threading.Thread(target=reader);t.start();self.assertTrue(entered.wait(3));self.assertFalse(done.is_set());s._state='STOPPING'
  t.join(3);self.assertFalse(t.is_alive());self.assertEqual(values,[False])
 def test_snapshot_does_not_assert_physical_lifetime(self):
  s=self.owner(); snap=s._diagnostics_owner_snapshot(GENERATION)
  s._service.process.physically_exited=True
  self.assertTrue(s._diagnostics_owner_current(snap)) # documented metadata-only boundary
  s._service._process_closed=True;self.assertFalse(s._diagnostics_owner_current(snap))
 def test_delegate_preserves_exact_failure_and_controller_state(self):
  import types
  s=self.owner(); snap=s._diagnostics_owner_snapshot(GENERATION); error=RuntimeError('sentinel'); mod=types.ModuleType('ceta.composition.resource_diagnostics')
  def fail(*args,**kw):raise error
  mod.collect_owned_diagnostics=fail
  with patch.dict(sys.modules,{'ceta.composition.resource_diagnostics':mod}):
   try:s.resource_diagnostics(expected_generation=GENERATION,envelope=object())
   except RuntimeError as caught:self.assertIs(caught,error)
   else:self.fail('failure swallowed')
  self.assertTrue(s._diagnostics_owner_current(snap))
with patch.object(ctypes,'WinDLL',side_effect=AssertionError('native DLL forbidden during binding review')):
 with (R/'independent-tests.txt').open('w',encoding='utf8') as f:
  result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Independent))
assert result.wasSuccessful()
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
argv=[sys.executable,'-B','-X','utf8',str(W/'verify_frozen.py')]
p=subprocess.run(argv,env=env,capture_output=True)
(R/'frozen-gate.stdout').write_bytes(p.stdout);(R/'frozen-gate.stderr').write_bytes(p.stderr)
assert p.returncode==0
AFTER={p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file()}
assert BEFORE==AFTER,'frozen work mutation'
report=dict(status='PASS',scope='binding-only; controlled borrowed ports; no native qualification',independent_tests=result.testsRun,author_binding_tests=10,old_methods_unchanged=len(a),frozen_work_files=len(BEFORE),frozen_work_unchanged=True,manifest_sha256=sha(W/'MANIFEST.json'),source_sha256=sha(new),command=argv,exit_status=p.returncode)
(R/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report))
