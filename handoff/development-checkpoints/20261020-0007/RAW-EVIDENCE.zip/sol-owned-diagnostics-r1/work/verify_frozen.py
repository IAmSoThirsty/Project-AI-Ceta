"""Pinned H2+D conservation and finite controlled owner-binding gate."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    work = Path(__file__).resolve().parent
    manifest = json.loads((work / 'MANIFEST.json').read_bytes())
    provenance = json.loads((work / 'BASELINE.json').read_bytes())
    assert sha(Path(provenance['packet'])) == provenance['packet_sha256']
    assert sha(Path(provenance['interface'])) == provenance['interface_sha256']
    packet = provenance['baseline']
    assert len(packet['baseline_payloads']) == 554
    for predecessor in packet['predecessors']:
        path = Path(predecessor['path'])
        assert sha(path) == predecessor['sha256']
        assert sha(path.parent.parent / 'delivery/SOURCE-HANDOFF.json') == predecessor['handoff_sha256']
    candidate = work / 'candidate'
    changed = []
    for item in packet['baseline_payloads']:
        rel = item['path']
        original = Path(packet['diagnostics_overlay'] if rel in packet['overlay_paths']
                        else packet['baseline_candidate']) / rel
        assert sha(original) == item['sha256'], ('baseline changed', rel)
        if sha(candidate / rel) != item['sha256']:
            changed.append(rel)
    assert changed == ['src/ceta/composition/owned_service.py'], changed
    product = {p.relative_to(candidate).as_posix(): sha(p) for p in candidate.rglob('*')
               if p.is_file() and not p.relative_to(candidate).as_posix().startswith('.agents/fixtures/')}
    assert product == manifest['candidate_hashes'] and len(product) == 555
    for rel, digest in manifest['fixture_hashes'].items():
        assert sha(candidate / rel) == digest, ('author fixture changed', rel)
    for rel, digest in manifest['support_hashes'].items():
        assert sha(work / rel) == digest, ('support changed', rel)
    for rel in manifest['changed_product_paths']:
        compile((candidate / rel).read_bytes(), str(candidate / rel), 'exec')
    env = os.environ.copy()
    env['PYTHONPATH'] = str(candidate / 'src') + os.pathsep + str(candidate / 'tests/contract')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    argv = [sys.executable, '-B', '-X', 'utf8', '-m', 'unittest', 'discover', '-s',
            str(candidate / 'tests/contract'), '-p', 'test_owned_diagnostics_binding.py', '-v']
    result = subprocess.run(argv, cwd=candidate, env=env, capture_output=True)
    sys.stdout.buffer.write(result.stdout)
    sys.stderr.buffer.write(result.stderr)
    assert result.returncode == 0
    print(json.dumps(dict(baseline_conserved=554, product_payloads=555,
                         changed_source=changed, controlled_binding_gate_exit=0)))


if __name__ == '__main__':
    main()
