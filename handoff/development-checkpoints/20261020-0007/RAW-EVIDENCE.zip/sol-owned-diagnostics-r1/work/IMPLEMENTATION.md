# Retained owned-service diagnostics binding

EXTEND the existing canonical OwnedService composition; no parallel process,
state, authority, telemetry store or scheduler is introduced. The exact H2 plus
accepted D overlay baseline contains 554 pinned payloads. Only owned_service.py
and its new targeted test module are changed. Root inspected the new binding
and directed this finite unit to freeze separately from the collector author's
work. The collector, OperatorSession and CLI remain the other author's scope.

Root clarified the immutable packet's mistaken 'integer generation' phrase:
the actual canonical OwnedService generation remains an exact 64-character
lowercase hex string. It is never converted to the sampler's internal integer
generation. Tests reject bool, int, uppercase, wrong length and malformed strings.
The original packet/interface remain byte-preserved; this clarification records
the actual parent instruction and existing public generation semantics.

OwnedDiagnosticsSnapshot is a frozen, non-wire composition value holding borrowed
service/client process ports plus fixed installation, registered scopes, root,
codec and generation. The snapshot operation rejects non-READY, active pending
requests, send workers, uncertain task requests, any retained worker, unresolved
launch, launch slots/pending/in-progress, missing or closed channels, missing
processes, or a shared process serving both roles. The installation must occupy
the installation: namespace and remain in bounded valid registered scopes.
No PID, role, task or project selector is exposed.

Currentness checks the exact value type, valid generation, controller availability,
unchanged installation and exact retained root/scopes/codec/process identities.
Copied stale snapshots and altered role bindings fail those checks. The controller
lock spans metadata checks only. No process poll, native counter query, termination,
close or collector callback occurs under it. Physical process currentness remains
the collector's responsibility; this binding alone is not a lifetime proof.
Public resource_diagnostics lazily imports and forwards all agreed keyword inputs.
It does not create a polling hook, background sampler or durable observation.

Ten controlled binding tests cover valid borrowed fields, frozen snapshots,
generation validation before binding work, busy/stopping/recovering/uncertain
guards, fixed installation, owner replacement/recovery, copied/malformed snapshots,
forbidden caller selectors, exact public forwarding, and concurrent stop during a
blocked collector callback. Fifteen existing ControlledOwnedServiceTests exercise
unchanged launch/send/shutdown/cleanup behavior without native process creation.
Those tests create only disposable fixture records inside this candidate;
retained fixture database files are separately hashed as test evidence, not
product payload or a live profile. Their paths are never used by the new binding.

The initial author test run failed because assertions compared formatted
ContractError text rather than its canonical code. Tests now assert .code;
the original failure receipt remains unchanged. No validation was weakened.
Final commands and raw outputs are separate from that historical failure.
Compileall runs on byte-identical short-path copies to avoid the previously
observed Windows relocated-cache path limit.

Author self-review inspected retained owner publication, generation, begin_call,
worker retirement, stop/poll, shutdown witness and OperatorSession/launcher callers.
The change preserves their public APIs and cleanup semantics. It adds no native
method invocation or lifetime mutation. The accepted H2/D predecessor handoffs,
all 554 original selected bytes and all unmodified local payloads are verified by
verify_frozen.py. This is source-bound deterministic evidence for requirement
groups CETA-20.05.01/.02 and REQ35-01/-03, not complete original acceptance,
fresh native/installed qualification or full product completion. The real collector
and its current Journal/physical-lifetime fencing require separate review and
integration. Canonical source, Git and host settings remain unchanged.
