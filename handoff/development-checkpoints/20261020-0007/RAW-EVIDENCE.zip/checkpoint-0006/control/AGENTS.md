# Exact sixth CETA development checkpoint

Existing 20-minute authority. Isolated preparation; distinct reviewer and actual gate before one hook-enabled descendant push. Preserve active HEAD/index/canonical files and all old exports, PDF parts and five immutable fixtures. Root alone claims exact .git scope. No source cutover, no native/host action, no force or replay.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/development-checkpoint-20261020/checkpoint-0006/work/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.git",
          "00-Active/Project-AI-CETA/.git/objects/**",
          "00-Active/Project-AI-CETA/.git/refs/heads/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/refs/heads/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/logs/refs/heads/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/logs/refs/heads/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/refs/remotes/origin/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/refs/remotes/origin/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/logs/refs/remotes/origin/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/logs/refs/remotes/origin/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/lfs/cache/locks/refs/heads/development/checkpoints/verifiable",
          "00-Active/Project-AI-CETA/.git/lfs/cache/locks/refs/heads/development/checkpoints/verifiable.lock"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:\\00-Active\\Project-AI-CETA\\.agents\\source-assembly-20261014T021300Z\\.agents\\e3\\Scripts\\python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\development-checkpoint-20261020\\checkpoint-0006\\work\\verify_prepared.py\""
        ]
      },
      "review": {
        "kind": "agent",
        "role": "reviewer",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/development-checkpoint-20261020/checkpoint-0006/review/**"
        ]
      }
    }
  }
}
```
