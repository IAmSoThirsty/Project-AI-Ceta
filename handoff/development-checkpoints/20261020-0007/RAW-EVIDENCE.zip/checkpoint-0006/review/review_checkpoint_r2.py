from pathlib import Path
import difflib,hashlib,json,re,subprocess,sys,zipfile
F=Path('T:/00-Active/Project-AI-CETA');P=Path(__file__).resolve().parent.parent;W=P/'work';R=P/'review/attempt2'
sys.path.insert(0,str(W));import prepare_checkpoint as e
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
expected={'WORK-FREEZE.json':'20d85a57ba9c57c13a61696551d9de2ebf6e16f1644211d4f4c7f02544c2d1f2','AUTHOR-RESULT.json':'db1bfccfb6084916c72a041e3ae6d428da4f82e0d430b8c271cc4da6dc91e843','prepared-0001/PREPARED.json':'df7a818b6d897fb5269fec2ff067f1032981b2716544028c20f5ac5f85802886'}
assert all(sha(W/n)==h for n,h in expected.items())
freeze=json.loads((W/'WORK-FREEZE.json').read_bytes())
def frozen():
 actual={p.relative_to(W).as_posix():sha(p) for p in W.rglob('*') if p.is_file() and p!=W/'WORK-FREEZE.json'}
 assert actual==freeze['hashes']
frozen()
prepared=json.loads((W/'prepared-0001/PREPARED.json').read_bytes());env=prepared['git_environment']
assert (prepared['commit'],prepared['tree'],prepared['parent'])==('3ab94d8c11e3169eee85c9fbb3f53fd7c234871a','a5ea29bea99daffacb02f01be82197754833929a','6f100604acb0dd3f4f8cc189feb64cfa7e357e0b')
commands=[]
for name in ('verify_prepared.py','audit_checkpoint.py'):
 argv=[sys.executable,'-B','-X','utf8',str(W/name)];p=subprocess.run(argv,cwd=F,capture_output=True,timeout=120)
 (R/(name+'.stdout')).write_bytes(p.stdout);(R/(name+'.stderr')).write_bytes(p.stderr)
 commands.append(dict(command=subprocess.list2cmdline(argv),exit_status=p.returncode));save('COMMANDS.json',commands)
 assert p.returncode==0,p.stderr.decode(errors='replace')
# Independently assess raw archive semantics and repeat both configured byte scans.
transport=json.loads((W/'public/EVIDENCE-TRANSPORT.json').read_bytes());members=transport['members'];assert len(members)==509
raw_inputs={};history={}
with zipfile.ZipFile(W/'public/RAW-EVIDENCE.zip') as z:
 names=z.namelist();assert len(set(n.casefold() for n in names))==len(names)
 assert names==[x['member'] for x in members] and z.comment==b''
 for item,info in zip(members,z.infolist(),strict=True):
  assert info.compress_type==zipfile.ZIP_STORED and info.date_time==(1980,1,1,0,0,0) and info.external_attr>>16==0o100644
  e.relative_path(info.filename);raw,pin=e.stable_read(item['source'])
  assert z.read(info)==raw and e.digest(raw)==item['sha256'] and len(raw)==item['bytes']
  raw_inputs[item['member']]=dict(input_path=item['source'],input_pin=pin)
 for lane,run in [('sol-discovery-r2','ceta-sol-discovery-r2-20261020'),('sol-diagnostics-r1','ceta-sol-diagnostics-r1-20261020'),('checkpoint-0005','ceta-development-checkpoint-0005-20261020')]:
  state=json.loads(z.read(f'{lane}/control/{run}/state.json'));assert len(state['nodes'])==6 and all(v['state']=='SUCCEEDED' for v in state['nodes'].values())
  verdict=json.loads(z.read(f'{lane}/control/final-run-verify.json'))['response'];assert verdict['receipts_valid'] is True and verdict['terminal_success'] is True
  history[lane]={'states':{k:v['state'] for k,v in state['nodes'].items()},'receipts_valid':True,'terminal_success':True}
 initial=json.loads(z.read('history/checkpoint-0001-r2/ceta-development-checkpoint-r2-20261020/state.json'));assert initial['nodes']['integrate']['state']=='FAILED'
 failed=json.loads(z.read('history/failed-discovery-r1/implement-complete.json'));assert failed['exit_status']!=0 and failed['response']['code']=='EXECUTION_FAILED'
 h1=F/'.agents/runtime/operational-resume-20261020/sol-discovery-r1/control/ceta-sol-discovery-r1-20261020/state.json';assert json.loads(h1.read_bytes())['nodes']['implement']['state']=='FAILED'
 retry=json.loads(z.read('history/failed-discovery-r1/implement-complete-final.json'));assert retry['exit_status']!=0 and retry['response']['allowed'] is False and retry['response']['code']=='ILLEGAL_TRANSITION'
 pub=json.loads(z.read('checkpoint-0005/control/INTEGRATION-RESULT.json'));assert pub['push_succeeded'] is True and pub['anonymous_readback'] is True and pub['checkpoint_commit']==prepared['parent']
for label,inputs in [('RAW',raw_inputs),('EXPORT',prepared['exports'])]:
 scan=e.scan_exports(inputs);save('INDEPENDENT-'+label+'-SCAN.json',scan);assert not scan['findings'] and scan['result']=='PASS'
url=re.compile(rb'(?i)[?&](?:sig|signature|x-amz-signature|x-goog-signature)=');hits=[]
for name,item in {**raw_inputs,**prepared['exports']}.items():
 raw=Path(item['input_path']).read_bytes()
 if url.search(raw) or url.search(raw.replace(b'\0',b'')):hits.append(name)
save('URL-MARKERS.json',dict(findings=hits,limit='configured URL markers only'));assert not hits
# Recompute exact tree delta and LOC from blobs, not author totals.
def tree(commit):
 out={}
 for entry in e.git(F,['ls-tree','-r','-z',commit],env=env).split(b'\0'):
  if entry:
   h,n=entry.split(b'\t',1);out[n.decode()]=h.decode().split()
 return out
old,new=tree(prepared['parent']),tree(prepared['commit']);assert len(old)==34569 and len(new)==34581
assert set(old)<=set(new);changes={p for p in old if old[p]!=new[p]};assert changes=={'DEVELOPMENT-CHECKPOINT.json','DEVELOPMENT-CHECKPOINT.md','src/ceta/resource/hardware.py','src/ceta/resource/diagnostics.py'}
assert all(old[p][0]==new[p][0] for p in old)
counts={'source_added':0,'source_removed':0,'tests_added':0,'tests_removed':0};diffs=[]
for path in ['src/ceta/resource/hardware.py','src/ceta/resource/diagnostics.py','tests/contract/test_hardware_discovery_continuation.py','tests/contract/test_resource_diagnostics_continuation.py']:
 before=e.batch_blobs(F,[old[path][2]],env)[0] if path in old else b'';after=e.batch_blobs(F,[new[path][2]],env)[0]
 diff=list(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='parent/'+path,tofile='candidate/'+path));diffs.extend(diff)
 kind='source' if path.startswith('src/') else 'tests'
 counts[kind+'_added']+=sum(x.startswith('+') and not x.startswith('+++') for x in diff);counts[kind+'_removed']+=sum(x.startswith('-') and not x.startswith('---') for x in diff)
assert counts==dict(source_added=53,source_removed=3,tests_added=373,tests_removed=0);(R/'PRODUCT.diff').write_text(''.join(diffs),encoding='utf8')
remote=e.git(F,['ls-remote','--refs','origin','refs/heads/development/checkpoints']).decode().strip();assert remote==prepared['parent']+'\trefs/heads/development/checkpoints'
locks=[str(p.relative_to(F/'.git')) for p in (F/'.git').rglob('*.lock') if p.is_file()];assert not locks,locks
status=json.loads((W/'public/STATUS.json').read_bytes())
for k in ('native_worker_qualification','full_joined_suite_acceptance','destination_acceptance','installed_product_acceptance','governed_authorization_to_effect_acceptance','endurance_acceptance','human_acceptance','full_product_operational'):assert status[k] is False
assert status['checkpoint_publication']=='NOT_RUN_PREPARED_FOR_DISTINCT_REVIEW'
frozen()
save('INDEPENDENT-RESULT.json',dict(status='PASS',commit=prepared['commit'],tree=prepared['tree'],parent=prepared['parent'],freeze_sha256=sha(W/'WORK-FREEZE.json'),frozen_payloads=len(freeze['hashes']),exports=len(prepared['exports']),raw_members=509,parent_paths=34569,child_paths=34581,exact_existing_changes=sorted(changes),counts=counts,history=history,H1='FAILED',C1r2='FAILED',locks=locks,public_parent=remote,scope='Exact publication evidence; configured scans only; no product/native approval'))
print(json.dumps(json.loads((R/'INDEPENDENT-RESULT.json').read_bytes()),indent=2))
