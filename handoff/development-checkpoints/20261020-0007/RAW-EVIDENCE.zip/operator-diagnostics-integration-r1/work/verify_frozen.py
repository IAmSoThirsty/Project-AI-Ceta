"""Exact joined source/evidence gate; performs no new native/test effects."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;C=W/'candidate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((W/'MANIFEST.json').read_bytes());actual={p.relative_to(C).as_posix():sha(p) for p in C.rglob('*') if p.is_file() and not p.is_relative_to(C/'.agents/fixtures')}
assert actual==m['payload_hashes'] and len(actual)==559
for p,h in m['predecessor_hashes'].items():assert sha(Path(p))==h,p
for n,h in m['support_hashes'].items():assert sha(W/n)==h,n
run=json.loads((W/'joined-tests-r2/RESULT.json').read_bytes());assert run['tests']==137 and run['successful'] and not any(run[k] for k in ('failures','errors','skips'))
assert run['ordinary_imports'] and not run['module_overlay'] and not run['root_override']
live=json.loads((W/'live-cli-01/RESULT.json').read_bytes());assert live['source_unchanged'] and live['custody']['child_exit']==0 and all(live['custody']['native_owner_after'].values())
assert live['source_pins_sha256']==sha(W/'live-cli-01/SOURCE-PINS.json')
assert json.loads((W/'live-cli-01/SOURCE-PINS.json').read_bytes())==actual
result=live['custody']['child_result'];assert result['payload']['startup']=='READY' and result['payload']['operation']=='COMPLETE_PROCESS_USAGE' and result['payload']['cleanup']=='STOPPED'
for n,log in result['logs'].items():assert sha(Path(log['path']))==log['sha256'] and Path(log['path']).stat().st_size==log['bytes']
for n in m['changed_python_paths']:compile((C/n).read_bytes(),str(C/n),'exec')
print(json.dumps(dict(status='PASS',exact_payloads=559,joined_tests=137,module_overlay=False,root_override=False,actual_ordinary_windows_cli_exit=0,exact_native_retirement=True,canonical_application=False,consequential_governed_effect=False,full_product_acceptance=False)))
