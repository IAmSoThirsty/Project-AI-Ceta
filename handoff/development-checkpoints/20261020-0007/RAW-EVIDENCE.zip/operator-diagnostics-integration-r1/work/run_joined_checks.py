"""Run the exact joined application with ordinary imports and own fixtures."""
from pathlib import Path
import argparse, hashlib, json, os, sys, unittest

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,default=Path(__file__).resolve().parent/'candidate');p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'joined-tests');a=p.parse_args()
    candidate=a.candidate.resolve(strict=True);a.output.mkdir(exist_ok=False)
    sys.path[:0]=[str(candidate/'src'),str(candidate/'tests/contract')]
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    from ceta.composition import owned_service, resource_diagnostics
    assert Path(owned_service.__file__).resolve()==candidate/'src/ceta/composition/owned_service.py'
    assert Path(resource_diagnostics.__file__).resolve()==candidate/'src/ceta/composition/resource_diagnostics.py'
    assert owned_service.ROOT==candidate
    names=['test_owned_diagnostics_binding','test_operator_resource_diagnostics','test_operator_diagnostics_launcher','test_resource_diagnostics_continuation','test_process_diagnostics.ProcessDiagnosticsTests','test_owned_service.ControlledOwnedServiceTests','test_shutdown_lifecycle.ShutdownContractTests','test_shutdown_lifecycle.ContextShutdownTests','test_shutdown_interruptions.InterruptionContractTests','test_shutdown_interruptions.LauncherInterruptionTests','test_shutdown_session_failures.LauncherDiagnosticMutationTests','test_outer_process_shutdown_handoff.LauncherRecordTests']
    before={p.relative_to(candidate).as_posix():sha(p) for p in candidate.rglob('*') if p.is_file() and not p.is_relative_to(candidate/'.agents/fixtures')}
    with (a.output/'TESTS.log').open('x',encoding='utf8') as log:
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names))
    after={p.relative_to(candidate).as_posix():sha(p) for p in candidate.rglob('*') if p.is_file() and not p.is_relative_to(candidate/'.agents/fixtures')}
    assert before==after
    report=dict(command=sys.argv,python=sys.executable,version=sys.version,tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),successful=result.wasSuccessful(),ordinary_imports=True,module_overlay=False,root_override=False,owned_service_source=str(owned_service.__file__),collector_source=str(resource_diagnostics.__file__),product_hashes_unchanged=True,payload_count=len(before),test_names=names,native_process_launch=False,installed_product_acceptance=False)
    (a.output/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report));return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
