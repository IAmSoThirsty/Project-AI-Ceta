"""One ordinary own-job CLI observation; no AppContainer or debug operation."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, msvcrt, os, sys, time
W=Path(__file__).resolve().parent;C=W/'candidate'
sys.path.insert(0,str(C/'src'))
from ceta.supervisor.windows_jobs import WindowsOwnedProcess
from ceta.supervisor.service import controlled_environment
F=Path('T:/00-Active/Project-AI-CETA')
P=F/'.agents/runtime/operational-resume-20261020/runner-repair-r1/work/tools/bounded_custody.py'
assert hashlib.sha256(P.read_bytes()).hexdigest()=='715b88ab286a524f5815ec3c47b987ba82cc50709272fdc467b7ddc76eeba1b4'
s=importlib.util.spec_from_file_location('verified_ordinary_custody',P);custody=importlib.util.module_from_spec(s);s.loader.exec_module(custody)

def save(path,value):
    with path.open('x',encoding='utf8') as out:json.dump(value,out,indent=2,allow_nan=False)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    out=W/'live-cli-01';out.mkdir(exist_ok=False);(out/'temporary').mkdir()
    source_pins={p.relative_to(C).as_posix():sha(p) for p in C.rglob('*') if p.is_file() and not p.is_relative_to(C/'.agents/fixtures')}
    assert len(source_pins)==559
    save(out/'SOURCE-PINS.json',source_pins)
    python=Path(sys._base_executable).resolve(strict=True)
    argv=(str(python),'-I','-B','-X','utf8',str(C/'tools/ceta_operator.py'),'--diagnostics','--diagnostics-envelope','1000','16000','4294967296')
    save(out/'START.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=list(argv),python_sha256=sha(python),candidate=str(C),source_join_sha256=sha(W/'JOIN.json'),script_sha256=sha(Path(__file__)),qualification='ordinary own-job read-only diagnostics; no consequential effect; no profile/debug/host configuration'))
    (out/'stdin.bin').write_bytes(b'')
    streams=[(out/'stdin.bin').open('rb'),(out/'stdout.bin').open('xb'),(out/'stderr.bin').open('xb')]
    handles=tuple(msvcrt.get_osfhandle(st.fileno()) for st in streams)
    owner_state={};stdio_errors=[]
    def launch():
        for h in handles:os.set_handle_inheritable(h,True)
        return WindowsOwnedProcess.launch(str(python),argv[1:],cwd=str(C),environment=controlled_environment(out/'temporary'),standard_handles=handles,expected_image_sha256=sha(python))
    def emit(identity):save(out/'OWNED-LAUNCH.json',identity)
    def read_child():
        for st in streams:
            try:st.close()
            except BaseException as error:stdio_errors.append(error)
        if stdio_errors:raise RuntimeError('OWNED_STDIO_CLOSE_UNCERTAIN')
        raws={}
        for name in ('stdout','stderr'):
            p=out/(name+'.bin');size=p.stat().st_size
            if size>1048576:raise RuntimeError('OWNED_CLI_LOG_BOUND')
            raws[name]=p.read_bytes()
        payload=None
        if raws['stdout']:
            payload=json.loads(raws['stdout'].decode('utf8'))
            if type(payload) is not dict:raise RuntimeError('OWNED_CLI_RESULT_OBJECT_REQUIRED')
        return dict(payload=payload,logs={name:dict(path=str(out/(name+'.bin')),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in raws.items()})
    try:
        result=custody.run_owned(launch,emit,read_child,timeout=40)
    except BaseException as error:
        data=BaseException.__dict__['__dict__'].__get__(error)
        report=data.get('full_runner_report',{})
        save(out/'FAILURE.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),error=custody.failure(error),custody=report,stdio_close_uncertain=bool(stdio_errors)))
        # Retain the exact returned ownership on uncertain retirement. No PID
        # search, cleanup replay or wider termination may substitute for it.
        after=report.get('native_owner_after');constructed=report.get('construction_custody') or {}
        if stdio_errors or constructed.get('retained_exact_owner') or data.get('_cleanup_handles') or (report.get('native_owner') is not None and (type(after) is not dict or not all(after.values()))):
            global retained_uncertain_cli_owner
            retained_uncertain_cli_owner=error
            print(json.dumps(dict(state='OWNED_CUSTODY_UNCERTAIN_RETAINED',evidence=str(out/'FAILURE.json'))),flush=True)
            while True:
                try:time.sleep(.25)
                except BaseException:pass
        raise
    current_pins={p.relative_to(C).as_posix():sha(p) for p in C.rglob('*') if p.is_file() and not p.is_relative_to(C/'.agents/fixtures')}
    assert current_pins==source_pins, 'live source drift'
    save(out/'RESULT.json',dict(source_pins_sha256=sha(out/'SOURCE-PINS.json'),source_unchanged=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=list(argv),custody=result,ordinary_process_launch=True,protected_native_profile_or_debug=False,governed_authorization_to_effect='NOT_EXERCISED_READ_ONLY_DIAGNOSTICS',canonical_application=False,full_product_acceptance=False))
    payload=result['child_result']['payload']
    print(json.dumps(dict(exit_status=result['child_exit'],observed=payload,custody=result['native_owner_after'],evidence=str(out/'RESULT.json'))),flush=True)
    return 0 if result['child_exit']==0 and payload and payload.get('startup')=='READY' and payload.get('operation')=='COMPLETE_PROCESS_USAGE' and payload.get('cleanup')=='STOPPED' else 2
if __name__=='__main__':raise SystemExit(main())
