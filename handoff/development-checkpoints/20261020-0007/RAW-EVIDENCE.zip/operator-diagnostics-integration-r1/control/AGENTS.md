# Exact joined operational diagnostics implementation

Inspect both exact author manifests before copy. Preserve all554 baseline payloads except declared source delta; no external project, pinned source or Git mutation. Existing user code/test authority includes bounded ordinary own disposable job/service/client and SQLite fixtures; no protected profile/debug or machine configuration. Distinct review before source-only handoff.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/operator-diagnostics-integration-r1/work/**"
        ]
      },
      "review": {
        "kind": "agent",
        "role": "reviewer",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/operator-diagnostics-integration-r1/review/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/operator-diagnostics-integration-r1/delivery/**"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:/00-Active/Project-AI-CETA/.agents/source-assembly-20261014T021300Z/.agents/e3/Scripts/python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\operational-resume-20261020\\operator-diagnostics-integration-r1\\work\\verify_frozen.py\""
        ]
      }
    }
  }
}
```
