from pathlib import Path
import json,sys,unittest
from unittest.mock import patch
R=Path(__file__).resolve().parent;C=R/'c';sys.path[:0]=[str(C/'src'),str(C/'tests/contract')]
from test_operator_resource_diagnostics import OperatorResourceDiagnosticsTests as Base,collector,SqliteJournal,SCOPES,STORE_PROFILE,GENERATION
from ceta.contracts.wire import ContractError
class Adverse(unittest.TestCase):
 setUp=Base.setUp;tearDown=Base.tearDown;wait=Base.wait;collect=Base.collect;reject=Base.reject;commit=Base.commit
 def test_cancellation_mutating_owner_is_rejected_before_counter_access(self):
  def cancel():self.service._state='STOPPING';return False
  self.reject('DIAGNOSTICS_OWNER_CHANGED',cancelled=cancel)
  self.assertEqual([x.calls for x in self.ports],[0,0])
 def test_elapsed_analysis_cannot_publish_aged_result(self):
  original=collector.PerformanceDiagnostics.analyze_process_current
  def delayed(engine,*args,**kwargs):
   result=original(engine,*args,**kwargs);self.now[0]+=2_000_000_000;return result
  with patch.object(collector.PerformanceDiagnostics,'analyze_process_current',new=delayed):
   self.reject('DIAGNOSTICS_DEADLINE_EXCEEDED')
 def test_swapped_fixed_roles_during_analysis_rejects_owner(self):
  original=collector.PerformanceDiagnostics.analyze_process_current;changed=[]
  def swap(engine,*args,**kwargs):
   result=original(engine,*args,**kwargs)
   if not changed:
    a,b=self.service._service,self.service._client;a.process,b.process=b.process,a.process;changed.append(True)
   return result
  with patch.object(collector.PerformanceDiagnostics,'analyze_process_current',new=swap):self.reject('DIAGNOSTICS_OWNER_CHANGED')
 def test_clock_overflow_prevents_journal_and_counter_access(self):
  self.now[0]=2**63-1
  with patch.object(collector,'SqliteJournal',side_effect=AssertionError('unexpected Journal open')):self.reject('DIAGNOSTICS_CLOCK_INVALID')
  self.assertEqual([x.calls for x in self.ports],[0,0])
 def test_constructor_custody_and_exact_primary_are_not_replaced(self):
  primary=ContractError('CONTROLLED_JOURNAL_CONSTRUCTION');owner=object();primary.journal_custody=owner
  with patch.object(collector,'SqliteJournal',side_effect=primary):
   with self.assertRaises(ContractError) as caught:self.collect()
  self.assertIs(caught.exception,primary);self.assertIs(caught.exception.journal_custody,owner)
  self.assertEqual([x.calls for x in self.ports],[0,0])
 def test_invalid_envelope_is_rejected_before_snapshot_and_journal(self):
  with patch.object(self.service,'_diagnostics_owner_snapshot',side_effect=AssertionError('unexpected snapshot')):
   with self.assertRaises(ContractError) as caught:collector.collect_owned_diagnostics(self.service,expected_generation=GENERATION,envelope={})
  self.assertEqual(caught.exception.code,'DIAGNOSTICS_ENVELOPE_REQUIRED')
with (R/'ADVERSE.log').open('x',encoding='utf8') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Adverse))
result=dict(tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),skips=len(r.skipped),success=r.wasSuccessful(),native_process_launch=False,ordinary_imports=True,root_override=False)
(R/'ADVERSE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result));raise SystemExit(not r.wasSuccessful())
