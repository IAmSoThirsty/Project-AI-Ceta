from pathlib import Path
import ast,difflib,hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parent;J=R.parent;W=J/'work';C=R/'c';S2=J.parent/'sol-operator-diagnostics-r1';S1=J.parent/'sol-owned-diagnostics-r1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((W/'MANIFEST.json').read_bytes());s2=json.loads((S2/'work/MANIFEST.json').read_bytes());s1=json.loads((S1/'work/MANIFEST.json').read_bytes())
assert sha(W/'MANIFEST.json')=='76cc82aa6855760d6f97950572608312016d8a8233ad26f199d1031bb1d23fa1'
assert sha(S2/'work/MANIFEST.json')=='ba4498b80dea8d966e22b79c1f7fc15083b63711ca6ab749a7f8fcf717d24d44'
actual={p.relative_to(C).as_posix():sha(p) for p in C.rglob('*') if p.is_file() and not p.is_relative_to(C/'.agents/fixtures')};assert actual==m['payload_hashes'] and len(actual)==559
own={'src/ceta/composition/owned_service.py','tests/contract/test_owned_diagnostics_binding.py'};corrected='tests/contract/test_operator_resource_diagnostics.py'
for n,h in actual.items():
 if n in own:assert h==s1['candidate_hashes'][n]
 elif n==corrected:
  old=(S2/'work/candidate'/n).read_bytes();new=(C/n).read_bytes();assert old.count(b'.agents/fixtures/operator-diagnostics')==1 and old.replace(b'.agents/fixtures/operator-diagnostics',b'.agents/fixtures/opdiag')==new
  (R/'ONLY-JOIN-TEST-CORRECTION.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='Sol2/'+n,tofile='Joined/'+n)),encoding='utf8')
 else:assert h==s2['payload_hashes'][n],n
commands=[];env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0'
for lane in (J,S2):
 argv=[sys.executable,'-B','-X','utf8',str(lane/'work/verify_frozen.py')];p=subprocess.run(argv,env=env,capture_output=True)
 (R/(lane.name+'.gate.stdout')).write_bytes(p.stdout);(R/(lane.name+'.gate.stderr')).write_bytes(p.stderr)
 commands.append(dict(command=subprocess.list2cmdline(argv),exit_status=p.returncode));assert p.returncode==0,p.stderr
live=json.loads((W/'live-cli-01/RESULT.json').read_bytes());start=json.loads((W/'live-cli-01/START.json').read_bytes());custody=live['custody']
assert live['command']==start['command'];assert custody['native_owner']==json.loads((W/'live-cli-01/OWNED-LAUNCH.json').read_bytes())
assert start['script_sha256']==sha(W/'run_live_cli.py') and start['source_join_sha256']==sha(W/'JOIN.json')
assert start['python_sha256']==custody['native_owner']['image_sha256']
assert set(custody['native_owner_after'])=={'closed','process_closed','thread_closed','job_closed','startup_handles_closed'} and all(x is True for x in custody['native_owner_after'].values())
assert custody['child_exit']==0 and custody['primary_error'] is None and custody['retirement_error'] is None and custody['construction_custody'] is None
assert json.loads((W/'live-cli-01/stdout.bin').read_bytes())==custody['child_result']['payload'];assert (W/'live-cli-01/stderr.bin').read_bytes()==b''
assert live['source_pins_sha256']==sha(W/'live-cli-01/SOURCE-PINS.json') and json.loads((W/'live-cli-01/SOURCE-PINS.json').read_bytes())==actual
helper=J.parent/'runner-repair-r1/work/tools/bounded_custody.py';assert sha(helper)=='715b88ab286a524f5815ec3c47b987ba82cc50709272fdc467b7ddc76eeba1b4'
payload=custody['child_result']['payload'];assert payload['startup']=='READY' and payload['operation']=='COMPLETE_PROCESS_USAGE' and payload['cleanup']=='STOPPED'
assert payload['diagnostics']['qualification']=='NOT_ESTABLISHED' and payload['diagnostics']['task_attribution']=='UNAVAILABLE_SHARED_RUNTIME_PROCESSES'
initial=json.loads((W/'joined-tests/RESULT.json').read_bytes());assert initial['tests']==137 and initial['errors']==15 and initial['successful'] is False
ordinary=json.loads((R/'ordinary-tests/RESULT.json').read_bytes());assert ordinary['tests']==137 and ordinary['successful'] and not any(ordinary[k] for k in ('failures','errors','skips'))
assert ordinary['ordinary_imports'] and not ordinary['root_override'] and not ordinary['module_overlay']
# Preserve all unchanged launcher helper bodies and the original cleanup finally block.
base=J.parent/'sol-discovery-r2/work/candidate/tools/ceta_operator.py'
def funcs(p):return {n.name:n for n in ast.parse(p.read_bytes()).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(base),funcs(C/'tools/ceta_operator.py')
helpers=set(a)-{'main','_run_owned_ui'}
assert all(ast.dump(a[n],include_attributes=False)==ast.dump(b[n],include_attributes=False) for n in helpers)
old_try=next(n for n in a['_run_owned_ui'].body if isinstance(n,ast.Try));new_try=next(n for n in b['_run_owned_operation'].body if isinstance(n,ast.Try))
assert [ast.dump(x,include_attributes=False) for x in old_try.finalbody]==[ast.dump(x,include_attributes=False) for x in new_try.finalbody]
report=dict(status='PASS',payloads=559,joined_source_identical_to_authors=True,only_join_test_edit=corrected,unchanged_launcher_helpers=sorted(helpers),original_cleanup_finally_AST_unchanged=True,ordinary_tests=137,adverse_tests=6,live_evidence_only={'command':live['command'],'native_owner':custody['native_owner'],'native_owner_after':custody['native_owner_after'],'child_exit':0,'payload':payload,'new_native_run':False},initial_join_failure_preserved=True,commands=commands)
(R/'PROVENANCE-LIVE-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps({'status':'PASS','payloads':559,'ordinary':137,'adverse':6,'native_rerun':False}))
