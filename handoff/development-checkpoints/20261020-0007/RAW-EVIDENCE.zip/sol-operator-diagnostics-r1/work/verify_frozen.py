"""Read-only exact source, predecessor, collaborator and evidence gate."""
from pathlib import Path
import hashlib
import json
import subprocess
w = Path(__file__).resolve().parent
repo = w.parents[4]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((w / "MANIFEST.json").read_text())
base = json.loads((w / "BASELINE.json").read_text())["payload_hashes"]
assert len(base) == 554
candidate = w / "candidate"
actual = {str(p.relative_to(candidate)).replace("\\", "/"): sha(p)
          for p in candidate.rglob("*") if p.is_file() and not p.is_relative_to(candidate / ".agents/fixtures")}
assert actual == m["payload_hashes"], "source payload drift"
assert len(actual) == 558
changed = {n for n in base if base[n] != actual.get(n)}
assert changed == {"src/ceta/application/operator.py", "tools/ceta_operator.py"}
assert set(actual) - set(base) == set(m["added_paths"])
for n in base:
    if n not in changed: assert actual[n] == base[n], n
for p, h in m["predecessor_hashes"].items(): assert sha(Path(p)) == h, p
for n, h in m["support_hashes"].items(): assert sha(w / n) == h, n
for n, h in m["canonical_hashes"].items(): assert sha(repo / n) == h, n
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == m["git_head"]
assert subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True) == m["git_status"]
tests = json.loads((w / "TESTS.json").read_text())
assert tests["tests"] == 112 and tests["successful"] and not any(tests[k] for k in ("failures", "errors", "skips"))
assert sha(Path(tests["collaborator"])) == tests["collaborator_sha256"]
for n, h in tests["tested_source_hashes"].items():
    assert actual[n] == h
    compile((candidate / n).read_bytes(), str(candidate / n), "exec")
probe = json.loads((w / "CLI-INVALID-ENVELOPE.json").read_text())
assert probe["exit_status"] == 2 and probe["source_sha256"] == actual["tools/ceta_operator.py"]
print("FROZEN PASS:554 baseline payloads conserved except operator.py/ceta_operator.py;4 additions;112 controlled tests passed;negative CLI exit2;collaborator separately pinned")
