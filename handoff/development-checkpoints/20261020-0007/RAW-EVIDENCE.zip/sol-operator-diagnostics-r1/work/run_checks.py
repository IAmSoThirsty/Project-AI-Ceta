"""Test the exact two-owner seam using a pinned read-only collaborator module."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import unittest
w = Path(__file__).resolve().parent
candidate = w / "candidate"
other = w.parents[1] / "sol-owned-diagnostics-r1/work"
p = other / "candidate/src/ceta/composition/owned_service.py"
manifest = json.loads((other / "MANIFEST.json").read_text())
assert hashlib.sha256(p.read_bytes()).hexdigest() == manifest["candidate_hashes"]["src/ceta/composition/owned_service.py"]
sys.path[:0] = [str(candidate / "src"), str(candidate / "tests/contract")]
spec = importlib.util.spec_from_file_location("ceta.composition.owned_service", p)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
# Test-only fixture root relocation: run the collaborator's exact source against
# this lane's disposable files; no copy or edit of its owned source is made.
module.ROOT = candidate
names = ["test_operator_resource_diagnostics", "test_operator_diagnostics_launcher",
         "test_resource_diagnostics_continuation", "test_process_diagnostics.ProcessDiagnosticsTests",
         "test_shutdown_lifecycle.ShutdownContractTests", "test_shutdown_lifecycle.ContextShutdownTests",
         "test_shutdown_interruptions.InterruptionContractTests", "test_shutdown_interruptions.LauncherInterruptionTests",
         "test_shutdown_session_failures.LauncherDiagnosticMutationTests", "test_outer_process_shutdown_handoff.LauncherRecordTests"]
with (w / "TESTS.log").open("w", encoding="utf8") as log:
    print("python", sys.executable, sys.version, "collaborator", p, file=log)
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.TestSuite(
        unittest.defaultTestLoader.loadTestsFromName(name) for name in names))
report = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skips=len(result.skipped), successful=result.wasSuccessful(), names=names,
              collaborator=str(p), collaborator_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
              fixture_root_override=str(candidate), python=sys.executable, version=sys.version,
              tested_source_hashes={n: hashlib.sha256((candidate / n).read_bytes()).hexdigest() for n in (
                  "src/ceta/composition/resource_diagnostics.py", "src/ceta/application/operator.py",
                  "tools/ceta_operator.py", "tests/contract/test_operator_resource_diagnostics.py",
                  "tests/contract/test_operator_diagnostics_launcher.py")})
(w / "TESTS.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
sys.exit(not result.wasSuccessful())
