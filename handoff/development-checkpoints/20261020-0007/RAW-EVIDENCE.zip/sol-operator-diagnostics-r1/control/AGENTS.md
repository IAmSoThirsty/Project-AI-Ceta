# Exact existing CETA diagnostics code implementation scope

Use the existing r6 specification and shared INTERFACE.txt. All canonical source, pinned predecessors and Git remain read-only. No native profile/debug/host configuration. Only fixed own-process observation and own disposable test fixtures. Distinct review and actual gate before source-only handoff.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-operator-diagnostics-r1/work/**"
        ]
      },
      "review": {
        "kind": "agent",
        "role": "reviewer",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-operator-diagnostics-r1/review/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-operator-diagnostics-r1/delivery/**"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:\\00-Active\\Project-AI-CETA\\.agents\\source-assembly-20261014T021300Z\\.agents\\e3\\Scripts\\python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\operational-resume-20261020\\sol-operator-diagnostics-r1\\work\\verify_frozen.py\""
        ]
      }
    }
  }
}
```
