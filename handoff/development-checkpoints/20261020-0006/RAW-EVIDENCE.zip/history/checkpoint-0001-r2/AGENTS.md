# Exact development checkpoint publication scopes

User authorizes recurring local development commits and pushes. Prepare immutable objects and temporary index only inside work. Distinct review and validation precede publication. Integrator claims only the existing .git directory; exact declared paths admit object import plus development/checkpoints refs/logs/locks and reject HEAD, index, config and unrelated refs. No force, reset, clean, hooks bypass, source cutover or visibility change. Preserve all evidence.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/development-checkpoint-20261020/work/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.git",
          "00-Active/Project-AI-CETA/.git/objects/**",
          "00-Active/Project-AI-CETA/.git/refs/heads/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/refs/heads/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/logs/refs/heads/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/logs/refs/heads/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/refs/remotes/origin/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/refs/remotes/origin/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/logs/refs/remotes/origin/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/logs/refs/remotes/origin/development/checkpoints.lock"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:\\00-Active\\Project-AI-CETA/.agents/source-assembly-20261014T021300Z/.agents/e3/Scripts/python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\development-checkpoint-20261020/work/verify_prepared.py\""
        ]
      }
    }
  }
}
```
