from pathlib import Path
import sys,unittest,json
R=Path(__file__).resolve().parent;W=R.parent/'work'
source=W.parents[1]/'token-integration-r1/work/candidate' if '--baseline' in sys.argv else W/'candidate'
sys.path[:0]=[str(source/'src'),str(W/'candidate/tests/contract')]
import ceta.resource.diagnostics as target
assert Path(target.__file__).resolve()==(source/'src/ceta/resource/diagnostics.py').resolve()
names=['test_resource_diagnostics_continuation']
if '--baseline' not in sys.argv:
 names+=['test_process_diagnostics.ProcessDiagnosticsTests','test_process_observation_timing.ProcessObservationTimingTests','test_process_performance_comparison.ProcessPerformanceComparisonTests','test_resource_management.DiagnosticTests','test_resource_management.CurrentComparisonTests','test_process_observation_validation.IndependentTimingBoundaryTests','test_process_observation_validation.NestedMeasurementValidationTests']
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names))
print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),source=str(target.__file__),successful=result.wasSuccessful())))
sys.exit(not result.wasSuccessful())
