from pathlib import Path
import sys,unittest,threading
from dataclasses import replace,asdict
from unittest.mock import patch
R=Path(__file__).resolve().parent;C=R.parent/'work/candidate'
sys.path[:0]=[str(C/'src'),str(C/'tests/contract')]
from ceta.resource.diagnostics import PerformanceDiagnostics,PerformanceEnvelope
from ceta.contracts.wire import ContractError
import test_process_diagnostics as f
class IndependentWindowTests(unittest.TestCase):
 def setUp(self):
  self.now,self.port,self.sampler=f.ProcessDiagnosticsTests().fixture()
  self.a=self.sampler.sample();self.now[0]=110;self.port.next=f.counters(110,cpu=200,read=600,write=250,private=1200);self.b=self.sampler.sample()
  self.engine=PerformanceDiagnostics();self.env=PerformanceEnvelope(20,2000,10000)
 def analyze(self,samples=None,**overrides):
  kw=dict(now_monotonic_ns=120,maximum_age_ns=100,scope_digest=f.digest('scope'),environment_digest=f.digest('environment'));kw.update(overrides)
  return self.engine.analyze_process_current((self.a,self.b) if samples is None else samples,self.env,**kw)
 def reject(self,samples,code):
  r=self.analyze(samples);self.assertEqual(r.measurement_state,'CURRENT_PROCESS_INPUT_REJECTED');self.assertIn(code,r.findings);self.assertEqual((r.read_io_bytes,r.write_io_bytes,r.peak_private_bytes),(None,None,None))
 def test_each_counter_in_either_frame_requires_exact_wrapper_time(self):
  for index,sample in enumerate((self.a,self.b)):
   for field in ('cpu_time_100ns','private_bytes','read_io_bytes','write_io_bytes'):
    for offset in (-1,1):
     with self.subTest(index=index,field=field,offset=offset):
      t=sample.observed_monotonic_ns+offset
      usage=replace(sample.process_usage,window_started_monotonic_ns=min(t,sample.observed_monotonic_ns),**{field:replace(getattr(sample.process_usage,field),observed_monotonic_ns=t)})
      samples=[self.a,self.b];samples[index]=replace(sample,process_usage=usage)
      self.reject(tuple(samples),'PROCESS_COUNTER_WINDOW_INCOHERENT')
 def test_probe_start_exact_freshness_boundary_both_frames(self):
  for index,sample in enumerate((self.a,self.b)):
   with self.subTest(index=index):
    samples=[self.a,self.b];samples[index]=replace(sample,process_usage=replace(sample.process_usage,window_started_monotonic_ns=20))
    self.assertEqual(self.analyze(tuple(samples)).read_io_bytes,500)
    samples[index]=replace(sample,process_usage=replace(sample.process_usage,window_started_monotonic_ns=19))
    self.reject(tuple(samples),'PROCESS_COUNTER_WINDOW_STALE_OR_FUTURE')
 def test_duplicate_id_rejected_with_distinct_valid_sequence(self):
  self.reject((self.a,replace(self.b,sample_id=self.a.sample_id)),'PROCESS_SAMPLE_REUSED_OR_DUPLICATED')
 def test_all_copied_members_are_owned_at_calculation_boundary(self):
  original=PerformanceDiagnostics.analyze_current
  def capture(engine,samples,envelope,**kw):
   self.assertIsNot(envelope,self.env)
   for owned,caller in zip(samples,(self.a,self.b)):
    self.assertIsNot(owned,caller);self.assertIsNot(owned.source,caller.source);self.assertIsNot(owned.process_usage,caller.process_usage)
    for field in ('cpu_milli','memory_bytes','storage_bytes','latency_ms'):self.assertIsNot(getattr(owned,field),getattr(caller,field))
    for field in ('cpu_time_100ns','private_bytes','read_io_bytes','write_io_bytes'):self.assertIsNot(getattr(owned.process_usage,field),getattr(caller.process_usage,field))
   return original(engine,samples,envelope,**kw)
  with patch.object(PerformanceDiagnostics,'analyze_current',capture):self.assertEqual(self.analyze().read_io_bytes,500)
 def test_concurrent_mutation_after_snapshot_does_not_rebind_identity(self):
  ready=threading.Event();changed=threading.Event();original=PerformanceDiagnostics.analyze_current;errors=[]
  def mutate():
   try:
    if not ready.wait(3):raise AssertionError('snapshot not reached')
    object.__setattr__(self.b.source,'source_generation',999)
    object.__setattr__(self.b.process_usage.read_io_bytes,'value',2**63-1)
    changed.set()
   except BaseException as e:errors.append(e);changed.set()
  def paused(engine,samples,envelope,**kw):
   ready.set();self.assertTrue(changed.wait(3));return original(engine,samples,envelope,**kw)
  worker=threading.Thread(target=mutate);worker.start()
  with patch.object(PerformanceDiagnostics,'analyze_current',paused):r=self.analyze()
  worker.join(3);self.assertFalse(worker.is_alive());self.assertEqual(errors,[]);self.assertEqual(r.read_io_bytes,500);self.assertEqual(r.measurement_state,'MEASURED_PROCESS_USAGE')
  self.reject((self.a,self.b),'PROCESS_SOURCE_MIXED')
 def test_nested_mutated_invalid_value_cannot_enter_arithmetic(self):
  for index,sample in enumerate((self.a,self.b)):
   for field in ('cpu_time_100ns','private_bytes','read_io_bytes','write_io_bytes'):
    with self.subTest(index=index,field=field):
     q=replace(getattr(sample.process_usage,field));object.__setattr__(q,'value',True)
     usage=replace(sample.process_usage,**{field:q});samples=[self.a,self.b];samples[index]=replace(sample,process_usage=usage)
     with self.assertRaises(ContractError):self.analyze(tuple(samples))
 def test_size_bound_precedes_iteration_and_copy(self):
  class NotTuple:
   def __iter__(self):raise AssertionError('iteration happened')
  with patch.object(PerformanceDiagnostics,'_copy_process_sample',side_effect=AssertionError('copy happened')):
   for samples in (NotTuple(),(self.a,)*8193):
    with self.assertRaisesRegex(ContractError,'RESOURCE_CURRENT_DIAGNOSTIC_INPUT_INVALID'):self.analyze(samples)
 def test_rejected_window_does_not_modify_later_valid_analysis(self):
  before=asdict(self.a),asdict(self.b)
  self.reject((self.a,replace(self.b,source=replace(self.b.source,sequence=9))),'PROCESS_SEQUENCE_GAP_OR_REPLAY')
  self.assertEqual(self.analyze().read_io_bytes,500);self.assertEqual((asdict(self.a),asdict(self.b)),before)
if __name__=='__main__':unittest.main(verbosity=2)
