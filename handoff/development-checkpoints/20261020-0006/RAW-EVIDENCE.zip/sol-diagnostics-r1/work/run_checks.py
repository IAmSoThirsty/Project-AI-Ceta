"""Run only controlled in-process diagnostics suites, without native launch."""
from pathlib import Path
import argparse
import json
import platform
import sys
import unittest

w = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--baseline", action="store_true")
args = parser.parse_args()
baseline = w.parents[1] / "token-integration-r1/work/candidate"
source = baseline if args.baseline else w / "candidate"
sys.path[:0] = [str(source / "src"), str(w / "candidate/tests/contract")]
import ceta.resource.diagnostics as target
assert Path(target.__file__).resolve() == (source / "src/ceta/resource/diagnostics.py").resolve()
names = ["test_resource_diagnostics_continuation"]
if not args.baseline:
    names += ["test_process_diagnostics.ProcessDiagnosticsTests",
              "test_process_observation_timing.ProcessObservationTimingTests",
              "test_process_performance_comparison.ProcessPerformanceComparisonTests",
              "test_resource_management.DiagnosticTests", "test_resource_management.CurrentComparisonTests",
              "test_process_observation_validation.IndependentTimingBoundaryTests",
              "test_process_observation_validation.NestedMeasurementValidationTests"]
label = "BASELINE-FINAL" if args.baseline else "FINAL-CHECKS"
with (w / (label + ".log")).open("w", encoding="utf-8") as log:
    print("source", target.__file__, "python", sys.executable, sys.version, "platform", platform.platform(), file=log)
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(
        unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in names))
summary = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
               skips=len(result.skipped), successful=result.wasSuccessful(), names=names,
               source=str(source), python=sys.executable, version=sys.version, command=sys.argv)
(w / (label + ".json")).write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary))
if args.baseline:
    sys.exit(0 if not result.wasSuccessful() and not result.errors else 1)
sys.exit(not result.wasSuccessful())
