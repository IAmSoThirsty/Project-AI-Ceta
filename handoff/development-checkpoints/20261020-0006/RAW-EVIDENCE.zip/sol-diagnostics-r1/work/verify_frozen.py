"""Read-only frozen source/evidence conservation gate for this exact lane."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

w = Path(__file__).resolve().parent
repo = w.parents[4]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((w / "MANIFEST.json").read_text(encoding="utf-8"))
bp = Path(m["baseline_manifest"]["path"])
assert sha(bp) == m["baseline_manifest"]["sha256"], "baseline manifest drift"
b = json.loads(bp.read_text(encoding="utf-8"))
base = Path(b["candidate"])
assert len(b["payload_hashes"]) == 552
for name, expected in b["payload_hashes"].items():
    assert sha(base / name) == expected, ("baseline drift", name)
candidate = w / "candidate"
actual = {str(p.relative_to(candidate)).replace("\\", "/"): sha(p)
          for p in candidate.rglob("*") if p.is_file()}
assert actual == m["payload_hashes"], "candidate source hash/set drift"
changed = {n for n, h in b["payload_hashes"].items() if actual.get(n) != h}
assert changed == {"src/ceta/resource/diagnostics.py"}, changed
assert set(actual) - set(b["payload_hashes"]) == {"tests/contract/test_resource_diagnostics_continuation.py"}
assert all(sha(w / name) == expected for name, expected in m["evidence_hashes"].items()), "evidence drift"
for name in changed | (set(actual) - set(b["payload_hashes"])):
    compile((candidate / name).read_bytes(), str(candidate / name), "exec")
for name, expected in m["canonical_hashes"].items():
    assert sha(repo / name) == expected, ("canonical drift", name)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip() == m["git_head"]
assert subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True) == m["git_status"]
checks = json.loads((w / "FINAL-CHECKS.json").read_text())
assert checks["tests"] == 156 and checks["successful"] and not any(checks[k] for k in ("failures", "errors", "skips"))
red = json.loads((w / "BASELINE-FINAL.json").read_text())
assert red["tests"] == 12 and red["failures"] == 16 and red["errors"] == 0 and not red["successful"]
print("FROZEN PASS: 553 payloads; baseline552 conserved except diagnostics.py; one added test; 156 controlled tests passed; baseline failures retained")
