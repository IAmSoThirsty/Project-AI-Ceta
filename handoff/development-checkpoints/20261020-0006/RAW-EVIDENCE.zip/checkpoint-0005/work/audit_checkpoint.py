"""Read-only supplemental audit of this exact local development candidate."""
from pathlib import Path, PurePosixPath
import json
import zipfile
from prepare_checkpoint import batch_blobs, checkout_state, digest, git, save, stable_read

W = Path(__file__).resolve().parent
F = Path(r'T:\00-Active\Project-AI-CETA')
P = W.parent.parent / 'checkpoint-0004' / 'work'
prepared = json.loads((W / 'prepared-0001/PREPARED.json').read_bytes())
previous = json.loads((P / 'prepared-0001/PREPARED.json').read_bytes())
spec = json.loads((W / 'CHECKPOINT-INPUTS.json').read_bytes())
before = json.loads((W / 'CANONICAL-BEFORE.json').read_bytes())
env = prepared['git_environment']


def tree(commit):
    result = {}
    for entry in git(F, ['ls-tree', '-r', '-z', commit], env=env).split(b'\0'):
        if entry:
            header, name = entry.split(b'\t', 1)
            result[name.decode('utf-8')] = tuple(header.decode('ascii').split())
    return result


parent_tree = tree(prepared['parent'])
child_tree = tree(prepared['commit'])
status_names = {'DEVELOPMENT-CHECKPOINT.json', 'DEVELOPMENT-CHECKPOINT.md'}
actual_old_changes = {name for name in parent_tree if child_tree.get(name) != parent_tree[name]}
assert actual_old_changes == status_names, actual_old_changes
assert not (set(parent_tree) - set(child_tree))
assert len(previous['exports']) == 765 and len(prepared['exports']) == len(manifest_payloads := json.loads(Path(spec['manifest']).read_bytes())['payload_hashes']) + len(spec['extra_exports'])
assert set(previous['exports']) <= set(prepared['exports'])
unchanged = set(previous['exports']) - status_names
assert len(unchanged) == 763
assert all(previous['exports'][n]['sha256'] == prepared['exports'][n]['sha256']
           and parent_tree[n] == child_tree[n] for n in unchanged)
manifest_raw, manifest_pin = stable_read(spec['manifest'])
assert manifest_pin['sha256'] == spec['manifest_sha256']
manifest = json.loads(manifest_raw)
assert len(manifest['payload_hashes']) == 552
assert all(parent_tree[n] == child_tree[n]
           and prepared['exports'][n]['sha256'] == value
           for n, value in manifest['payload_hashes'].items())
fixtures = json.loads((W / 'public/STATUS.json').read_bytes())['preserved_registry_fixtures']
assert len(fixtures) == 5 and all(parent_tree[n] == child_tree[n] for n in fixtures)
pdf_paths = sorted(n for n in parent_tree if 'pdf' in n.lower())
assert pdf_paths and all(parent_tree[n] == child_tree[n] for n in pdf_paths)
archive = W / 'public/RAW-EVIDENCE.zip'
transport = json.loads((W / 'public/EVIDENCE-TRANSPORT.json').read_bytes())
if transport['members']:
    assert digest(archive.read_bytes()) == transport['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert z.namelist() == [m['member'] for m in transport['members']]
        for item, info in zip(transport['members'], z.infolist(), strict=True):
            parts = PurePosixPath(info.filename).parts
            assert not info.filename.startswith('/') and '..' not in parts
            assert '\\' not in info.filename and ':' not in info.filename
            assert info.compress_type == zipfile.ZIP_STORED and not info.is_dir()
            assert info.date_time == (1980, 1, 1, 0, 0, 0)
            raw, pin = stable_read(item['source'])
            assert pin['sha256'] == item['sha256'] and len(raw) == item['bytes']
            assert z.read(info.filename) == raw
    for name in ('RAW-EVIDENCE-SECRET-SCAN.json', 'RAW-EVIDENCE-ARCHIVE-SCAN.json'):
        scan = json.loads((W / 'public' / name).read_bytes())
        assert not scan['findings'] and scan['result'] == 'PASS'
else:
    assert transport['method'] == 'NO_TRANSPORT_REQUIRED' and not archive.exists()
    preflight = json.loads((W / 'EXPORT-PREFLIGHT.json').read_bytes())
    scan = json.loads((W / 'RAW-SELECTED-EXPORT-SCAN.json').read_bytes())
    assert not preflight['whitespace_issues'] and not scan['findings']
    assert scan['result'] == 'PASS'
source = json.loads((W / 'public/SOURCE-PROVENANCE.json').read_bytes())
compiled = []
for item in source['exact_authored_python_exports']:
    raw, pin = stable_read(item['source'])
    assert pin['sha256'] == item['sha256']
    compile(raw, item['source'], 'exec')
    compiled.append(item['path'])
assert len(compiled) == len(source['exact_authored_python_exports'])
for name in ('prepare_checkpoint.py', 'publish_checkpoint.py', 'verify_prepared.py'):
    assert (W / name).read_bytes() == (P / name).read_bytes()
    compile((W / name).read_bytes(), str(W / name), 'exec')
historical = {
    'loader-capture-r2': '88499a9e6f8f2ec21d394ca6712759791c07a9685d67643cbc36e5b51a24ea4d',
    'loader-capture-r3': 'a9c092ebc3e23573f17dc5bf95286946e2836091258eee24c0e59c5bf21559c8',
    'loader-capture-r4': 'df5b0ce0f4360196c04c4883ff74fd580e68bdb5e7eabbac2c1252c090cf5c87',
}
for name, value in historical.items():
    path = f'handoff/development-checkpoints/20261020-0003/history/rejected-reviews/{name}/REVIEW.json'
    assert prepared['exports'][path]['sha256'] == value
assert not any(n.endswith('.py') and '/history/' in n for n in prepared['exports'])
assert all(Path(v).is_relative_to(W) for k, v in env.items()
           if k != 'GIT_ALTERNATE_OBJECT_DIRECTORIES')
assert git(F, ['cat-file', '--batch-check'], data=(prepared['commit'] + '\n').encode()).strip() == (prepared['commit'] + ' missing').encode()
after = dict(checkout=checkout_state(F), normal_index_native=stable_read(F / '.git/index')[1],
             canonical_export_path_pins={n: stable_read(F / n)[1] if (F / n).exists() else None
                                         for n in prepared['exports']},
             refs=git(F, ['for-each-ref', '--format=%(refname) %(objectname)']).decode().splitlines(),
             active_source_worktree_edited=False)
assert after == before, 'canonical paths, index metadata, checkout or refs drifted'
save(W / 'CANONICAL-AFTER.json', after)
save(W / 'CONSERVATION.json', dict(status='PASS', before_sha256=digest((W / 'CANONICAL-BEFORE.json').read_bytes()),
    after_sha256=digest((W / 'CANONICAL-AFTER.json').read_bytes()),
    canonical_export_paths_checked=len(after['canonical_export_path_pins']),
    index_bytes_and_native_identity_and_mtime_unchanged=True, refs_unchanged=True,
    prepared_commit_absent_from_normal_object_database=True, native_effects=False))
result = dict(status='PASS', commit=prepared['commit'], tree=prepared['tree'],
    parent=prepared['parent'], parent_tree_paths=len(parent_tree), child_tree_paths=len(child_tree),
    prior_exports=765, prior_exports_unchanged=763, updated_existing_paths=sorted(actual_old_changes),
    new_paths=sorted(set(child_tree) - set(parent_tree)), product_payloads_unchanged=552,
    immutable_registry_fixtures_unchanged=fixtures, pdf_named_paths_unchanged=pdf_paths,
    transported_evidence_files=len(transport['members']),
    archive_exact_roundtrip=True if transport['members'] else 'NOT_APPLICABLE_NO_NEW_ARCHIVE',
    original_and_archive_scans='PASS' if transport['members'] else 'RAW_SELECTED_PASS_NO_NEW_ARCHIVE',
    newly_exported_python_compiled_without_import=compiled, reviewed_tools_exact_copies=True,
    rejected_reviews_exact=historical, canonical_conservation='PASS',
    product_source_lines_authored=0, product_test_lines_authored=0,
    product_acceptance=False, native_execution=False, publication=False)
save(W / 'SUPPLEMENTAL-AUDIT.json', result)
print(json.dumps({k: v for k, v in result.items() if k not in ('new_paths', 'pdf_named_paths_unchanged', 'newly_exported_python_compiled_without_import')}, indent=2))
