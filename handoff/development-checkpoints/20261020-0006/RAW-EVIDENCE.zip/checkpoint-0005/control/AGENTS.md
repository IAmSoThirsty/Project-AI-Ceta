# Fifth scheduled CETA development checkpoint

Fresh exact scope. Preserve prior failed receipt; parent checkpoint 030b0c091e451c871e260cac845e376af225d2da. Preparation uses an isolated object directory and index under work. Distinct review and gate precede one ordinary hook-enabled publication. The actual integrator claims .git itself, with exact object/ref/log/lock/cache scopes. Preserve active HEAD, normal index and source files. No other refs, force, cleanup, hook bypass, visibility change or source promotion.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/development-checkpoint-20261020/checkpoint-0005/work/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.git",
          "00-Active/Project-AI-CETA/.git/objects/**",
          "00-Active/Project-AI-CETA/.git/refs/heads/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/refs/heads/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/logs/refs/heads/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/logs/refs/heads/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/refs/remotes/origin/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/refs/remotes/origin/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/logs/refs/remotes/origin/development/checkpoints",
          "00-Active/Project-AI-CETA/.git/logs/refs/remotes/origin/development/checkpoints.lock",
          "00-Active/Project-AI-CETA/.git/lfs/cache/locks/refs/heads/development/checkpoints/verifiable",
          "00-Active/Project-AI-CETA/.git/lfs/cache/locks/refs/heads/development/checkpoints/verifiable.lock"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:\\00-Active\\Project-AI-CETA\\.agents\\source-assembly-20261014T021300Z\\.agents\\e3\\Scripts\\python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\development-checkpoint-20261020\\checkpoint-0005\\work\\verify_prepared.py\""
        ]
      }
    }
  }
}
```
