"""Read-only source conservation and deterministic affinity regression gate."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    work = Path(__file__).resolve().parent
    manifest = json.loads((work / 'MANIFEST.json').read_bytes())
    candidate = work / 'candidate'
    baseline = json.loads((work / 'BASELINE.json').read_bytes())
    previous = json.loads((work / 'R1-PROVENANCE.json').read_bytes())
    r1 = Path(previous['source'])
    assert sha(r1 / 'work/MANIFEST.json') == previous['r1_manifest_sha256']
    for rel, digest in previous['r1_candidate_hashes'].items():
        assert sha(r1 / 'work/candidate' / rel) == digest, ('r1 candidate changed', rel)
    for rel, digest in previous['history_hashes'].items():
        assert sha(r1 / rel) == digest, ('r1 evidence changed', rel)
        assert sha(work / 'r1-history' / rel) == digest, ('copied r1 evidence changed', rel)
    assert sha(work / 'r1-history/ROOT-DISCOVERY-CACHE-CONFLICT-REPRODUCTION.json') == previous['root_reproduction_sha256']
    assert sha(Path(baseline['manifest'])) == baseline['manifest_sha256']
    assert len(baseline['payload_hashes']) == 552
    changed = []
    for rel, digest in baseline['payload_hashes'].items():
        assert sha(Path(baseline['baseline']) / rel) == digest, ('old source changed', rel)
        if sha(candidate / rel) != digest:
            changed.append(rel)
    assert changed == ['src/ceta/resource/hardware.py'], changed
    actual = {p.relative_to(candidate).as_posix(): sha(p)
              for p in candidate.rglob('*') if p.is_file()}
    assert actual == manifest['candidate_hashes'], 'candidate bytes/paths changed'
    assert len(actual) == 553
    for rel, digest in manifest['support_hashes'].items():
        assert sha(work / rel) == digest, ('support changed', rel)
    for rel in ('src/ceta/resource/hardware.py', 'tests/contract/test_hardware_discovery_continuation.py'):
        compile((candidate / rel).read_bytes(), str(candidate / rel), 'exec')
    env = os.environ.copy()
    env['PYTHONPATH'] = str(candidate / 'src') + os.pathsep + str(candidate / 'tests/contract')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    result = subprocess.run([sys.executable, '-B', '-X', 'utf8', '-m', 'unittest', 'discover',
                             '-s', str(candidate / 'tests/contract'), '-p',
                             'test_hardware_discovery_continuation.py', '-v'],
                            cwd=candidate, env=env, capture_output=True)
    sys.stdout.buffer.write(result.stdout)
    sys.stderr.buffer.write(result.stderr)
    assert result.returncode == 0, result.returncode
    print(json.dumps(dict(baseline_conserved=552, candidate_files=553,
                         changed_source=changed, deterministic_regression_exit=0)))


if __name__ == '__main__':
    main()
