# Discovery r2: preserve an observed scope conflict

This successor copies the exact frozen r1 candidate into its own leased work
directory and preserves r1 FAILED state, receipts, denial, illegal-transition
response, raw diagnostics and Root's independent defect reproduction. Provenance
and hash maps are in R1-PROVENANCE.json. No r1 or canonical bytes are modified.

The narrow repair is two source lines: a mismatching native scope observed while
checking positive cached CPU capacity sets the existing
CPU_PROCESSOR_GROUP_SCOPE_UNAVAILABLE reason. Existing code then publishes an
unavailable observation and clears the old counter baseline without taking a new
counter frame. A later qualified call establishes a new baseline before measured
capacity can return. Public signatures and injected-reader behavior are preserved.

The added deterministic test reproduces Root's exact scope sequence of None,
(1,4), (1,4). It asserts that the conflict consumes only the first scope answer,
does not read a counter, clears the old baseline, denies available_capacity,
then produces BASELINE_REQUIRED and a later measured result from fresh frames.
The new 12-test continuation suite fails exactly this regression against r1 and
passes against r2. Existing hardware 52 and resource 95 tests pass. Byte-identical
copies of the changed files pass compileall under a short local work path.
The r1 expected baseline failures and repaired compilation failure retain their
original nonzero statuses in r1-history; COMMANDS.json preserves r2's r1-regression
failure. Only actual final passing gates are submitted as acceptance commands.

Author self-review: the observed conflict now reaches the existing unavailable
branch before _read_counters; that branch clears _previous. The sample sequence
advances, cached positive capacity is replaced, and subsequent recovery is already
guarded by the monitor lock and fresh-baseline behavior. Query-time fences from r1
remain covered by both public-clock and elapsed-clock tests. No scheduling, state,
authority or evidence owner is introduced.

Source responsibility remains EXTEND CETA-20.01.02 and REUSE CETA-20.01.01/.03.
This regression covers bounded subcases of AT-CETA-20.01.02-02, -04, -08 and -09;
the inherited r1 tests cover reservation subtraction, malformed masks, bounds,
interruption and concurrent requests. These are acceptance subcases, not a claim
that all original rows or the full hardware-discovery component are complete.
Independent review remains pending. CPU sets, thread affinity, job CPU rate limits,
accelerator runtime utilization, worker ownership and complete admission wiring
remain separate follow-up work. No host settings, profile, canonical source or
Git mutation occurred.
