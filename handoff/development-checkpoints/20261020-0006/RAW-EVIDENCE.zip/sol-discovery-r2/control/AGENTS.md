# Exact CETA sol-discovery-r2 source/evidence scope

Existing user code authority. Canonical product, old inputs and Git are read-only. Actual distinct review precedes source-only handoff. No native profile/debug/memory effect, host repair or promotion.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-discovery-r2/work/**"
        ]
      },
      "review": {
        "kind": "agent",
        "role": "reviewer",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-discovery-r2/review/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-discovery-r2/delivery/**"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:\\00-Active\\Project-AI-CETA\\.agents\\source-assembly-20261014T021300Z\\.agents\\e3\\Scripts\\python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\operational-resume-20261020\\sol-discovery-r2\\work\\verify_frozen.py\""
        ]
      }
    }
  }
}
```
