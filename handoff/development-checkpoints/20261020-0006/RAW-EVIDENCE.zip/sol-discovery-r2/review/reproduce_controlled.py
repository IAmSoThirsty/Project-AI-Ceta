from pathlib import Path
import sys,unittest,json
from unittest.mock import patch
R=Path(__file__).resolve().parent;W=R.parent/'work'
source=W.parents[1]/'sol-discovery-r1/work/candidate' if '--r1' in sys.argv else W/'candidate'
sys.path[:0]=[str(source/'src'),str(W/'candidate/tests/contract')]
import ceta.resource.hardware as hardware
assert Path(hardware.__file__).resolve()==(source/'src/ceta/resource/hardware.py').resolve()
names=['test_hardware_discovery_continuation']
if '--r1' not in sys.argv:names+=['test_hardware_observation.HardwareObservationTests']
attempts=[]
def native(*args,**kwargs):
 attempts.append(str(args));raise AssertionError('unexpected native read in controlled review')
with patch('ceta.resource.hardware.ctypes.WinDLL',side_effect=native),patch('ceta.resource.hardware.shutil.disk_usage',side_effect=native):
 def leaves(suite):
  for test in suite:
   if isinstance(test,unittest.TestSuite):yield from leaves(test)
   else:yield test
 excluded=['test_default_elapsed_fence_rejects_zero_coarse_delta_overlong_probes', 'test_profiler_keeps_earliest_time_and_static_accelerator_semantics', 'test_profiler_rejects_oversized_accelerator_capacity', 'test_profiler_rejects_window_exceedance_as_one_coherent_unknown_profile', 'test_profiler_rollback_skips_probes_and_does_not_lower_high_water', 'test_profiler_sequences_and_entire_probe_windows_are_serialized', 'test_profiler_storage_invalid_fields_remain_unavailable']
 tests=list(leaves(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)))
 selected=[t for t in tests if t._testMethodName not in excluded]
 result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),native_attempts=attempts,source=str(hardware.__file__))))
assert not attempts,attempts
sys.exit(not result.wasSuccessful())
