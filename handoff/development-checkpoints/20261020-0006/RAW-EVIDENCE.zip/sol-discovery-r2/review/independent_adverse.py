from pathlib import Path
import sys,unittest,threading
from unittest.mock import patch
R=Path(__file__).resolve().parent;C=R.parent/'work/candidate';sys.path[:0]=[str(C/'src'),str(C/'tests/contract')]
from ceta.resource.hardware import WindowsComputeAvailabilityMonitor,SamplingPolicy,available_capacity
from ceta.contracts.resource_management import ResourceVector
from ceta.resource.pressure import ResourcePressureDetector
class IndependentCacheConflictTests(unittest.TestCase):
 def setup_monitor(self):
  now=[100];frames=iter(((1000,100),(2000,1100),(3000,1200),(4000,1700)));reads=[]
  def read():reads.append(now[0]);return next(frames)
  with patch.object(WindowsComputeAvailabilityMonitor,'_system_times',side_effect=read):
   m=WindowsComputeAvailabilityMonitor(clock=lambda:now[0],policy=SamplingPolicy(maximum_age_ns=100,minimum_interval_ns=10,control_cpu_milli=50),processor_count=lambda:4)
  with patch.object(m,'_native_processor_scope',return_value=(1,4)):
   self.assertEqual(m.sample().free.reason,'CPU_BASELINE_REQUIRED');now[0]=110;self.assertEqual(m.sample().reservable.value,3950)
  now[0]=111;return m,now,reads
 def test_each_transient_scope_conflict_terminates_before_reprobe(self):
  for scope in (None,(1,3),(2,4)):
   with self.subTest(scope=scope):
    m,now,reads=self.setup_monitor()
    with patch.object(m,'_native_processor_scope',side_effect=[scope,(1,4),(1,4)]) as call:r=m.sample()
    self.assertEqual(call.call_count,1);self.assertEqual(reads,[100,110]);self.assertIsNone(m._previous);self.assertEqual(r.free.reason,'CPU_PROCESSOR_GROUP_SCOPE_UNAVAILABLE')
    self.assertIsNone(available_capacity(r,ResourceVector(0,0,0,0),111,100));self.assertFalse(ResourcePressureDetector().observe(r,current=True).admission_open)
    with patch.object(m,'_native_processor_scope',return_value=(1,4)):
     self.assertIs(m.sample(),r);now[0]=121;self.assertEqual(m.sample().free.reason,'CPU_BASELINE_REQUIRED');now[0]=131;self.assertEqual(m.sample().free.value,2000)
 def test_conflict_and_time_failure_both_clear_baseline(self):
  for delta in (-2,101):
   with self.subTest(delta=delta):
    m,now,reads=self.setup_monitor()
    def scope():now[0]+=delta;return None
    with patch.object(m,'_native_processor_scope',side_effect=scope):r=m.sample()
    self.assertFalse(r.free.measured);self.assertIsNone(m._previous);self.assertEqual(reads,[100,110])
    now[0]=max(now[0],111)+10
    with patch.object(m,'_native_processor_scope',return_value=(1,4)):self.assertEqual(m.sample().free.reason,'CPU_BASELINE_REQUIRED')
 def test_concurrent_call_cannot_reuse_capacity_after_observed_conflict(self):
  m,now,reads=self.setup_monitor();entered=threading.Event();release=threading.Event();out=[];errors=[]
  def scope():entered.set();self.assertTrue(release.wait(3));return None
  def sample():
   try:out.append(m.sample())
   except BaseException as e:errors.append(e)
  with patch.object(m,'_native_processor_scope',side_effect=scope) as call:
   a=threading.Thread(target=sample);a.start();self.assertTrue(entered.wait(3));b=threading.Thread(target=sample);b.start();release.set();a.join(3);b.join(3)
  self.assertFalse(a.is_alive() or b.is_alive());self.assertEqual(errors,[]);self.assertEqual(len(out),2);self.assertTrue(all(not x.reservable.measured for x in out));self.assertIs(out[0],out[1]);self.assertEqual(call.call_count,1);self.assertEqual(reads,[100,110]);self.assertIsNone(m._previous)
 def test_process_control_interrupt_clears_cache_and_allows_clean_retry(self):
  for error in (KeyboardInterrupt('control'),SystemExit(8)):
   with self.subTest(error=type(error)):
    m,now,reads=self.setup_monitor()
    with patch.object(m,'_native_processor_scope',side_effect=error),self.assertRaises(type(error)) as caught:m.sample()
    self.assertIs(caught.exception,error);self.assertIsNone(m._cached);self.assertIsNone(m._previous)
    with patch.object(m,'_native_processor_scope',return_value=(1,4)):self.assertEqual(m.sample().free.reason,'CPU_BASELINE_REQUIRED')
if __name__=='__main__':
 with patch('ceta.resource.hardware.ctypes.WinDLL',side_effect=AssertionError('native effects prohibited')):unittest.main(verbosity=2)
