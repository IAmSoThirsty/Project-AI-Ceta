from pathlib import Path
import sys,unittest,json
from unittest.mock import patch
R=Path(__file__).resolve().parent;W=R.parent/'work'
source=W.parents[1]/'sol-discovery-r1/work/candidate' if '--r1' in sys.argv else W/'candidate'
sys.path[:0]=[str(source/'src'),str(W/'candidate/tests/contract')]
import ceta.resource.hardware as hardware
assert Path(hardware.__file__).resolve()==(source/'src/ceta/resource/hardware.py').resolve()
names=['test_hardware_discovery_continuation']
if '--r1' not in sys.argv:names+=['test_hardware_observation.HardwareObservationTests']
attempts=[]
def native(*args,**kwargs):
 attempts.append(str(args));raise AssertionError('unexpected native read in controlled review')
with patch('ceta.resource.hardware.ctypes.WinDLL',side_effect=native),patch('ceta.resource.hardware.shutil.disk_usage',side_effect=native):
 result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names))
print(json.dumps(dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skips=len(result.skipped),native_attempts=attempts,source=str(hardware.__file__))))
assert not attempts,attempts
sys.exit(not result.wasSuccessful())
