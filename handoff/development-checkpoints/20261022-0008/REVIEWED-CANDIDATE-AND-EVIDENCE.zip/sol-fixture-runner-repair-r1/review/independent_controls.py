import ast,unittest,json
from pathlib import Path
from unittest.mock import patch
import fixture_scope_runner as m
class IndependentControls(unittest.TestCase):
 def test_exact_scope_rejects_added_scope(self):
  b={'graph_root':str(Path.cwd()),'workspaces':{'x':str(Path.cwd()/'one')}}
  with self.assertRaises(AssertionError):m.assert_claim(b,'x',{'workspace':b['workspaces']['x'],'effective_write_scope':['one/**','two/**']})
 def test_snapshot_hash_error_preserves_exact_exception(self):
  p=Path(__file__).parent/'hash-fault';p.mkdir();(p/'x').write_bytes(b'x');e=KeyboardInterrupt('exact-stop')
  with patch.object(m,'sha',side_effect=e),self.assertRaises(KeyboardInterrupt) as caught:m.complete_snapshot(p)
  self.assertIs(caught.exception,e)
 def test_finalizer_retains_all_errors_when_no_prior_primary(self):
  tree=ast.parse(Path(m.__file__).read_text());execute=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='execute')
  target=next(n for n in execute.body if isinstance(n,ast.Try) and n.finalbody)
  block=compile(ast.fix_missing_locations(ast.Module(body=target.finalbody,type_ignores=[])),str(m.__file__),'exec')
  first=RuntimeError('first complete failure');second=ValueError('second complete failure');failures=iter((first,second));root=Path(__file__).parent
  def complete(*args,**kwargs):raise next(failures)
  state=dict(primary=None,claims={'a':{'workspace':str(root)},'b':{'workspace':str(root)}},hashes={},PROJECT=root,control=root,observed={'a':{'before':{}},'b':{'before':{}}},binding={},returncode=0,check=None,sha=lambda p:'hash',save=lambda *a:None,assert_claim=lambda *a:None,complete_snapshot=lambda p:{},changed=lambda *a:[],complete=complete,Path=Path)
  exec(block,state)
  self.assertIs(state['primary'],first)
  self.assertEqual(getattr(first,'fixture_retirement_errors',()),(first,second),'later exact retirement exception is lost when no earlier primary exists')
