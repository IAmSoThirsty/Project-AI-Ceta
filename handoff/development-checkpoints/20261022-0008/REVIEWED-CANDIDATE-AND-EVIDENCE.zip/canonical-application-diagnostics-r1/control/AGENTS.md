# Canonical ordinary application diagnostics

Own ordinary job and new UUID development profile only. Preserve canonical source, prior fixture files, active work, Git and host/protected native state.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/canonical-application-diagnostics-r1/work/**"
        ]
      },
      "review": {
        "kind": "agent",
        "role": "reviewer",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/canonical-application-diagnostics-r1/review/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/canonical-application-diagnostics-r1/delivery/**"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:\\00-Active\\Project-AI-CETA\\.agents\\source-assembly-20261014T021300Z\\.agents\\e3\\Scripts\\python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\operational-resume-20261020\\canonical-application-diagnostics-r1\\work\\verify_result.py\""
        ]
      }
    },
    "nodes": {
      "fixtures": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/fixtures/operator-24/**"
        ]
      }
    },
    "edges": [
      {
        "id": "plan_fixtures",
        "from": "plan",
        "to": "fixtures",
        "type": "delegates_to"
      },
      {
        "id": "fixtures_review",
        "from": "fixtures",
        "to": "review",
        "type": "requires_review"
      }
    ]
  }
}
```
