from pathlib import Path
import json,hashlib,difflib
R=Path(__file__).resolve().parent;S=R.parent;F=Path("T:/00-Active/Project-AI-CETA");W=S/"work";L=W/"live-cli-01"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
def verify():
 packet=read(S/"packet/INPUTS.json");start=read(L/"START.json");result=read(L/"RESULT.json");owner=read(L/"OWNED-LAUNCH.json");pins=read(L/"SOURCE-PINS.json");manifest=Path(packet["source_manifest"])
 assert sha(manifest)==packet["source_manifest_sha256"]==start["source_manifest_sha256"]
 assert len(pins)==559 and pins==read(manifest)["payload_hashes"]
 assert all(sha(F/n)==h for n,h in pins.items())
 assert result["source_unchanged"] is True and result["source_pins_sha256"]==sha(L/"SOURCE-PINS.json")
 assert sha(W/"run_canonical_cli.py")==start["script_sha256"]
 assert sha(Path(start["command"][0]))==start["python_sha256"]==owner["image_sha256"]
 assert start["command"]==result["command"] and start["command"][1:]==packet["command"][1:]
 assert Path(start["candidate"])==F
 custody=result["custody"];assert custody["native_owner"]==owner
 assert owner["pid"]==23248 and owner["creation_time"]==134370103576265961
 assert custody["child_exit"]==0 and custody["primary_error"] is None and custody["retirement_error"] is None
 assert custody["native_owner_after"]==dict(closed=True,process_closed=True,thread_closed=True,job_closed=True,startup_handles_closed=True)
 assert custody["automatic_cleanup_retry"] is False
 for name in ("stdout","stderr"):
  p=L/(name+".bin");claim=custody["child_result"]["logs"][name]
  assert Path(claim["path"])==p and claim["bytes"]==p.stat().st_size and claim["sha256"]==sha(p)
 assert (L/"stderr.bin").read_bytes()==b""
 payload=read(L/"stdout.bin");assert payload==custody["child_result"]["payload"]
 assert (payload["startup"],payload["operation"],payload["cleanup"])==("READY","COMPLETE_PROCESS_USAGE","STOPPED")
 d=payload["diagnostics"];assert d["envelope_status"]=="CALLER_DECLARED_UNQUALIFIED" and d["qualification"]=="NOT_ESTABLISHED"
 assert d["latency"]=="UNOBSERVED" and d["causal_bottleneck"]=="NOT_ESTABLISHED"
 assert set(d["processes"])=={"service","client"} and d["sample_count_per_process"]==2
 for v in d["processes"].values():
  assert v["measurement_state"]=="MEASURED_PROCESS_USAGE" and not v["telemetry"]["within_envelope"]
  assert set(v["telemetry"]["findings"])=={"LATENCY_UNAVAILABLE","CPU_UNAVAILABLE"}
 terminal=read(S/"control/EXECUTION-TERMINAL.json");command=read(S/"control/EXECUTION-COMMAND.json")
 assert terminal["exit_status"]==0 and terminal["argv"]==command["argv"] and Path(command["argv"][-1])==W/"run_canonical_cli.py"
 outer=read(S/"control/EXECUTION.stdout");assert outer["exit_status"]==0 and outer["observed"]==payload and outer["custody"]==custody["native_owner_after"]
 assert (S/"control/EXECUTION.stderr").read_bytes()==b""
 assert not (W/"verify_result.py").exists()
 assert "verify_result.py" in (S/"control/AGENTS.md").read_text()
 assert sha(F/".agents/runtime/operational-resume-20261020/runner-repair-r1/work/tools/bounded_custody.py")=="715b88ab286a524f5815ec3c47b987ba82cc50709272fdc467b7ddc76eeba1b4"
 return {"passed":True,"source_payloads":559,"pid":owner["pid"],"creation_time":owner["creation_time"],"actual_child_exit":0,"all_five_outer_handles_closed":True,"formal_graph_gate":"NOT_RUN_MISSING_SCRIPT","native_reexecution":False,"full_product_acceptance":False}
if __name__=="__main__":print(json.dumps(verify(),indent=2))
