# Exact CETA full-product continuation scope

Implement existing requirements; original full scope remains. Preserve all canonical files and predecessor candidates. Only own work directory writable until distinct review and Root publication. No other project imports, protected profile/debug operation, host setting change or old grant replay.

```agents-graph
{
  "version": 1,
  "graph": {
    "id": "t_drive_repository_change",
    "override_nodes": {
      "implement": {
        "kind": "agent",
        "role": "worker",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-journal-read-budget-r1/work/**"
        ]
      },
      "review": {
        "kind": "agent",
        "role": "reviewer",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-journal-read-budget-r1/review/**"
        ]
      },
      "integrate": {
        "kind": "integration",
        "role": "integrator",
        "access": "write_scoped",
        "write_scope": [
          "00-Active/Project-AI-CETA/.agents/runtime/operational-resume-20261020/sol-journal-read-budget-r1/delivery/**"
        ]
      },
      "validate": {
        "kind": "gate",
        "access": "read_only",
        "commands": [
          "\"T:/00-Active/Project-AI-CETA/.agents/source-assembly-20261014T021300Z/.agents/e3/Scripts/python.exe\" -B -X utf8 \"T:\\00-Active\\Project-AI-CETA\\.agents\\runtime\\operational-resume-20261020\\sol-journal-read-budget-r1\\work\\verify_frozen.py\""
        ]
      }
    }
  }
}
```
