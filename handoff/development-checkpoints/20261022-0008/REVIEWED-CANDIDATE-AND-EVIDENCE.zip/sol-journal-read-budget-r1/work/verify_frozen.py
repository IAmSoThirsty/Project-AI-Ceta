"""Exact source and evidence gate; canonical publication is another scope."""
from pathlib import Path
import hashlib
import json
w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((w / "MANIFEST.json").read_text())
b = json.loads((w / "BASELINE.json").read_text())["payload_hashes"]
assert len(b) == 559
c = w / "candidate"
actual = {str(p.relative_to(c)).replace("\\", "/"): sha(p) for p in c.rglob("*")
          if p.is_file() and not p.is_relative_to(c / ".agents/fixtures")}
assert actual == m["payload_hashes"] and len(actual) == 560
assert {n for n in b if b[n] != actual.get(n)} == set(m["changed_paths"])
assert set(actual) - set(b) == {"tests/contract/test_journal_read_budget.py"}
assert set(m["changed_paths"]) == {"src/ceta/store/journal.py", "src/ceta/composition/resource_diagnostics.py",
    "tests/contract/test_operator_resource_diagnostics.py", "docs/operations/operator_resource_diagnostics.md"}
for n, expected in b.items():
    assert sha(Path(m["baseline_candidate"]) / n) == expected, ("baseline drift", n)
for p, h in m["predecessor_hashes"].items(): assert sha(Path(p)) == h, p
for n, h in m["support_hashes"].items(): assert sha(w / n) == h, n
r = json.loads((w / "TESTS.json").read_text())
assert r["successful"] and r["tests"] == 107 and not any(r[k] for k in ("failures", "errors", "skips"))
for n, h in r["tested_source_hashes"].items():
    assert actual[n] == h
    compile((c / n).read_bytes(), str(c / n), "exec")
failure = json.loads((w / "CLOSE-GUARD-FAILURE.json").read_text())
assert failure["exit_status"] != 0 and sha(w / "BEFORE-CLOSE-GUARD.py") == failure["source_sha256"]
assert json.loads((w / "COMPILE.json").read_text())["exit_status"] == 0
print("FROZEN PASS:559 baseline payloads conserved outside4 changed paths;1 new test;107 passing checks;actual earlier failure retained separately")
