"""Targeted real SQLite and controlled operator checks; no child processes."""
from pathlib import Path
import hashlib
import json
import sys
import unittest
w = Path(__file__).resolve().parent
c = w / "candidate"
sys.path[:0] = [str(c / "src"), str(c / "tests/contract")]
names = ["test_journal_read_budget", "test_operator_resource_diagnostics",
         "test_operator_diagnostics_launcher", "test_journal_constructor_cleanup",
         "test_journal_postconstruction_cleanup"]
from test_store_transactions import AtomicStoreTests
excluded = ["test_process_crash_before_or_after_commit_reopens_as_whole_transaction"]
names += ["test_store_transactions.AtomicStoreTests." + n for n in unittest.defaultTestLoader.getTestCaseNames(AtomicStoreTests) if n not in excluded]
with (w / "TESTS.log").open("w", encoding="utf8") as log:
    print("python", sys.executable, sys.version, file=log)
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.TestSuite(
        unittest.defaultTestLoader.loadTestsFromName(n) for n in names))
paths = ["src/ceta/store/journal.py", "src/ceta/composition/resource_diagnostics.py",
         "tests/contract/test_journal_read_budget.py", "tests/contract/test_operator_resource_diagnostics.py"]
report = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skips=len(result.skipped), successful=result.wasSuccessful(), names=names,
              excluded_subprocess_methods=excluded, python=sys.executable, version=sys.version,
              tested_source_hashes={n: hashlib.sha256((c / n).read_bytes()).hexdigest() for n in paths})
(w / "TESTS.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k:v for k,v in report.items() if k != "names"}))
sys.exit(not result.wasSuccessful())
