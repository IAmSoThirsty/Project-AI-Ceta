from pathlib import Path
import hashlib,importlib,io,json,sys,threading,unittest
from unittest.mock import patch
R=Path(__file__).resolve().parent;C=R/'c';sys.path[:0]=[str(C/'src'),str(C/'tests/contract')]
import test_journal_read_budget as base
from ceta.store import journal as owner
from ceta.store.journal import SqliteJournal,JournalReadBudget
from ceta.contracts.wire import ContractError
from test_store_transactions import AtomicStoreTests
class IndependentCases(unittest.TestCase):
 setUp=base.JournalReadBudgetTests.setUp
 tearDown=base.JournalReadBudgetTests.tearDown
 budget=base.JournalReadBudgetTests.budget
 reader=base.JournalReadBudgetTests.reader
 costly_validation=base.JournalReadBudgetTests.costly_validation
 close_after_budget_failure=base.JournalReadBudgetTests.close_after_budget_failure
 def test_precancel_refuses_before_runtime_or_filesystem(self):
  with patch.object(owner,'load_sqlite',side_effect=AssertionError('runtime reached')),patch.object(owner,'_location',side_effect=AssertionError('filesystem reached')):
   with self.assertRaisesRegex(ContractError,'JOURNAL_READ_CANCELLED'):self.reader(self.budget(cancelled=lambda:True))
 def test_all_closed_reads_precede_callbacks(self):
  calls=[0];armed=[False]
  def cancel():
   calls[0]+=1
   if armed[0]:raise AssertionError('closed owner callback')
   return False
  q=self.reader(self.budget(cancelled=cancel));q.close();armed[0]=True;before=calls[0]
  for read in [q.validate,lambda:q.position(base.SCOPES[0]),q.store_position,lambda:q.snapshot(()),lambda:q.replay(base.SCOPES[0]),lambda:q.projection(base.SCOPES[0]),q.storage_identity]:
   with self.assertRaisesRegex(ContractError,'JOURNAL_CLOSED'):read()
  self.assertEqual(calls[0],before)
 def test_busy_close_does_not_touch_connection_then_recovers(self):
  q=self.reader();wrapped=base.ConnectionFault(q._connection);q._connection=wrapped;held=threading.Event();release=threading.Event()
  def hold():
   with q._lock:held.set();release.wait(3)
  t=threading.Thread(target=hold);t.start();self.assertTrue(held.wait(3))
  try:
   with self.assertRaisesRegex(ContractError,'JOURNAL_READ_BUDGET_BUSY'):q.close()
   self.assertEqual((wrapped.removals,wrapped.closes),(0,0))
  finally:release.set();t.join(3)
  self.assertFalse(t.is_alive());q.close();self.assertEqual((wrapped.removals,wrapped.closes),(1,1))
 def test_constructor_primary_and_both_cleanup_failures_retained(self):
  real=self.writer._sqlite.connect;primary=SystemExit('install');remove=RuntimeError('remove');close=RuntimeError('close');owners=[]
  def connect(*a,**k):
   q=base.ConnectionFault(real(*a,**k),install=primary,remove=remove,close=close);owners.append(q);return q
  with patch.object(self.writer._sqlite,'connect',side_effect=connect):
   with self.assertRaises(SystemExit) as caught:self.reader()
  self.assertIs(caught.exception,primary);self.assertIs(primary.journal_cleanup_error,close);self.assertIs(primary.journal_progress_error,remove)
  self.assertEqual((owners[0].removals,owners[0].closes),(1,1))
  with self.assertRaisesRegex(ContractError,'JOURNAL_CONSTRUCTOR_CLOSE_UNCERTAIN'):primary.journal_custody.close()
  self.assertEqual((owners[0].removals,owners[0].closes),(1,1))
 def test_frozen_user_clock_still_hits_elapsed_deadline(self):
  now=[1000];armed=[False]
  q=self.reader(JournalReadBudget(1000001000,clock=lambda:1000))
  start=q._read_budget.elapsed_start
  with patch.object(owner.time,'perf_counter_ns',return_value=start+1000000000):
   with self.assertRaisesRegex(ContractError,'JOURNAL_READ_DEADLINE_EXCEEDED') as caught:q.store_position()
  self.close_after_budget_failure(q,caught.exception)
 def test_cancelled_vm_does_not_poison_new_reader_or_writer(self):
  q=self.reader(self.budget(maximum_vm_steps=10000))
  original=self.writer.store_position()
  with self.assertRaisesRegex(ContractError,'JOURNAL_READ_BUDGET_EXHAUSTED') as caught:self.costly_validation(q)
  self.close_after_budget_failure(q,caught.exception)
  fresh=self.reader()
  try:self.assertEqual(fresh.store_position(),original);self.assertEqual(self.writer.store_position(),original)
  finally:fresh.close()
class ObservedResult(unittest.TextTestResult):
 def __init__(self,*a,**k):super().__init__(*a,**k);self.started=[];self.stopped=[]
 def startTest(self,t):super().startTest(t);self.started.append(t.id())
 def stopTest(self,t):self.stopped.append(t.id());super().stopTest(t)
def ids(suite):
 return [suite.id()] if isinstance(suite,unittest.TestCase) else [v for sub in suite for v in ids(sub)]
names=['test_journal_read_budget','test_operator_resource_diagnostics','test_operator_diagnostics_launcher','test_journal_constructor_cleanup','test_journal_postconstruction_cleanup']
excluded='test_process_crash_before_or_after_commit_reopens_as_whole_transaction'
names+=['test_store_transactions.AtomicStoreTests.'+n for n in unittest.defaultTestLoader.getTestCaseNames(AtomicStoreTests) if n!=excluded]
suite=unittest.TestSuite([*(unittest.defaultTestLoader.loadTestsFromName(n) for n in names),unittest.defaultTestLoader.loadTestsFromTestCase(IndependentCases)])
expected=ids(suite);assert len(expected)==113 and len(set(expected))==113
pins=json.loads((R/'SOURCE-BEFORE.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={p:sha(C/p) for p in pins};assert before==pins
with (R/'TESTS.log').open('x',encoding='utf8') as out:result=unittest.TextTestRunner(stream=out,verbosity=2,resultclass=ObservedResult).run(suite)
after={p:sha(C/p) for p in pins};ok=result.wasSuccessful() and not result.skipped and result.testsRun==113 and result.started==result.stopped==expected and not result.shouldStop and after==before
report={'successful':ok,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'loaded_ids':expected,'started_ids':result.started,'stopped_ids':result.stopped,'payload_before':before,'payload_after':after,'source_unchanged':before==after,'author_cohort':107,'independent_cases':6,'excluded_process_test':excluded,'product_native_launches':False,'full_product_acceptance':False,'python':sys.executable}
with (R/'TESTS.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps({k:v for k,v in report.items() if k not in ['loaded_ids','started_ids','stopped_ids','payload_before','payload_after']}));raise SystemExit(0 if ok else 1)
